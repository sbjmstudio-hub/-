#include "ProfileManager.h"
#include "Settings.h"
#include "ModuleRegistry.h"
#include <windows.h>
#include <filesystem>
#include <cstdlib>

namespace wirza {
namespace {

std::wstring appDataBase(){
    wchar_t* env=nullptr;
    size_t len=0;
    if(_wdupenv_s(&env,&len,L"APPDATA")!=0 || !env) return L".";
    std::wstring p(env);
    free(env);
    p += L"\\Wirza_Cliant";
    std::error_code ec;
    std::filesystem::create_directories(p,ec);
    return p;
}

std::wstring widen(const std::string& s){
    if(s.empty()) return {};
    int n=MultiByteToWideChar(CP_UTF8,0,s.c_str(),-1,nullptr,0);
    if(n<=0) return {};
    std::wstring out(static_cast<size_t>(n),L'\0');
    MultiByteToWideChar(CP_UTF8,0,s.c_str(),-1,out.data(),n);
    if(!out.empty() && out.back()==L'\0') out.pop_back();
    return out;
}

std::string narrow(const std::wstring& s){
    if(s.empty()) return {};
    int n=WideCharToMultiByte(CP_UTF8,0,s.c_str(),-1,nullptr,0,nullptr,nullptr);
    if(n<=0) return {};
    std::string out(static_cast<size_t>(n),'\0');
    WideCharToMultiByte(CP_UTF8,0,s.c_str(),-1,out.data(),n,nullptr,nullptr);
    if(!out.empty() && out.back()=='\0') out.pop_back();
    return out;
}

}

ProfileManager& ProfileManager::Get(){ static ProfileManager p; return p; }

std::wstring ProfileManager::ProfilesDir() const {
    auto d=appDataBase()+L"\\profiles";
    std::error_code ec;
    std::filesystem::create_directories(d,ec);
    return d;
}

std::string ProfileManager::SafeName(const std::string& name){
    std::string out;
    for(char c:name){
        if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-'||c==' ')
            out.push_back(c);
    }
    while(!out.empty() && out.front()==' ') out.erase(out.begin());
    while(!out.empty() && out.back()==' ') out.pop_back();
    if(out.empty()) out="Default";
    return out;
}

std::vector<std::string> ProfileManager::ListProfiles() const {
    std::vector<std::string> result;
    std::error_code ec;
    for(const auto& e:std::filesystem::directory_iterator(ProfilesDir(),ec)){
        if(ec) break;
        if(!e.is_directory()) continue;
        result.push_back(narrow(e.path().filename().wstring()));
    }
    return result;
}

bool ProfileManager::SaveProfile(const std::string& name){
    Settings::Get().Save();
    ModuleRegistry::Get().Save();

    const auto safe=widen(SafeName(name));
    const auto dir=std::filesystem::path(ProfilesDir())/safe;
    std::error_code ec;
    std::filesystem::create_directories(dir,ec);
    if(ec) return false;

    std::filesystem::copy_file(Settings::Get().FilePath(),dir/L"settings.ini",
        std::filesystem::copy_options::overwrite_existing,ec);
    if(ec) return false;
    ec.clear();
    std::filesystem::copy_file(ModuleRegistry::Get().FilePath(),dir/L"modules.ini",
        std::filesystem::copy_options::overwrite_existing,ec);
    return !ec;
}

bool ProfileManager::LoadProfile(const std::string& name){
    const auto safe=widen(SafeName(name));
    const auto dir=std::filesystem::path(ProfilesDir())/safe;
    const auto s=dir/L"settings.ini";
    const auto m=dir/L"modules.ini";
    if(!std::filesystem::exists(s) || !std::filesystem::exists(m)) return false;

    std::error_code ec;
    std::filesystem::copy_file(s,Settings::Get().FilePath(),
        std::filesystem::copy_options::overwrite_existing,ec);
    if(ec) return false;
    ec.clear();
    std::filesystem::copy_file(m,ModuleRegistry::Get().FilePath(),
        std::filesystem::copy_options::overwrite_existing,ec);
    if(ec) return false;

    Settings::Get().Load();
    ModuleRegistry::Get().Load();
    return true;
}

bool ProfileManager::DeleteProfile(const std::string& name){
    const auto safe=widen(SafeName(name));
    std::error_code ec;
    const auto count=std::filesystem::remove_all(std::filesystem::path(ProfilesDir())/safe,ec);
    return !ec && count>0;
}

}
