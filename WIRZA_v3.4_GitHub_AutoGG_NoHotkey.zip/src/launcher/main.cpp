#include <windows.h>
#include <tlhelp32.h>
#include <shellapi.h>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

namespace {
std::filesystem::path exeDir(){
    wchar_t p[MAX_PATH]{};
    GetModuleFileNameW(nullptr,p,MAX_PATH);
    return std::filesystem::path(p).parent_path();
}
std::filesystem::path dllPath(){ return exeDir()/L"WIRZA.Client.dll"; }
std::filesystem::path logPath(){ return exeDir()/L"WIRZA.Launcher.log"; }

void logLine(const std::wstring& s){
    std::wofstream f(logPath(),std::ios::app);
    if(f) f<<s<<L"\n";
    std::wcout<<s<<L"\n";
}

void waitForEnter(){
    std::wcout<<L"Press Enter to close..."<<std::flush;
    std::wstring line;
    std::getline(std::wcin,line);
}


bool processRunning(const wchar_t* exeName){
    PROCESSENTRY32W pe{sizeof(pe)};
    HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
    if(snap==INVALID_HANDLE_VALUE) return false;
    bool found=false;
    if(Process32FirstW(snap,&pe)){
        do{
            if(_wcsicmp(pe.szExeFile,exeName)==0){ found=true; break; }
        }while(Process32NextW(snap,&pe));
    }
    CloseHandle(snap);
    return found;
}

bool processHasModule(DWORD pid,const wchar_t* moduleName){
    HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,pid);
    if(snap==INVALID_HANDLE_VALUE) return false;
    MODULEENTRY32W me{sizeof(me)};
    bool found=false;
    if(Module32FirstW(snap,&me)){
        do{
            if(_wcsicmp(me.szModule,moduleName)==0){ found=true; break; }
        }while(Module32NextW(snap,&me));
    }
    CloseHandle(snap);
    return found;
}

bool wirzaAlreadyLoaded(DWORD pid){
    return processHasModule(pid,L"WIRZA.Client.dll");
}

void waitForObsGameCapture(DWORD pid){
    if(!processRunning(L"obs64.exe") && !processRunning(L"obs32.exe")) return;

    if(processHasModule(pid,L"graphics-hook64.dll") || processHasModule(pid,L"graphics-hook32.dll")){
        logLine(L"[OBS] Game Capture graphics hook is already inside Minecraft.");
        return;
    }

    logLine(L"[OBS] OBS detected. Waiting briefly for its Game Capture graphics hook...");
    for(int i=0;i<80;i++){
        if(processHasModule(pid,L"graphics-hook64.dll") || processHasModule(pid,L"graphics-hook32.dll")){
            logLine(L"[OBS] Game Capture hook detected. WIRZA will load after OBS so its in-game draw is captured.");
            return;
        }
        Sleep(100);
    }
    logLine(L"[OBS] Game Capture hook was not detected. Continuing normally; enable the Minecraft Game Capture source before launching WIRZA for the most reliable capture order.");
}

DWORD findMinecraft(){
    const std::vector<std::wstring> names={L"Minecraft.Windows.exe",L"Minecraft.exe"};
    PROCESSENTRY32W pe{sizeof(pe)};
    HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
    if(snap==INVALID_HANDLE_VALUE)return 0;
    DWORD pid=0;
    if(Process32FirstW(snap,&pe)){
        do{
            for(const auto& n:names){
                if(_wcsicmp(pe.szExeFile,n.c_str())==0){ pid=pe.th32ProcessID; break; }
            }
            if(pid) break;
        }while(Process32NextW(snap,&pe));
    }
    CloseHandle(snap);
    return pid;
}

bool loadClient(DWORD pid,const std::filesystem::path& dll){
    HANDLE p=OpenProcess(PROCESS_CREATE_THREAD|PROCESS_QUERY_INFORMATION|
                         PROCESS_VM_OPERATION|PROCESS_VM_WRITE|PROCESS_VM_READ,
                         FALSE,pid);
    if(!p){
        logLine(L"[ERROR] OpenProcess failed. Windows error="+std::to_wstring(GetLastError()));
        return false;
    }

    const std::wstring path=std::filesystem::absolute(dll).wstring();
    const SIZE_T bytes=(path.size()+1)*sizeof(wchar_t);
    void* remote=VirtualAllocEx(p,nullptr,bytes,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
    if(!remote){
        logLine(L"[ERROR] VirtualAllocEx failed. Windows error="+std::to_wstring(GetLastError()));
        CloseHandle(p);
        return false;
    }

    bool ok=WriteProcessMemory(p,remote,path.c_str(),bytes,nullptr)!=FALSE;
    if(!ok) logLine(L"[ERROR] WriteProcessMemory failed. Windows error="+std::to_wstring(GetLastError()));

    auto load=reinterpret_cast<LPTHREAD_START_ROUTINE>(
        GetProcAddress(GetModuleHandleW(L"kernel32.dll"),"LoadLibraryW"));
    HANDLE th=(ok&&load)?CreateRemoteThread(p,nullptr,0,load,remote,0,nullptr):nullptr;
    if(!th){
        logLine(L"[ERROR] CreateRemoteThread failed. Windows error="+std::to_wstring(GetLastError()));
        ok=false;
    }else{
        const DWORD wait=WaitForSingleObject(th,15000);
        DWORD exitCode=0;
        if(wait!=WAIT_OBJECT_0 || !GetExitCodeThread(th,&exitCode) || exitCode==0){
            logLine(L"[ERROR] Minecraft did not confirm WIRZA.Client.dll loading.");
            ok=false;
        }
        CloseHandle(th);
    }

    VirtualFreeEx(p,remote,0,MEM_RELEASE);
    CloseHandle(p);
    return ok;
}

void launchMinecraft(){ ShellExecuteW(nullptr,L"open",L"minecraft://",nullptr,nullptr,SW_SHOWNORMAL); }
}

int wmain(){
    SetConsoleTitleW(L"WIRZA Client v3.4");
    logLine(L"========================================");
    logLine(L" WIRZA CLIENT v3.4 - INTERNAL HUD / OBS");
    logLine(L"========================================");
    logLine(L"[INFO] Transparent two-file build: no hidden payload, no temp DLL, no self-delete.");

    const auto dll=dllPath();
    if(!std::filesystem::exists(dll)){
        logLine(L"[ERROR] WIRZA.Client.dll must be next to WIRZA.Launcher.exe.");
        waitForEnter();
        return 2;
    }

    DWORD pid=findMinecraft();
    if(!pid){
        logLine(L"[INFO] Minecraft Bedrock is not running. Starting it...");
        launchMinecraft();
        for(int i=0;i<60&&!pid;i++){ Sleep(1000); pid=findMinecraft(); }
    }
    if(!pid){
        logLine(L"[ERROR] Minecraft process was not detected.");
        waitForEnter();
        return 3;
    }

    logLine(L"[INFO] Minecraft PID="+std::to_wstring(pid));
    if(wirzaAlreadyLoaded(pid)){
        logLine(L"[OK] WIRZA.Client.dll is already loaded in Minecraft; no second injection was attempted.");
        logLine(L"[INFO] Right Shift = WIRZA menu");
        waitForEnter();
        return 0;
    }

    // OBS Game Capture also hooks the graphics API. When OBS is already active,
    // loading WIRZA after graphics-hook makes WIRZA's Present draw much more
    // likely to be inside the frame OBS copies from Minecraft.
    waitForObsGameCapture(pid);

    logLine(L"[INFO] Loading visible WIRZA.Client.dll from the launcher folder...");
    if(!loadClient(pid,dll)){
        logLine(L"[ERROR] Client load failed.");
        waitForEnter();
        return 4;
    }

    logLine(L"[OK] WIRZA Client loaded.");
    logLine(L"[INFO] Right Shift = WIRZA menu");
    logLine(L"[INFO] Hold C = native Minecraft camera zoom when this game build is supported.");
    logLine(L"[INFO] FOV and GUI Scale use guarded local Minecraft state; visual/HUD effects stay in the game D3D12 frame.");
    logLine(L"[INFO] HUD is rendered into Minecraft's D3D12 backbuffer before Present for OBS Game Capture compatibility.");
    waitForEnter();
    return 0;
}
