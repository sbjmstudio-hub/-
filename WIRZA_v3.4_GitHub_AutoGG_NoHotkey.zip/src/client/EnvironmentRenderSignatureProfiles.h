#pragma once
#include <array>
#include <cstddef>
#include <string_view>

namespace wirza {

enum class EnvironmentFogColorAbi {
    DimensionBrightnessFogColorRefV1
};

enum class EnvironmentFogScalarsAbi {
    OpaqueFogStateRefV1
};

enum class EnvironmentOverlayAbi {
    AlphaRefV1
};

// Exact-build adapter for Bedrock's client-side environment rendering paths.
// Every pattern/offset below is part of the ABI contract and must be verified
// against the exact Minecraft for Windows build before a profile is added.
// Empty pattern strings simply mean that capability was not verified for that
// build and must remain disabled.
struct EnvironmentRenderSignatureProfile {
    std::string_view gameVersion;

    // Dimension::getBrightnessDependentFogColor-style path.
    std::string_view fogColorPattern;
    bool fogColorResolveRel32=false;
    int fogColorDisplacementOffset=1;
    int fogColorInstructionLength=5;
    EnvironmentFogColorAbi fogColorAbi=EnvironmentFogColorAbi::DimensionBrightnessFogColorRefV1;

    // Opaque fog-parameter update path. Offsets are byte offsets inside the
    // verified fog state object. -1 means unavailable on that profile.
    std::string_view fogScalarsPattern;
    bool fogScalarsResolveRel32=false;
    int fogScalarsDisplacementOffset=1;
    int fogScalarsInstructionLength=5;
    EnvironmentFogScalarsAbi fogScalarsAbi=EnvironmentFogScalarsAbi::OpaqueFogStateRefV1;
    std::ptrdiff_t fogStartOffset=-1;
    std::ptrdiff_t fogEndOffset=-1;
    std::ptrdiff_t fogDensityOffset=-1;

    // Separate screen-overlay paths keep fire/water/in-block policy isolated.
    // AlphaRefV1 is only valid when the verified target exposes a mutable alpha
    // float by reference. There is intentionally no guessed fallback ABI.
    std::string_view fireOverlayPattern;
    bool fireOverlayResolveRel32=false;
    int fireOverlayDisplacementOffset=1;
    int fireOverlayInstructionLength=5;

    std::string_view waterOverlayPattern;
    bool waterOverlayResolveRel32=false;
    int waterOverlayDisplacementOffset=1;
    int waterOverlayInstructionLength=5;

    std::string_view blockOverlayPattern;
    bool blockOverlayResolveRel32=false;
    int blockOverlayDisplacementOffset=1;
    int blockOverlayInstructionLength=5;
    EnvironmentOverlayAbi overlayAbi=EnvironmentOverlayAbi::AlphaRefV1;
};

// Intentionally empty in this source package. Add an entry only after the
// exact Minecraft executable, function ABI and all used offsets are verified
// on a real Windows/Minecraft build. No wildcard/nearest-version matching.
inline constexpr std::array<EnvironmentRenderSignatureProfile,0> kVerifiedEnvironmentRenderProfiles{};

inline const EnvironmentRenderSignatureProfile* VerifiedEnvironmentRenderProfileFor(std::string_view gameVersion){
    for(const auto& profile:kVerifiedEnvironmentRenderProfiles){
        if(profile.gameVersion==gameVersion) return &profile;
    }
    return nullptr;
}

} // namespace wirza
