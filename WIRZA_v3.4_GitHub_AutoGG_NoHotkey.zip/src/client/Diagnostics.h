#pragma once
#include <string>

namespace wirza {

class Diagnostics {
public:
    static Diagnostics& Get();
    std::string GameVersion() const;
    bool ObsRunning() const;
};

}
