#pragma once
#include <chrono>
#include <string>
#include <windows.h>

namespace wirza {

// Sends one local "gg" message after WIRZA observes a clear victory result.
// It never sends on kills, clicks, movement, or arbitrary hotkeys.
class AutoGGController {
public:
    static AutoGGController& Get();
    void Update(HWND hwnd, bool gameplayActive);
    const char* StatusText() const { return status_.c_str(); }

private:
    void queueGG(int delayMs);
    void cancelPending();
    void typeUnicode(const std::string& text);
    void tapKey(WORD vk);
    bool titleShowsVictory() const;
    bool observeFreshVictoryChat(std::chrono::steady_clock::time_point now);
    static bool containsVictoryPhrase(const std::string& text);

    int phase_=0;
    std::string pending_;
    std::chrono::steady_clock::time_point due_{};

    bool previousTitleVictory_=false;
    bool sentForRound_=false;
    std::string lastVictoryChatKey_;
    std::chrono::steady_clock::time_point lastVictoryEvidence_{};
    std::string status_="Armed";
};

}
