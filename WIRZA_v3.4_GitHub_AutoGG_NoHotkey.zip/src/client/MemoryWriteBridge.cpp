#include "MemoryWriteBridge.h"

#include "GameDataBridge.h"
#include "Input.h"
#include "ModuleRegistry.h"
#include "PatternScan.h"

#include <MinHook.h>
#include <windows.h>

#include <algorithm>
#include <cmath>
#include <cstring>

namespace wirza {
namespace {
// Current public Bedrock clients use this ABI for LevelRendererPlayer::getFov.
// We still require a pattern match at runtime; if it is absent, WIRZA leaves the
// game's camera untouched instead of guessing an address.
using GetFovFn=float(__fastcall*)(void*,float,void*,void*);
GetFovFn g_originalGetFov=nullptr;
void* g_getFovTarget=nullptr;

using GetGammaFn=float(__fastcall*)(uintptr_t);
GetGammaFn g_originalGetGamma=nullptr;
void* g_getGammaTarget=nullptr;

constexpr const char* kGetFovPatternPrimary=
    "4C 8B DC 53 48 83 EC ? 0F 29 74 24";
constexpr const char* kGetFovPatternFallback=
    "48 8B ? 48 89 ? ? 48 89 ? ? 57 48 81 EC ? ? ? ? "
    "0F 29 ? ? 0F 29 ? ? 44 0F ? ? ? 44 0F ? ? ? 48 8B ? ? ? ? ? "
    "48 33 ? 48 89 ? ? ? 41 0F";

constexpr const char* kGetGammaPatternPrimary=
    "48 83 EC 28 48 8B 01 48 8D 54 24 30 41 B8 36 00 00 00";
constexpr const char* kGetGammaPatternFallback=
    "48 83 EC 38 48 8B 05 ? ? ? ? 48 31 E0 48 89 44 24 ? "
    "48 8B 01 48 8B 40 08 48 8D 54 24 ? 41 B8 35 00 00 00";

constexpr ptrdiff_t kClientInstanceGuiDataOffset=0x648;
constexpr ptrdiff_t kGuiScreenSizeOffset=0x40;
constexpr ptrdiff_t kGuiSizeOffset=0x50;
constexpr ptrdiff_t kGuiScaleOffset=0x5C;
constexpr ptrdiff_t kGuiScaleFracOffset=0x60;

struct RawVec2 { float x,y; };

void* readPointer(const void* address){
    if(!ReadableAddress(address,sizeof(void*))) return nullptr;
    void* value=nullptr;
    std::memcpy(&value,address,sizeof(value));
    return ReadableAddress(value,sizeof(void*)) ? value : nullptr;
}

float __fastcall hookGetFov(void* a1,float f,void* a3,void* a4){
    const float vanilla=g_originalGetFov ? g_originalGetFov(a1,f,a3,a4) : f;
    return MemoryWriteBridge::Get().AdjustFov(vanilla);
}

float __fastcall hookGetGamma(uintptr_t a1){
    const float vanilla=g_originalGetGamma ? g_originalGetGamma(a1) : 1.0f;
    return MemoryWriteBridge::Get().AdjustGamma(vanilla);
}

float horizontalSpeed(){
    const auto& p=GameDataBridge::Get().Player();
    if(!p.valid) return 0.0f;
    return std::sqrt(p.velocity.x*p.velocity.x+p.velocity.z*p.velocity.z);
}
}

MemoryWriteBridge& MemoryWriteBridge::Get(){
    static MemoryWriteBridge bridge;
    return bridge;
}

bool MemoryWriteBridge::Install(){
    // ClientCore normally calls this once. Keep the bridge idempotent anyway so
    // a future launcher/reload path cannot stack duplicate MinHook detours.
    if(state_.load()!=MemoryWriteState::NotInitialized)
        return fovReady_.load() || lightingReady_.load() || guiScaleReady_.load();

    HMODULE mc=GetModuleHandleW(nullptr);
    bool fovSignatureFound=false;
    bool fovHookFailed=false;

    // Camera FOV / Zoom. This is independent from gamma and GuiData writes.
    uintptr_t target=FindPattern(mc,kGetFovPatternPrimary);
    if(!target) target=FindPattern(mc,kGetFovPatternFallback);
    if(target && ReadableAddress(reinterpret_cast<void*>(target),16)){
        fovSignatureFound=true;
        g_getFovTarget=reinterpret_cast<void*>(target);
        if(MH_CreateHook(g_getFovTarget,reinterpret_cast<void*>(&hookGetFov),
                         reinterpret_cast<void**>(&g_originalGetFov))==MH_OK &&
           MH_EnableHook(g_getFovTarget)==MH_OK){
            fovReady_=true;
        }else{
            // Never guess another address after a failed hook. Leave vanilla FOV.
            if(g_getFovTarget) MH_DisableHook(g_getFovTarget);
            g_getFovTarget=nullptr;
            g_originalGetFov=nullptr;
            fovReady_=false;
            fovHookFailed=true;
        }
    }

    // Gamma / Lighting. This hook is cosmetic and deliberately independent of
    // FOV support so one changed Bedrock function cannot disable another.
    uintptr_t gammaTarget=FindPattern(mc,kGetGammaPatternPrimary);
    if(!gammaTarget) gammaTarget=FindPattern(mc,kGetGammaPatternFallback);
    if(gammaTarget && ReadableAddress(reinterpret_cast<void*>(gammaTarget),16)){
        g_getGammaTarget=reinterpret_cast<void*>(gammaTarget);
        if(MH_CreateHook(g_getGammaTarget,reinterpret_cast<void*>(&hookGetGamma),
                         reinterpret_cast<void**>(&g_originalGetGamma))==MH_OK &&
           MH_EnableHook(g_getGammaTarget)==MH_OK){
            lightingReady_=true;
        }else{
            if(g_getGammaTarget) MH_DisableHook(g_getGammaTarget);
            g_getGammaTarget=nullptr;
            g_originalGetGamma=nullptr;
            lightingReady_=false;
        }
    }

    if(fovReady_.load()) state_=MemoryWriteState::Ready;
    else if(fovHookFailed && fovSignatureFound) state_=MemoryWriteState::HookFailed;
    else state_=MemoryWriteState::FovSignatureMissing;

    // GuiData becomes available only after ClientInstance is live in a world/menu.
    // Tick() will validate and enable those guarded writes independently.
    return fovReady_.load() || lightingReady_.load();
}

void MemoryWriteBridge::Shutdown(){
    restoreGuiScale();
    if(g_getFovTarget) MH_DisableHook(g_getFovTarget);
    if(g_getGammaTarget) MH_DisableHook(g_getGammaTarget);
    g_getFovTarget=nullptr;
    g_originalGetFov=nullptr;
    g_getGammaTarget=nullptr;
    g_originalGetGamma=nullptr;
    fovReady_=false;
    lightingReady_=false;
    guiScaleReady_=false;
    zoomProjectionRatio_=1.0f;
    state_=MemoryWriteState::NotInitialized;
}

const char* MemoryWriteBridge::StatusText() const{
    const bool fov=fovReady_.load();
    const bool gamma=lightingReady_.load();
    const bool gui=guiScaleReady_.load();

    if(fov && gamma && gui) return "FOV + gamma + guarded GuiData writes ready";
    if(fov && gamma) return "FOV + gamma hooks ready; GuiData activates when available";
    if(fov && gui) return "FOV hook + guarded GuiData writes ready; gamma fallback active";
    if(gamma && gui) return "Gamma + guarded GuiData writes ready; FOV signature unsupported";
    if(fov) return "FOV hook ready; gamma fallback active; waiting for GuiData";
    if(gamma) return "Gamma hook ready; FOV signature unsupported; waiting for GuiData";
    if(gui) return "Guarded GuiData writes ready; FOV/gamma signatures unsupported";

    if(state_.load()==MemoryWriteState::HookFailed)
        return "FOV hook failed; gamma/GUI paths remain independently guarded";
    if(state_.load()==MemoryWriteState::FovSignatureMissing)
        return "No supported FOV/gamma hook yet; guarded GuiData waits for ClientInstance";
    return "Not initialized";
}

bool MemoryWriteBridge::writableAddress(const void* p,size_t bytes){
    if(!p || bytes==0) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if(!VirtualQuery(p,&mbi,sizeof(mbi))) return false;
    if(mbi.State!=MEM_COMMIT || (mbi.Protect&(PAGE_NOACCESS|PAGE_GUARD))) return false;
    const DWORD prot=mbi.Protect&0xFF;
    const bool writable=prot==PAGE_READWRITE || prot==PAGE_WRITECOPY ||
                        prot==PAGE_EXECUTE_READWRITE || prot==PAGE_EXECUTE_WRITECOPY;
    if(!writable) return false;
    const auto start=reinterpret_cast<uintptr_t>(p);
    const auto end=start+bytes;
    const auto regionEnd=reinterpret_cast<uintptr_t>(mbi.BaseAddress)+mbi.RegionSize;
    return end>=start && end<=regionEnd;
}

bool MemoryWriteBridge::writeBytes(void* dst,const void* src,size_t bytes){
    if(!writableAddress(dst,bytes) || !src) return false;
    std::memcpy(dst,src,bytes);
    return true;
}

bool MemoryWriteBridge::validateGuiData(void* gui,Vec2& screen,float& scale,float& frac) const{
    if(!gui || !ReadableAddress(gui,0x68)) return false;

    RawVec2 s{};
    std::memcpy(&s,reinterpret_cast<unsigned char*>(gui)+kGuiScreenSizeOffset,sizeof(s));
    std::memcpy(&scale,reinterpret_cast<unsigned char*>(gui)+kGuiScaleOffset,sizeof(scale));
    std::memcpy(&frac,reinterpret_cast<unsigned char*>(gui)+kGuiScaleFracOffset,sizeof(frac));

    if(!std::isfinite(s.x)||!std::isfinite(s.y)||s.x<320.0f||s.y<180.0f||s.x>20000.0f||s.y>20000.0f)
        return false;
    if(!std::isfinite(scale)||!std::isfinite(frac)||scale<0.20f||scale>8.0f||frac<0.10f||frac>5.0f)
        return false;
    const float reciprocal=scale*frac;
    if(reciprocal<0.70f||reciprocal>1.30f) return false;

    screen={s.x,s.y};
    return writableAddress(reinterpret_cast<unsigned char*>(gui)+kGuiSizeOffset,sizeof(RawVec2)) &&
           writableAddress(reinterpret_cast<unsigned char*>(gui)+kGuiScaleOffset,sizeof(float)) &&
           writableAddress(reinterpret_cast<unsigned char*>(gui)+kGuiScaleFracOffset,sizeof(float));
}

bool MemoryWriteBridge::applyGuiScale(){
    auto& mods=ModuleRegistry::Get();
    auto* module=mods.Find("gui_scale");
    const bool wantsMinecraft=module && module->enabled && !mods.Bool("gui_scale","hud_only",false);
    if(!wantsMinecraft){
        restoreGuiScale();
        return false;
    }

    void* client=GameDataBridge::Get().ClientInstanceRaw();
    if(!client || !ReadableAddress(client,static_cast<size_t>(kClientInstanceGuiDataOffset+sizeof(void*)))){
        guiScaleReady_=false;
        return false;
    }
    void* gui=readPointer(reinterpret_cast<unsigned char*>(client)+kClientInstanceGuiDataOffset);
    Vec2 screen{}; float current=0.0f,frac=0.0f;
    if(!validateGuiData(gui,screen,current,frac)){
        guiScaleReady_=false;
        return false;
    }

    const float target=std::clamp(mods.Float("gui_scale","scale",1.0f),0.5f,2.0f);
    const float targetFrac=1.0f/target;
    const RawVec2 targetSize{screen.x*targetFrac,screen.y*targetFrac};

    std::scoped_lock lock(guiMutex_);
    if(!guiBackup_.valid || guiBackup_.gui!=gui){
        guiBackup_.valid=true;
        guiBackup_.gui=gui;
        guiBackup_.scale=current;
    }

    const bool ok=writeBytes(reinterpret_cast<unsigned char*>(gui)+kGuiScaleOffset,&target,sizeof(target)) &&
                  writeBytes(reinterpret_cast<unsigned char*>(gui)+kGuiScaleFracOffset,&targetFrac,sizeof(targetFrac)) &&
                  writeBytes(reinterpret_cast<unsigned char*>(gui)+kGuiSizeOffset,&targetSize,sizeof(targetSize));
    guiScaleReady_=ok;
    return ok;
}

void MemoryWriteBridge::restoreGuiScale(){
    std::scoped_lock lock(guiMutex_);
    if(!guiBackup_.valid || !guiBackup_.gui) return;

    Vec2 screen{}; float current=0.0f,frac=0.0f;
    if(validateGuiData(guiBackup_.gui,screen,current,frac)){
        const float original=std::clamp(guiBackup_.scale,0.20f,8.0f);
        const float originalFrac=1.0f/original;
        const RawVec2 originalSize{screen.x*originalFrac,screen.y*originalFrac};
        writeBytes(reinterpret_cast<unsigned char*>(guiBackup_.gui)+kGuiScaleOffset,&original,sizeof(original));
        writeBytes(reinterpret_cast<unsigned char*>(guiBackup_.gui)+kGuiScaleFracOffset,&originalFrac,sizeof(originalFrac));
        writeBytes(reinterpret_cast<unsigned char*>(guiBackup_.gui)+kGuiSizeOffset,&originalSize,sizeof(originalSize));
    }
    guiBackup_={};
    guiScaleReady_=false;
}

void MemoryWriteBridge::Tick(){
    applyGuiScale();
}

float MemoryWriteBridge::HudOnlyScale() const{
    auto& mods=ModuleRegistry::Get();
    auto* module=mods.Find("gui_scale");
    if(!module || !module->enabled || !mods.Bool("gui_scale","hud_only",false)) return 1.0f;
    return std::clamp(mods.Float("gui_scale","scale",1.0f),0.5f,2.0f);
}

float MemoryWriteBridge::AdjustFov(float vanillaFov){
    if(!std::isfinite(vanillaFov) || vanillaFov<1.0f || vanillaFov>359.0f)
        return vanillaFov;

    // Bedrock calls the same function for hand projection using fixed values.
    // Preserve those calls so changing/zooming the camera does not distort the hand.
    // Current public Bedrock clients identify the 70-degree call as the hand
    // projection. A main-camera FOV can legitimately be 60, so do not skip it.
    if(std::fabs(vanillaFov-70.0f)<0.10f)
        return vanillaFov;

    auto& mods=ModuleRegistry::Get();
    auto* fovModule=mods.Find("fov");
    auto* zoomModule=mods.Find("zoom");
    const auto& input=Input::Get().State();

    const bool fovEnabled=fovModule && fovModule->enabled;
    const bool zoomActive=zoomModule && zoomModule->enabled && input.foreground && input.c;
    if(!fovEnabled && !zoomActive){
        zoomProjectionRatio_=1.0f;
        std::scoped_lock lock(fovMutex_);
        currentMainFov_=vanillaFov;
        fovBaselineValid_=false;
        lastFovTime_=std::chrono::steady_clock::now();
        return vanillaFov;
    }

    std::scoped_lock lock(fovMutex_);
    const auto now=std::chrono::steady_clock::now();
    float dt=1.0f/60.0f;
    if(lastFovTime_.time_since_epoch().count()!=0){
        dt=std::chrono::duration<float>(now-lastFovTime_).count();
        dt=std::clamp(dt,1.0f/500.0f,0.10f);
    }
    lastFovTime_=now;

    const float speed=horizontalSpeed();
    if(!fovBaselineValid_){
        vanillaBaseline_=vanillaFov;
        currentMainFov_=vanillaFov;
        fovBaselineValid_=true;
    }else if(!zoomActive && speed<0.08f){
        // Slowly track the user's underlying vanilla setting while standing still.
        const float a=std::clamp(dt*2.0f,0.0f,0.20f);
        vanillaBaseline_ += (vanillaFov-vanillaBaseline_)*a;
    }

    const float normal=std::clamp(mods.Float("fov","normal_fov",90.0f),30.0f,120.0f);
    float target=fovEnabled ? normal : vanillaFov;
    if(fovEnabled && mods.Bool("fov","dynamic_fov",true)){
        const float dynamicDelta=std::clamp(vanillaFov-vanillaBaseline_,-20.0f,20.0f);
        target=std::clamp(normal+dynamicDelta,30.0f,140.0f);
    }
    if(zoomActive){
        target=std::clamp(mods.Float("zoom","target_fov",30.0f),5.0f,std::max(5.0f,normal));
    }

    const bool smooth=zoomModule && mods.Bool("zoom","smooth",true);
    if(smooth){
        const float smoothSpeed=std::clamp(mods.Float("zoom","smooth_speed",12.0f),1.0f,30.0f);
        const float alpha=1.0f-std::exp(-smoothSpeed*dt);
        currentMainFov_ += (target-currentMainFov_)*std::clamp(alpha,0.0f,1.0f);
        if(std::fabs(currentMainFov_-target)<0.01f) currentMainFov_=target;
    }else{
        currentMainFov_=target;
    }

    const float projectionBase=fovEnabled ? std::max(1.0f,normal)
                                          : std::clamp(vanillaBaseline_,30.0f,179.0f);
    zoomProjectionRatio_=std::clamp(currentMainFov_/projectionBase,0.04f,1.5f);
    return std::clamp(currentMainFov_,1.0f,359.0f);
}

float MemoryWriteBridge::AdjustGamma(float vanillaGamma){
    if(!std::isfinite(vanillaGamma) || vanillaGamma<0.0f || vanillaGamma>100.0f)
        return vanillaGamma;

    auto& mods=ModuleRegistry::Get();
    auto* lighting=mods.Find("lighting");
    if(!lighting || !lighting->enabled) return vanillaGamma;

    if(mods.Bool("lighting","full_bright",false)) return 25.0f;

    const float brightness=std::clamp(mods.Float("lighting","brightness",1.0f),0.5f,2.0f);
    const float gamma=std::clamp(mods.Float("lighting","gamma",1.0f),0.5f,3.0f);
    const float base=std::max(0.05f,vanillaGamma);
    return std::clamp(base*brightness*gamma,0.05f,25.0f);
}

}
