#pragma once
#include <array>
#include <cstddef>
#include <string_view>

namespace wirza {

enum class ActorOverlayAbi {
    GetOverlayColorV1
};

// Exact-build adapter for the actor overlay-color render path.
// actorPointerOffset is part of the verified ABI because some Bedrock builds
// pass a render object that contains the Actor* rather than the Actor* itself.
struct ActorOverlaySignatureProfile {
    std::string_view gameVersion;
    std::string_view pattern;
    bool resolveRel32Call=true;
    int displacementOffset=1;
    int instructionLength=5;
    std::ptrdiff_t actorPointerOffset=0;
    ActorOverlayAbi abi=ActorOverlayAbi::GetOverlayColorV1;
};

// Intentionally empty in this package. A profile may be added only after the
// exact Minecraft for Windows version, function ABI, and actor pointer offset
// are verified on that build. There is no guessed/wildcard fallback.
inline constexpr std::array<ActorOverlaySignatureProfile,0> kVerifiedActorOverlayProfiles{};

inline const ActorOverlaySignatureProfile* VerifiedActorOverlayProfileFor(std::string_view gameVersion) {
    for (const auto& profile : kVerifiedActorOverlayProfiles) {
        if (profile.gameVersion == gameVersion) return &profile;
    }
    return nullptr;
}

} // namespace wirza
