#include "Settings.h"
#include <filesystem>
#include <cstdlib>
#include <cwchar>

namespace wirza {
namespace {
std::wstring appDataDir() {
    wchar_t* env = nullptr;
    size_t len = 0;
    if (_wdupenv_s(&env, &len, L"APPDATA") != 0 || !env) return L".";
    std::wstring path(env);
    free(env);
    path += L"\\WIRZA Client";
    std::error_code ec;
    std::filesystem::create_directories(path, ec);
    return path;
}

int readInt(const std::wstring& f, const wchar_t* key, int def) {
    return static_cast<int>(GetPrivateProfileIntW(L"WIRZA", key, def, f.c_str()));
}
float readFloat(const std::wstring& f, const wchar_t* key, float def) {
    wchar_t buf[64]{};
    wchar_t d[64]{};
    swprintf_s(d, L"%.4f", def);
    GetPrivateProfileStringW(L"WIRZA", key, d, buf, 64, f.c_str());
    return static_cast<float>(_wtof(buf));
}
void writeInt(const std::wstring& f, const wchar_t* key, int v) {
    wchar_t b[32]{}; swprintf_s(b, L"%d", v);
    WritePrivateProfileStringW(L"WIRZA", key, b, f.c_str());
}
void writeFloat(const std::wstring& f, const wchar_t* key, float v) {
    wchar_t b[64]{}; swprintf_s(b, L"%.4f", v);
    WritePrivateProfileStringW(L"WIRZA", key, b, f.c_str());
}
void loadPos(const std::wstring& f, const wchar_t* prefix, HudPosition& p) {
    std::wstring kx = std::wstring(prefix) + L"X";
    std::wstring ky = std::wstring(prefix) + L"Y";
    p.x = readFloat(f, kx.c_str(), p.x); p.y = readFloat(f, ky.c_str(), p.y);
}
void savePos(const std::wstring& f, const wchar_t* prefix, const HudPosition& p) {
    std::wstring kx = std::wstring(prefix) + L"X";
    std::wstring ky = std::wstring(prefix) + L"Y";
    writeFloat(f, kx.c_str(), p.x); writeFloat(f, ky.c_str(), p.y);
}
}

Settings& Settings::Get() { static Settings s; return s; }
std::wstring Settings::FilePath() const { return appDataDir() + L"\\settings.ini"; }
void Settings::Load() {
    const auto f = FilePath();
    fps = readInt(f,L"FPS",fps)!=0; cps = readInt(f,L"CPS",cps)!=0;
    wasd = readInt(f,L"WASD",wasd)!=0; mouse = readInt(f,L"Mouse",mouse)!=0;
    timer = readInt(f,L"Timer",timer)!=0; stopwatch = readInt(f,L"Stopwatch",stopwatch)!=0;
    zoom = readInt(f,L"Zoom",zoom)!=0; hideAllHud = readInt(f,L"HideAll",hideAllHud)!=0;
    animations = readInt(f,L"Animations",animations)!=0;
    hudBackground = readInt(f,L"HudBackground",hudBackground)!=0;
    hudShadow = readInt(f,L"HudShadow",hudShadow)!=0;
    hideWhenNotMinecraft = readInt(f,L"HideWhenNotMinecraft",hideWhenNotMinecraft)!=0;
    savePosition = readInt(f,L"SavePosition",savePosition)!=0;
    hudScale = readFloat(f,L"HudScale",hudScale); zoomFactor = readFloat(f,L"ZoomFactor",zoomFactor);
    timerSeconds = readInt(f,L"TimerSeconds",timerSeconds);
    crosshairLength = readFloat(f,L"CrosshairLength",crosshairLength);
    crosshairGap = readFloat(f,L"CrosshairGap",crosshairGap);
    crosshairThickness = readFloat(f,L"CrosshairThickness",crosshairThickness);
    crosshairR = readFloat(f,L"CrosshairR",crosshairR);
    crosshairG = readFloat(f,L"CrosshairG",crosshairG);
    crosshairB = readFloat(f,L"CrosshairB",crosshairB);
    crosshairA = readFloat(f,L"CrosshairA",crosshairA);
    loadPos(f,L"Fps",fpsPos); loadPos(f,L"Cps",cpsPos); loadPos(f,L"Wasd",wasdPos);
    loadPos(f,L"Mouse",mousePos); loadPos(f,L"Timer",timerPos); loadPos(f,L"Stopwatch",stopwatchPos);
}
void Settings::Save() const {
    const auto f = FilePath();
    writeInt(f,L"FPS",fps); writeInt(f,L"CPS",cps); writeInt(f,L"WASD",wasd); writeInt(f,L"Mouse",mouse);
    writeInt(f,L"Timer",timer); writeInt(f,L"Stopwatch",stopwatch); writeInt(f,L"Zoom",zoom); writeInt(f,L"HideAll",hideAllHud);
    writeInt(f,L"Animations",animations); writeInt(f,L"HudBackground",hudBackground); writeInt(f,L"HudShadow",hudShadow);
    writeInt(f,L"HideWhenNotMinecraft",hideWhenNotMinecraft); writeInt(f,L"SavePosition",savePosition);
    writeFloat(f,L"HudScale",hudScale); writeFloat(f,L"ZoomFactor",zoomFactor); writeInt(f,L"TimerSeconds",timerSeconds);
    writeFloat(f,L"CrosshairLength",crosshairLength);
    writeFloat(f,L"CrosshairGap",crosshairGap);
    writeFloat(f,L"CrosshairThickness",crosshairThickness);
    writeFloat(f,L"CrosshairR",crosshairR);
    writeFloat(f,L"CrosshairG",crosshairG);
    writeFloat(f,L"CrosshairB",crosshairB);
    writeFloat(f,L"CrosshairA",crosshairA);
    savePos(f,L"Fps",fpsPos); savePos(f,L"Cps",cpsPos); savePos(f,L"Wasd",wasdPos);
    savePos(f,L"Mouse",mousePos); savePos(f,L"Timer",timerPos); savePos(f,L"Stopwatch",stopwatchPos);
}
}
