#pragma once
#include <cstdint>
#include <concepts>
#include <string>
#include <vector>
#include <entt/entt.hpp>

namespace wirza::bedrock {

struct EntityId {
    uint32_t rawId{};
    [[nodiscard]] constexpr bool operator==(const EntityId&) const = default;
    [[nodiscard]] constexpr operator uint32_t() const { return rawId; }
};

struct EntityIdTraits {
    using value_type = EntityId;
    using entity_type = uint32_t;
    using version_type = uint16_t;

    static constexpr entity_type entity_mask = 0x3FFFF;
    static constexpr entity_type version_mask = 0x3FFF;
};

struct IEntityComponent {};

struct ActorEquipmentComponent : IEntityComponent {
    static constexpr uint32_t type_hash = 0xB06141A9;
    void* handContainer{};
    void* armorContainer{};
};

struct HashedStringRaw {
    int64_t hash{};
    std::string string;
    void* lastCompare{};
};

struct ActorDefinitionIdentifier {
    std::string nameSpace;
    std::string identifier;
    std::string initEvent;
    std::string fullName;
    HashedStringRaw canonicalName;
};

struct ActorDefinitionIdentifierComponent : IEntityComponent {
    static constexpr uint32_t type_hash = 0xDEB6534F;
    ActorDefinitionIdentifier identifier;
};

struct AttributeInstanceRaw {
    unsigned char pad[0x78]{};
    float maxValue{};
    float value{};
};

struct BaseAttributeMapRaw {
    std::vector<uint32_t> ids;
    std::vector<AttributeInstanceRaw> instances;
    unsigned char pad[0x20]{};
};

struct AttributesComponent : IEntityComponent {
    static constexpr uint32_t type_hash = 0xFD3B0613;
    BaseAttributeMapRaw baseAttributes{};
};

} // namespace wirza::bedrock

template<>
struct entt::entt_traits<wirza::bedrock::EntityId>
    : entt::basic_entt_traits<wirza::bedrock::EntityIdTraits> {
    static constexpr std::size_t page_size = 2048;
};

template<std::derived_from<wirza::bedrock::IEntityComponent> Type>
struct entt::component_traits<Type, wirza::bedrock::EntityId> {
    using element_type = Type;
    using entity_type = wirza::bedrock::EntityId;
    static constexpr bool in_place_delete = true;
    static constexpr std::size_t page_size = 128 * !std::is_empty_v<Type>;
};

template<typename Type>
struct entt::storage_type<Type, wirza::bedrock::EntityId> {
    using type = entt::basic_storage<Type, wirza::bedrock::EntityId>;
};

template<std::derived_from<wirza::bedrock::IEntityComponent> Type>
struct entt::type_hash<Type> {
    [[nodiscard]] static consteval entt::id_type value() noexcept {
        return Type::type_hash;
    }
    [[nodiscard]] consteval operator entt::id_type() const noexcept { return value(); }
};
