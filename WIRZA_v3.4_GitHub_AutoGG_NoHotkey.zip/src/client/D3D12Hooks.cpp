#include "D3D12Hooks.h"
#include "UI.h"
#include "Settings.h"
#include "LogoTexture.h"
#include "VisualEffects.h"
#include "ColorPostProcess.h"
#include <windows.h>
#include <d3d12.h>
#include <dxgi1_4.h>
#include <wrl/client.h>
#include <MinHook.h>
#include <imgui.h>
#include <backends/imgui_impl_win32.h>
#include <backends/imgui_impl_dx12.h>
#include <vector>
#include <atomic>
#include <mutex>
#include <utility>

using Microsoft::WRL::ComPtr;

namespace wirza {
namespace {
using PresentFn=HRESULT(__stdcall*)(IDXGISwapChain*,UINT,UINT);
using ResizeFn=HRESULT(__stdcall*)(IDXGISwapChain*,UINT,UINT,UINT,DXGI_FORMAT,UINT);
using ExecuteFn=void(__stdcall*)(ID3D12CommandQueue*,UINT,ID3D12CommandList* const*);
PresentFn oPresent=nullptr; ResizeFn oResize=nullptr; ExecuteFn oExecute=nullptr;
void* pPresent=nullptr; void* pResize=nullptr; void* pExecute=nullptr;
std::atomic<ID3D12CommandQueue*> queue{nullptr};

struct Frame { ComPtr<ID3D12CommandAllocator> allocator; ComPtr<ID3D12Resource> buffer; D3D12_CPU_DESCRIPTOR_HANDLE rtv{}; UINT64 fenceValue=0; };
ComPtr<ID3D12Device> device; ComPtr<ID3D12DescriptorHeap> rtvHeap,srvHeap; ComPtr<ID3D12GraphicsCommandList> cmd; ComPtr<ID3D12Fence> fence;
std::vector<Frame> frames;
ComPtr<ID3D12Resource> motionHistory[2];
D3D12_GPU_DESCRIPTOR_HANDLE motionGpu[2]{};
ComPtr<ID3D12Resource> colorSource;
D3D12_GPU_DESCRIPTOR_HANDLE colorGpu{};
bool motionReady[2]{false,false};
bool motionWasRequested=false;
int motionRead=0,motionWrite=1; HANDLE fenceEvent=nullptr; UINT64 nextFence=1; UINT rtvStep=0; DXGI_FORMAT format=DXGI_FORMAT_UNKNOWN; HWND hwnd=nullptr; WNDPROC oldWndProc=nullptr; bool imguiReady=false; std::mutex renderMutex;

void releaseRenderer(){
    if(!imguiReady)return;
    if(oldWndProc&&hwnd)SetWindowLongPtrW(hwnd,GWLP_WNDPROC,reinterpret_cast<LONG_PTR>(oldWndProc)); oldWndProc=nullptr;
    UI::Shutdown(); LogoTexture::Shutdown(); VisualEffects::SetMotionTexture(nullptr,false); ColorPostProcess::Shutdown(); ImGui_ImplDX12_Shutdown(); ImGui_ImplWin32_Shutdown(); ImGui::DestroyContext();
    for(auto& h:motionHistory) h.Reset(); colorSource.Reset(); colorGpu={}; motionReady[0]=motionReady[1]=false; motionWasRequested=false; motionRead=0; motionWrite=1;
    for(auto& f:frames){f.buffer.Reset();f.allocator.Reset();} frames.clear(); cmd.Reset(); rtvHeap.Reset(); srvHeap.Reset(); fence.Reset(); device.Reset();
    if(fenceEvent){CloseHandle(fenceEvent);fenceEvent=nullptr;} hwnd=nullptr; imguiReady=false;
}

LRESULT CALLBACK hookWndProc(HWND h,UINT m,WPARAM w,LPARAM l){ bool handled=false; auto r=UI::WndProc(h,m,w,l,handled); if(handled)return r; return CallWindowProcW(oldWndProc,h,m,w,l); }

bool initRenderer(IDXGISwapChain* sc){
    if(imguiReady)return true; auto q=queue.load(); if(!q)return false;
    DXGI_SWAP_CHAIN_DESC sd{}; if(FAILED(sc->GetDesc(&sd))||!sd.OutputWindow||sd.BufferCount<2)return false;
    if(FAILED(sc->GetDevice(IID_PPV_ARGS(&device))))return false; hwnd=sd.OutputWindow; format=sd.BufferDesc.Format;
    DWORD windowPid=0; GetWindowThreadProcessId(hwnd,&windowPid);
    if(!hwnd || windowPid!=GetCurrentProcessId()) { hwnd=nullptr; return false; }
    D3D12_DESCRIPTOR_HEAP_DESC rh{}; rh.Type=D3D12_DESCRIPTOR_HEAP_TYPE_RTV; rh.NumDescriptors=sd.BufferCount;
    if(FAILED(device->CreateDescriptorHeap(&rh,IID_PPV_ARGS(&rtvHeap))))return false; rtvStep=device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
    D3D12_DESCRIPTOR_HEAP_DESC sh{}; sh.Type=D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV; sh.NumDescriptors=5; sh.Flags=D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
    if(FAILED(device->CreateDescriptorHeap(&sh,IID_PPV_ARGS(&srvHeap))))return false;
    frames.resize(sd.BufferCount); auto rtv=rtvHeap->GetCPUDescriptorHandleForHeapStart();
    for(UINT i=0;i<sd.BufferCount;i++){ if(FAILED(device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,IID_PPV_ARGS(&frames[i].allocator))))return false; if(FAILED(sc->GetBuffer(i,IID_PPV_ARGS(&frames[i].buffer))))return false; frames[i].rtv=rtv; device->CreateRenderTargetView(frames[i].buffer.Get(),nullptr,rtv); rtv.ptr+=rtvStep; }
    if(FAILED(device->CreateCommandList(0,D3D12_COMMAND_LIST_TYPE_DIRECT,frames[0].allocator.Get(),nullptr,IID_PPV_ARGS(&cmd))))return false; cmd->Close();
    if(FAILED(device->CreateFence(0,D3D12_FENCE_FLAG_NONE,IID_PPV_ARGS(&fence))))return false; fenceEvent=CreateEventW(nullptr,FALSE,FALSE,nullptr); if(!fenceEvent)return false;
    IMGUI_CHECKVERSION(); ImGui::CreateContext(); auto& io=ImGui::GetIO(); io.IniFilename=nullptr; io.ConfigFlags|=ImGuiConfigFlags_NavEnableKeyboard;
    const auto srvCpu0=srvHeap->GetCPUDescriptorHandleForHeapStart();
    const auto srvGpu0=srvHeap->GetGPUDescriptorHandleForHeapStart();
    ImGui_ImplWin32_Init(hwnd); ImGui_ImplDX12_Init(device.Get(),static_cast<int>(frames.size()),format,srvHeap.Get(),srvCpu0,srvGpu0);

    const UINT srvStep=device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
    D3D12_CPU_DESCRIPTOR_HANDLE logoCpu=srvCpu0; logoCpu.ptr+=srvStep;
    D3D12_GPU_DESCRIPTOR_HANDLE logoGpu=srvGpu0; logoGpu.ptr+=srvStep;
    LogoTexture::Initialize(device.Get(),q,logoCpu,logoGpu);

    // Alpha 4A motion history. Slots 2/3 are sampled by ImGui next frame.
    // We copy the Minecraft backbuffer before WIRZA draws, so the history does
    // not recursively smear WIRZA HUD/menu elements.
    if(!frames.empty() && frames[0].buffer){
        auto historyDesc=frames[0].buffer->GetDesc();
        historyDesc.Flags=D3D12_RESOURCE_FLAG_NONE;
        D3D12_HEAP_PROPERTIES hp{}; hp.Type=D3D12_HEAP_TYPE_DEFAULT;
        for(int i=0;i<2;++i){
            if(SUCCEEDED(device->CreateCommittedResource(&hp,D3D12_HEAP_FLAG_NONE,&historyDesc,
                    D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE,nullptr,IID_PPV_ARGS(&motionHistory[i])))){
                D3D12_CPU_DESCRIPTOR_HANDLE cpu=srvCpu0; cpu.ptr+=srvStep*(2+i);
                D3D12_GPU_DESCRIPTOR_HANDLE gpu=srvGpu0; gpu.ptr+=srvStep*(2+i);
                D3D12_SHADER_RESOURCE_VIEW_DESC srv{};
                srv.Shader4ComponentMapping=D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
                srv.Format=historyDesc.Format;
                srv.ViewDimension=D3D12_SRV_DIMENSION_TEXTURE2D;
                srv.Texture2D.MipLevels=1;
                device->CreateShaderResourceView(motionHistory[i].Get(),&srv,cpu);
                motionGpu[i]=gpu;
            }
        }
    }

    // Alpha 4B Color Saturation. Slot 4 samples a raw copy of the current
    // Minecraft backbuffer, then a dedicated fullscreen shader writes the
    // corrected image back before WIRZA HUD/menu rendering.
    if(!frames.empty() && frames[0].buffer){
        auto sourceDesc=frames[0].buffer->GetDesc();
        sourceDesc.Flags=D3D12_RESOURCE_FLAG_NONE;
        D3D12_HEAP_PROPERTIES hp{}; hp.Type=D3D12_HEAP_TYPE_DEFAULT;
        if(SUCCEEDED(device->CreateCommittedResource(&hp,D3D12_HEAP_FLAG_NONE,&sourceDesc,
                D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE,nullptr,IID_PPV_ARGS(&colorSource)))){
            D3D12_CPU_DESCRIPTOR_HANDLE cpu=srvCpu0; cpu.ptr+=srvStep*4;
            colorGpu=srvGpu0; colorGpu.ptr+=srvStep*4;
            D3D12_SHADER_RESOURCE_VIEW_DESC srv{};
            srv.Shader4ComponentMapping=D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
            srv.Format=sourceDesc.Format;
            srv.ViewDimension=D3D12_SRV_DIMENSION_TEXTURE2D;
            srv.Texture2D.MipLevels=1;
            device->CreateShaderResourceView(colorSource.Get(),&srv,cpu);
            ColorPostProcess::Initialize(device.Get(),format);
        }
    }

    oldWndProc=reinterpret_cast<WNDPROC>(SetWindowLongPtrW(hwnd,GWLP_WNDPROC,reinterpret_cast<LONG_PTR>(hookWndProc)));
    UI::Initialize(hwnd); imguiReady=true; return true;
}

void waitFrame(Frame& f){ if(!f.fenceValue||fence->GetCompletedValue()>=f.fenceValue)return; fence->SetEventOnCompletion(f.fenceValue,fenceEvent); WaitForSingleObject(fenceEvent,1000); }

void render(IDXGISwapChain* sc){
    std::scoped_lock lock(renderMutex); if(!initRenderer(sc))return; ComPtr<IDXGISwapChain3> sc3; if(FAILED(sc->QueryInterface(IID_PPV_ARGS(&sc3))))return;
    UINT idx=sc3->GetCurrentBackBufferIndex(); if(idx>=frames.size())return; Frame& f=frames[idx]; waitFrame(f); f.allocator->Reset(); cmd->Reset(f.allocator.Get(),nullptr);

    const bool motionRequested=VisualEffects::MotionCaptureRequested();
    if(motionRequested && !motionWasRequested){
        // Avoid blending a stale frame after the module has been disabled for a while.
        motionReady[0]=motionReady[1]=false;
    }
    const bool historyAvailable=motionRequested && motionHistory[motionRead] && motionReady[motionRead];
    VisualEffects::SetMotionTexture(historyAvailable?reinterpret_cast<ImTextureID>(motionGpu[motionRead].ptr):nullptr,historyAvailable);

    ImGui_ImplDX12_NewFrame(); ImGui_ImplWin32_NewFrame(); ImGui::NewFrame(); UI::NewFrame(hwnd); UI::Render(); ImGui::Render();

    const bool colorRequested=ColorPostProcess::Requested() && colorSource && colorGpu.ptr!=0;
    const bool capture=motionRequested && motionHistory[motionWrite];
    ID3D12DescriptorHeap* heaps[]={srvHeap.Get()};
    cmd->SetDescriptorHeaps(1,heaps);

    // Step 1: make the swapchain buffer writable. If Color Saturation is active,
    // first preserve the raw Minecraft frame in colorSource.
    if(colorRequested){
        D3D12_RESOURCE_BARRIER b[2]{};
        b[0].Type=D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        b[0].Transition.pResource=f.buffer.Get();
        b[0].Transition.Subresource=D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        b[0].Transition.StateBefore=D3D12_RESOURCE_STATE_PRESENT;
        b[0].Transition.StateAfter=D3D12_RESOURCE_STATE_COPY_SOURCE;
        b[1].Type=D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        b[1].Transition.pResource=colorSource.Get();
        b[1].Transition.Subresource=D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        b[1].Transition.StateBefore=D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
        b[1].Transition.StateAfter=D3D12_RESOURCE_STATE_COPY_DEST;
        cmd->ResourceBarrier(2,b);
        cmd->CopyResource(colorSource.Get(),f.buffer.Get());
        b[0].Transition.StateBefore=D3D12_RESOURCE_STATE_COPY_SOURCE;
        b[0].Transition.StateAfter=D3D12_RESOURCE_STATE_RENDER_TARGET;
        b[1].Transition.StateBefore=D3D12_RESOURCE_STATE_COPY_DEST;
        b[1].Transition.StateAfter=D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
        cmd->ResourceBarrier(2,b);

        cmd->OMSetRenderTargets(1,&f.rtv,FALSE,nullptr);
        const auto desc=f.buffer->GetDesc();
        ColorPostProcess::Render(cmd.Get(),colorGpu,static_cast<UINT>(desc.Width),desc.Height);
    }else{
        D3D12_RESOURCE_BARRIER b{};
        b.Type=D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        b.Transition.pResource=f.buffer.Get();
        b.Transition.Subresource=D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        b.Transition.StateBefore=D3D12_RESOURCE_STATE_PRESENT;
        b.Transition.StateAfter=D3D12_RESOURCE_STATE_RENDER_TARGET;
        cmd->ResourceBarrier(1,&b);
    }

    // Step 2: motion history captures the already color-corrected Minecraft
    // frame, but still before WIRZA HUD/menu elements are drawn.
    if(capture){
        D3D12_RESOURCE_BARRIER b[2]{};
        b[0].Type=D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        b[0].Transition.pResource=f.buffer.Get();
        b[0].Transition.Subresource=D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        b[0].Transition.StateBefore=D3D12_RESOURCE_STATE_RENDER_TARGET;
        b[0].Transition.StateAfter=D3D12_RESOURCE_STATE_COPY_SOURCE;
        b[1].Type=D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        b[1].Transition.pResource=motionHistory[motionWrite].Get();
        b[1].Transition.Subresource=D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        b[1].Transition.StateBefore=D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
        b[1].Transition.StateAfter=D3D12_RESOURCE_STATE_COPY_DEST;
        cmd->ResourceBarrier(2,b);
        cmd->CopyResource(motionHistory[motionWrite].Get(),f.buffer.Get());
        b[0].Transition.StateBefore=D3D12_RESOURCE_STATE_COPY_SOURCE;
        b[0].Transition.StateAfter=D3D12_RESOURCE_STATE_RENDER_TARGET;
        b[1].Transition.StateBefore=D3D12_RESOURCE_STATE_COPY_DEST;
        b[1].Transition.StateAfter=D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
        cmd->ResourceBarrier(2,b);
    }

    cmd->OMSetRenderTargets(1,&f.rtv,FALSE,nullptr); cmd->SetDescriptorHeaps(1,heaps); ImGui_ImplDX12_RenderDrawData(ImGui::GetDrawData(),cmd.Get());
    D3D12_RESOURCE_BARRIER present{}; present.Type=D3D12_RESOURCE_BARRIER_TYPE_TRANSITION; present.Transition.pResource=f.buffer.Get(); present.Transition.Subresource=D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES; present.Transition.StateBefore=D3D12_RESOURCE_STATE_RENDER_TARGET; present.Transition.StateAfter=D3D12_RESOURCE_STATE_PRESENT; cmd->ResourceBarrier(1,&present);
    cmd->Close(); ID3D12CommandList* lists[]={cmd.Get()}; queue.load()->ExecuteCommandLists(1,lists); UINT64 fv=nextFence++; queue.load()->Signal(fence.Get(),fv); f.fenceValue=fv;

    if(capture){
        motionReady[motionWrite]=true;
        std::swap(motionRead,motionWrite);
    }
    motionWasRequested=motionRequested;
}
HRESULT __stdcall hPresent(IDXGISwapChain* sc,UINT sync,UINT flags){ render(sc); return oPresent(sc,sync,flags); }
HRESULT __stdcall hResize(IDXGISwapChain* sc,UINT bc,UINT w,UINT h,DXGI_FORMAT fmt,UINT fl){ {std::scoped_lock lock(renderMutex); releaseRenderer();} return oResize(sc,bc,w,h,fmt,fl); }
void __stdcall hExecute(ID3D12CommandQueue* q,UINT n,ID3D12CommandList* const* lists){ if(q&&q->GetDesc().Type==D3D12_COMMAND_LIST_TYPE_DIRECT)queue.store(q); oExecute(q,n,lists); }

bool resolveMethods(){
    WNDCLASSEXW wc{sizeof(wc),CS_CLASSDC,DefWindowProcW,0,0,GetModuleHandleW(nullptr),nullptr,nullptr,nullptr,nullptr,L"WIRZA_DUMMY",nullptr}; RegisterClassExW(&wc);
    HWND dw=CreateWindowW(wc.lpszClassName,L"",WS_OVERLAPPEDWINDOW,0,0,100,100,nullptr,nullptr,wc.hInstance,nullptr); if(!dw)return false;
    ComPtr<IDXGIFactory4> factory; ComPtr<ID3D12Device> dev; ComPtr<ID3D12CommandQueue> q; ComPtr<IDXGISwapChain1> s1;
    bool ok=false;
    do{
        if(FAILED(CreateDXGIFactory1(IID_PPV_ARGS(&factory))))break; if(FAILED(D3D12CreateDevice(nullptr,D3D_FEATURE_LEVEL_11_0,IID_PPV_ARGS(&dev))))break;
        D3D12_COMMAND_QUEUE_DESC qd{}; qd.Type=D3D12_COMMAND_LIST_TYPE_DIRECT; if(FAILED(dev->CreateCommandQueue(&qd,IID_PPV_ARGS(&q))))break;
        DXGI_SWAP_CHAIN_DESC1 sd{}; sd.Width=100;sd.Height=100;sd.Format=DXGI_FORMAT_R8G8B8A8_UNORM;sd.SampleDesc.Count=1;sd.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;sd.BufferCount=2;sd.SwapEffect=DXGI_SWAP_EFFECT_FLIP_DISCARD;
        if(FAILED(factory->CreateSwapChainForHwnd(q.Get(),dw,&sd,nullptr,nullptr,&s1)))break;
        auto sv=*reinterpret_cast<void***>(s1.Get()); auto qv=*reinterpret_cast<void***>(q.Get()); pPresent=sv[8];pResize=sv[13];pExecute=qv[10]; ok=pPresent&&pResize&&pExecute;
    }while(false);
    DestroyWindow(dw); UnregisterClassW(wc.lpszClassName,wc.hInstance); return ok;
}
}

bool D3D12Hooks::Install(){
    if(!resolveMethods())return false;
    if(MH_CreateHook(pPresent,reinterpret_cast<void*>(&hPresent),reinterpret_cast<void**>(&oPresent))!=MH_OK)return false;
    if(MH_CreateHook(pResize,reinterpret_cast<void*>(&hResize),reinterpret_cast<void**>(&oResize))!=MH_OK)return false;
    if(MH_CreateHook(pExecute,reinterpret_cast<void*>(&hExecute),reinterpret_cast<void**>(&oExecute))!=MH_OK)return false;
    if(MH_EnableHook(pPresent)!=MH_OK||MH_EnableHook(pResize)!=MH_OK||MH_EnableHook(pExecute)!=MH_OK)return false; return true;
}
void D3D12Hooks::Shutdown(){
    if(pPresent)MH_DisableHook(pPresent); if(pResize)MH_DisableHook(pResize); if(pExecute)MH_DisableHook(pExecute);
    std::scoped_lock lock(renderMutex); releaseRenderer(); queue.store(nullptr);
}

bool D3D12Hooks::RendererReady(){
    return imguiReady && hwnd!=nullptr && queue.load()!=nullptr;
}

const char* D3D12Hooks::CaptureStatus(){
    if(!imguiReady || !hwnd) return "Waiting for Minecraft D3D12 swapchain";
    DWORD pid=0;
    GetWindowThreadProcessId(hwnd,&pid);
    if(pid!=GetCurrentProcessId()) return "Swapchain window mismatch - rendering disabled/unsafe";
    if(!queue.load()) return "Minecraft swapchain found; waiting for D3D12 direct queue";
    return "In-process Minecraft backbuffer; drawn before Present (OBS Game Capture target)";
}
}
