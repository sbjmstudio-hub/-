#pragma once
#include <windows.h>
#include <cstdint>
#include <string_view>
namespace wirza {
uintptr_t FindPattern(HMODULE module, std::string_view pattern);
uintptr_t ResolveRel32(uintptr_t instruction, int displacementOffset, int instructionLength);
bool ReadableAddress(const void* p, size_t bytes=1);
}
