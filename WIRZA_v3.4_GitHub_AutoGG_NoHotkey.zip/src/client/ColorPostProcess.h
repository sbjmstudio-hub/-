#pragma once
#include <d3d12.h>
#include <dxgiformat.h>

namespace wirza {

// Renderer-only post process used by Color Saturation.
// It samples a copy of the Minecraft backbuffer and writes the corrected image
// back into the same swapchain render target. No Minecraft memory is modified.
class ColorPostProcess {
public:
    static bool Initialize(ID3D12Device* device, DXGI_FORMAT renderTargetFormat);
    static void Shutdown();
    static bool Requested();
    static bool Render(ID3D12GraphicsCommandList* cmd, D3D12_GPU_DESCRIPTOR_HANDLE sourceSrv,
                       UINT width, UINT height);
};

}
