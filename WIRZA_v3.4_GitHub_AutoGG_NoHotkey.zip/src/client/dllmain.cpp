#include "ClientCore.h"
#include <windows.h>
DWORD WINAPI WirzaThread(LPVOID module){ return wirza::ClientCore::Run(module); }
BOOL APIENTRY DllMain(HMODULE module,DWORD reason,LPVOID){ if(reason==DLL_PROCESS_ATTACH){ DisableThreadLibraryCalls(module); HANDLE t=CreateThread(nullptr,0,WirzaThread,module,0,nullptr); if(t)CloseHandle(t); } return TRUE; }
