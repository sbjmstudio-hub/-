#pragma once
#include <windows.h>

namespace wirza {

struct InputState {
    bool w=false, a=false, s=false, d=false;
    bool space=false, shift=false, ctrl=false;
    bool left=false, right=false, c=false;
    bool foreground=false;
};

class Input {
public:
    static Input& Get();
    void Update(HWND gameWindow);
    const InputState& State() const { return state_; }
    bool ConsumeRightShiftPressed();

private:
    InputState state_{};
    bool prevRightShift_=false;
    bool rightShiftPressed_=false;
};

}
