#pragma once
#include <atomic>

namespace wirza {

struct FirstPersonMatrix4 {
    // Column-major 4x4 matrix, matching the MatrixRefV1 adapter contract.
    float m[16]{};
};

enum class FirstPersonBridgeState {
    NotInitialized,
    NoVerifiedProfile,
    SignatureMissing,
    HookFailed,
    Ready
};

class FirstPersonRenderBridge {
public:
    static FirstPersonRenderBridge& Get();

    bool Install();
    void Uninstall();

    bool Supported() const { return state_.load() == FirstPersonBridgeState::Ready; }
    FirstPersonBridgeState State() const { return state_.load(); }
    const char* StatusText() const;

    // Exposed so the verified adapter trampoline can apply WIRZA's visual-only
    // transform. This does not modify packets, reach, movement or game state.
    void ApplyTransform(FirstPersonMatrix4& matrix, float partialTick);

private:
    std::atomic<FirstPersonBridgeState> state_{FirstPersonBridgeState::NotInitialized};
    void* target_=nullptr;
};

}
