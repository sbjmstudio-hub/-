#pragma once
#include <chrono>
namespace wirza {
class Countdown {
public:
    void SetDuration(int seconds); void StartPause(); void Reset();
    double Remaining() const; bool Running() const { return running_; }
private:
    using Clock=std::chrono::steady_clock;
    int duration_=600; double stored_=600.0; bool running_=false; Clock::time_point started_=Clock::now();
};
class StopwatchTimer {
public:
    void StartPause(); void Reset(); double Elapsed() const; bool Running() const { return running_; }
private:
    using Clock=std::chrono::steady_clock;
    double stored_=0.0; bool running_=false; Clock::time_point started_=Clock::now();
};
Countdown& Timer(); StopwatchTimer& Stopwatch();
}
