#pragma once
#include "ModuleRegistry.h"
#include <chrono>
#include <string>
#include <utility>
#include <vector>

namespace wirza {

enum class ExtendedFeatureBridgeState {
    NotInitialized,
    NoVerifiedProfile,
    Ready
};

struct ScoreboardSnapshot {
    bool ready=false;
    std::string title;
    std::vector<std::pair<std::string,int>> rows;
};

struct BossBarSnapshot {
    bool ready=false;
    std::string title;
    float progress=0.0f;
};

struct ChatLineSnapshot {
    std::string text;
    std::chrono::system_clock::time_point received{};
};

struct ChatSnapshot {
    bool ready=false;
    std::vector<ChatLineSnapshot> lines;
};

struct TitleSnapshot {
    bool ready=false;
    std::string title;
    std::string subtitle;
    float life01=0.0f;
};

struct PackSnapshot {
    bool ready=false;
    std::string name;
};


struct TwoDItemPolicy { float scale=1.0f, offsetX=0.0f, offsetY=0.0f, rotation=0.0f; };
struct GuiScalePolicy { float scale=1.0f; bool hudOnly=false; };
struct ItemPhysicsPolicy { float rotationSpeed=1.0f, groundTilt=90.0f, bobStrength=0.2f; };
struct KillSoundPolicy { float volume=0.8f; int preset=0; };
struct NickHiderPolicy { bool hideSelf=true, hideOthers=false; std::string replacement="Player"; };
struct PackOrganizerPolicy { bool favoritesFirst=true, compact=false; std::string search; };

struct ParticleVisualPolicy {
    float amount=1.0f;
    float size=1.0f;
    Color4 color{1,1,1,1};
    bool overrideColor=false;
};

// Adapter contract for Bedrock render/UI paths that are highly build-bound.
// Alpha 4G intentionally ships with no guessed signatures. A verified adapter
// can feed these snapshots without changing any module/UI code.
class ExtendedFeatureBridge {
public:
    static ExtendedFeatureBridge& Get();
    bool Install();
    void Uninstall();

    ExtendedFeatureBridgeState State() const { return state_; }
    const char* StatusText() const;

    const ScoreboardSnapshot& Scoreboard() const { return scoreboard_; }
    const BossBarSnapshot& BossBar() const { return bossBar_; }
    const ChatSnapshot& Chat() const { return chat_; }
    const TitleSnapshot& Title() const { return title_; }
    const PackSnapshot& Pack() const { return pack_; }

    ParticleVisualPolicy CurrentParticlePolicy() const;
    TwoDItemPolicy CurrentTwoDItemPolicy() const;
    GuiScalePolicy CurrentGuiScalePolicy() const;
    ItemPhysicsPolicy CurrentItemPhysicsPolicy() const;
    KillSoundPolicy CurrentKillSoundPolicy() const;
    NickHiderPolicy CurrentNickHiderPolicy() const;
    PackOrganizerPolicy CurrentPackOrganizerPolicy() const;

    // Verified build adapters call these setters after observing vanilla data.
    void SetScoreboard(ScoreboardSnapshot value) { scoreboard_=std::move(value); }
    void SetBossBar(BossBarSnapshot value) { bossBar_=std::move(value); }
    void SetChat(ChatSnapshot value) { chat_=std::move(value); }
    void SetTitle(TitleSnapshot value) { title_=std::move(value); }
    void SetPack(PackSnapshot value) { pack_=std::move(value); }

private:
    ExtendedFeatureBridgeState state_=ExtendedFeatureBridgeState::NotInitialized;
    ScoreboardSnapshot scoreboard_{};
    BossBarSnapshot bossBar_{};
    ChatSnapshot chat_{};
    TitleSnapshot title_{};
    PackSnapshot pack_{};
};

}
