#include "RadioPlayer.h"
#include "ModuleRegistry.h"
#include <mfapi.h>
#include <mfplay.h>
#include <objbase.h>
#include <algorithm>

namespace wirza {
namespace {
std::wstring widenUtf8(const std::string& s){
    if(s.empty()) return {};
    int n=MultiByteToWideChar(CP_UTF8,0,s.c_str(),-1,nullptr,0);
    if(n<=1) return {};
    std::wstring w(static_cast<size_t>(n),L'\0');
    MultiByteToWideChar(CP_UTF8,0,s.c_str(),-1,w.data(),n);
    w.resize(static_cast<size_t>(n-1));
    return w;
}
}

RadioPlayer& RadioPlayer::Get(){ static RadioPlayer p; return p; }

bool RadioPlayer::ensureStarted(){
    if(mfStarted_) return true;
    const HRESULT co=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    comInitialized_=SUCCEEDED(co);
    const HRESULT hr=MFStartup(MF_VERSION,MFSTARTUP_FULL);
    if(FAILED(hr)){
        status_="Media Foundation startup failed";
        return false;
    }
    mfStarted_=true;
    return true;
}

bool RadioPlayer::open(const std::string& url){
    Stop();
    if(url.empty()) { status_="Set a direct audio stream URL"; return false; }
    if(!ensureStarted()) return false;
    const auto wide=widenUtf8(url);
    if(wide.empty()) { status_="Invalid station URL"; return false; }

    IMFPMediaPlayer* created=nullptr;
    const HRESULT hr=MFPCreateMediaPlayer(wide.c_str(),TRUE,MFP_OPTION_NONE,nullptr,nullptr,&created);
    if(FAILED(hr) || !created){
        status_="Could not open stream (direct audio URL required)";
        return false;
    }
    player_=created;
    currentUrl_=url;
    const float volume=std::clamp(ModuleRegistry::Get().Float("radio","volume",0.5f),0.0f,1.0f);
    player_->SetVolume(volume);
    status_="Playing";
    return true;
}

bool RadioPlayer::PlayConfigured(){
    return open(ModuleRegistry::Get().Text("radio","station",""));
}

void RadioPlayer::Stop(){
    if(player_){
        player_->Pause();
        player_->Shutdown();
        player_->Release();
        player_=nullptr;
    }
    currentUrl_.clear();
    status_="Stopped";
}

void RadioPlayer::Update(){
    auto& mods=ModuleRegistry::Get();
    auto* m=mods.Find("radio");
    const bool enabled=m && m->enabled;
    if(!enabled){
        if(lastEnabled_) Stop();
        lastEnabled_=false;
        return;
    }

    if(player_){
        player_->SetVolume(std::clamp(mods.Float("radio","volume",0.5f),0.0f,1.0f));
        const auto configured=mods.Text("radio","station","");
        if(!configured.empty() && configured!=currentUrl_ && mods.Bool("radio","autoplay",false)) open(configured);
    }else if(!lastEnabled_ && mods.Bool("radio","autoplay",false)){
        PlayConfigured();
    }
    lastEnabled_=true;
}

void RadioPlayer::Shutdown(){
    Stop();
    if(mfStarted_){ MFShutdown(); mfStarted_=false; }
    if(comInitialized_){ CoUninitialize(); comInitialized_=false; }
}

}
