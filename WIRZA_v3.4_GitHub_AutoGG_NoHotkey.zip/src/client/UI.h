#pragma once
#include <windows.h>
namespace wirza {
class UI {
public:
    static void Initialize(HWND hwnd);
    static void Shutdown();
    static void NewFrame(HWND hwnd);
    static void Render();
    static bool MenuOpen();
    static bool WantsInput();
    static LRESULT WndProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam,bool& handled);
private:
    static void DrawMenu();
    static void DrawHud();
};
}
