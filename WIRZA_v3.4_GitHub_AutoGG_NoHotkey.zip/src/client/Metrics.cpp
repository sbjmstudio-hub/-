#include "Metrics.h"

namespace wirza {

Metrics& Metrics::Get(){ static Metrics m; return m; }

void Metrics::OnFrame(){
    ++frameCount_;
    auto now=Clock::now();
    auto ms=std::chrono::duration_cast<std::chrono::milliseconds>(now-sampleStart_).count();
    if(ms>=500){
        fps_=static_cast<int>((frameCount_*1000.0)/ms+0.5);
        frameCount_=0;
        sampleStart_=now;
    }
}

void Metrics::trim(std::deque<Clock::time_point>& q) const {
    auto cutoff=Clock::now()-std::chrono::seconds(1);
    while(!q.empty() && q.front()<cutoff) q.pop_front();
}

void Metrics::OnInput(bool l,bool r){
    auto now=Clock::now();
    if(l&&!prevLeft_){
        leftClicks_.push_back(now);
        lastLeftClick_=now;
    }
    if(r&&!prevRight_) rightClicks_.push_back(now);

    prevLeft_=l;
    prevRight_=r;
    trim(leftClicks_);
    trim(rightClicks_);
}

int Metrics::LeftCps() const {
    auto& q=const_cast<std::deque<Clock::time_point>&>(leftClicks_);
    trim(q);
    return static_cast<int>(q.size());
}

int Metrics::RightCps() const {
    auto& q=const_cast<std::deque<Clock::time_point>&>(rightClicks_);
    trim(q);
    return static_cast<int>(q.size());
}

double Metrics::SecondsSinceLeftClick() const {
    if(lastLeftClick_.time_since_epoch().count()==0) return 9999.0;
    return std::chrono::duration<double>(Clock::now()-lastLeftClick_).count();
}

}
