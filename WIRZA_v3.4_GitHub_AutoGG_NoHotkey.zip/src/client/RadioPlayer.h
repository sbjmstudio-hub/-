#pragma once
#include <string>
#include <windows.h>

struct IMFPMediaPlayer;

namespace wirza {

class RadioPlayer {
public:
    static RadioPlayer& Get();
    void Update();
    bool PlayConfigured();
    void Stop();
    void Shutdown();
    const char* StatusText() const { return status_.c_str(); }
    bool Playing() const { return player_!=nullptr; }

private:
    bool ensureStarted();
    bool open(const std::string& url);

    IMFPMediaPlayer* player_=nullptr;
    bool mfStarted_=false;
    bool comInitialized_=false;
    bool lastEnabled_=false;
    std::string currentUrl_;
    std::string status_="Idle";
};

}
