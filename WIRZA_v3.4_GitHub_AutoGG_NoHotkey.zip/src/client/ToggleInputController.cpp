#include "ToggleInputController.h"
#include "ModuleRegistry.h"
#include "ServerPolicy.h"

namespace wirza {

ToggleInputController& ToggleInputController::Get(){ static ToggleInputController c; return c; }

bool ToggleInputController::processKey(HWND,UINT msg,WPARAM wp,LPARAM lp,int key,bool enabled,bool& latched){
    if(!enabled || static_cast<int>(wp)!=key) return false;
    if(key==VK_SHIFT && (GetAsyncKeyState(VK_RSHIFT)&0x8000)) return false; // preserve WIRZA menu key

    if(msg==WM_KEYDOWN || msg==WM_SYSKEYDOWN){
        const bool repeat=(lp & (1LL<<30))!=0;
        if(!repeat) latched=!latched;
        return false; // vanilla receives the physical down event
    }
    if(msg==WM_KEYUP || msg==WM_SYSKEYUP){
        // While latched, suppress the physical release so Windows-message based
        // Bedrock input keeps the key held. Second press toggles off, then its
        // release is allowed through. Raw-input builds remain Partial.
        return latched;
    }
    return false;
}

bool ToggleInputController::ProcessWndProc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp){
    auto& mods=ModuleRegistry::Get();
    auto* m=mods.Find("toggle_sneak_sprint");
    if(!m || !m->enabled || !ServerPolicy::Get().AllowedModule(m->id)) return false;
    const int sprint=mods.Int("toggle_sneak_sprint","sprint_key",VK_CONTROL);
    const int sneak=mods.Int("toggle_sneak_sprint","sneak_key",VK_SHIFT);
    if(processKey(hwnd,msg,wp,lp,sprint,mods.Bool("toggle_sneak_sprint","toggle_sprint",true),sprintLatched_)) return true;
    if(processKey(hwnd,msg,wp,lp,sneak,mods.Bool("toggle_sneak_sprint","toggle_sneak",true),sneakLatched_)) return true;
    return false;
}

void ToggleInputController::ReleaseAll(HWND hwnd){
    auto& mods=ModuleRegistry::Get();
    const bool sprintWas=sprintLatched_;
    const bool sneakWas=sneakLatched_;
    // Clear first so our own WndProc filter does not suppress this synthetic release.
    sprintLatched_=false;
    sneakLatched_=false;
    if(sprintWas && hwnd) SendMessageW(hwnd,WM_KEYUP,mods.Int("toggle_sneak_sprint","sprint_key",VK_CONTROL),0xC0000001);
    if(sneakWas && hwnd) SendMessageW(hwnd,WM_KEYUP,mods.Int("toggle_sneak_sprint","sneak_key",VK_SHIFT),0xC0000001);
}

void ToggleInputController::Update(HWND hwnd,bool gameplayActive){
    auto* m=ModuleRegistry::Get().Find("toggle_sneak_sprint");
    const bool active=gameplayActive && m && m->enabled && ServerPolicy::Get().AllowedModule(m->id);
    if(previouslyActive_ && !active) ReleaseAll(hwnd);
    previouslyActive_=active;
}

}
