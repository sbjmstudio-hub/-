#pragma once
#include <array>
#include <string_view>

namespace wirza {

enum class FirstPersonAbi {
    MatrixRefV1
};

// A profile is only added after its exact Minecraft for Windows build has been
// checked on a real Windows machine. Keeping this list empty is intentional:
// an unverified pattern must never be used as a fallback.
struct FirstPersonSignatureProfile {
    std::string_view gameVersion;
    std::string_view pattern;
    bool resolveRel32Call=false;
    int displacementOffset=1;
    int instructionLength=5;
    FirstPersonAbi abi=FirstPersonAbi::MatrixRefV1;
};

inline constexpr std::array<FirstPersonSignatureProfile,0> kVerifiedFirstPersonProfiles{};

inline const FirstPersonSignatureProfile* VerifiedFirstPersonProfileFor(std::string_view gameVersion) {
    for (const auto& profile : kVerifiedFirstPersonProfiles) {
        if (profile.gameVersion == gameVersion) return &profile;
    }
    return nullptr;
}

}
