#include "Input.h"
#include "Metrics.h"

namespace wirza {

Input& Input::Get(){ static Input i; return i; }

static bool down(int vk){ return (GetAsyncKeyState(vk)&0x8000)!=0; }

static bool currentProcessOwnsWindow(HWND hwnd){
    if(!hwnd) return false;
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    return pid != 0 && pid == GetCurrentProcessId();
}

void Input::Update(HWND gameWindow){
    HWND fg = GetForegroundWindow();
    state_.foreground = currentProcessOwnsWindow(fg) || (gameWindow && fg == gameWindow);

    const bool rs=down(VK_RSHIFT);
    rightShiftPressed_=state_.foreground && rs && !prevRightShift_;
    prevRightShift_=rs;

    if(!state_.foreground){
        state_.w=state_.a=state_.s=state_.d=false;
        state_.space=state_.shift=state_.ctrl=false;
        state_.left=state_.right=state_.c=false;
        Metrics::Get().OnInput(false,false);
        return;
    }

    state_.w=down('W');
    state_.a=down('A');
    state_.s=down('S');
    state_.d=down('D');
    state_.space=down(VK_SPACE);
    state_.shift=down(VK_SHIFT);
    state_.ctrl=down(VK_CONTROL);
    state_.left=down(VK_LBUTTON);
    state_.right=down(VK_RBUTTON);
    state_.c=down('C');

    Metrics::Get().OnInput(state_.left,state_.right);
}

bool Input::ConsumeRightShiftPressed(){
    bool v=rightShiftPressed_;
    rightShiftPressed_=false;
    return v;
}

}
