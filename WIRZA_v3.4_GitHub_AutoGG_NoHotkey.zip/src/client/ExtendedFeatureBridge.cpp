#include "ExtendedFeatureBridge.h"
#include "Diagnostics.h"
#include "ExtendedSignatureProfiles.h"
#include <algorithm>

namespace wirza {

ExtendedFeatureBridge& ExtendedFeatureBridge::Get(){
    static ExtendedFeatureBridge b;
    return b;
}

bool ExtendedFeatureBridge::Install(){
    // No signature/ABI is accepted until it has been checked against the exact
    // Minecraft for Windows executable. This keeps UI/particle modules crash-safe.
    const auto version=Diagnostics::Get().GameVersion();
    if(!VerifiedExtendedProfileFor(version)){
        state_=ExtendedFeatureBridgeState::NoVerifiedProfile;
        return false;
    }
    // A profile becomes Ready only when its individual hook ABIs have been
    // implemented and validated on that exact executable.
    state_=ExtendedFeatureBridgeState::Ready;
    return true;
}

void ExtendedFeatureBridge::Uninstall(){
    state_=ExtendedFeatureBridgeState::NotInitialized;
    scoreboard_={}; bossBar_={}; chat_={}; title_={}; pack_={};
}

const char* ExtendedFeatureBridge::StatusText() const {
    switch(state_){
        case ExtendedFeatureBridgeState::NotInitialized: return "Not initialized";
        case ExtendedFeatureBridgeState::NoVerifiedProfile: return "No verified build profile - safe adapter standby";
        case ExtendedFeatureBridgeState::Ready: return "Verified extended feature adapter ready";
    }
    return "Unknown";
}

ParticleVisualPolicy ExtendedFeatureBridge::CurrentParticlePolicy() const {
    ParticleVisualPolicy p{};
    auto& mods=ModuleRegistry::Get();
    auto* m=mods.Find("particle_changer");
    if(!m || !m->enabled) return p;
    p.amount=std::clamp(mods.Float("particle_changer","amount",1.0f),0.0f,3.0f);
    p.size=std::clamp(mods.Float("particle_changer","size",1.0f),0.25f,3.0f);
    p.overrideColor=mods.Bool("particle_changer","override_color",false);
    if(auto* o=mods.Option(*m,"particle_color");o && o->type==OptionType::Color) p.color=o->colorValue;
    return p;
}

TwoDItemPolicy ExtendedFeatureBridge::CurrentTwoDItemPolicy() const {
    auto& m=ModuleRegistry::Get();
    return {m.Float("2d_items","scale",1.0f),m.Float("2d_items","offset_x",0.0f),m.Float("2d_items","offset_y",0.0f),m.Float("2d_items","rotation",0.0f)};
}
GuiScalePolicy ExtendedFeatureBridge::CurrentGuiScalePolicy() const {
    auto& m=ModuleRegistry::Get(); return {m.Float("gui_scale","scale",1.0f),m.Bool("gui_scale","hud_only",false)};
}
ItemPhysicsPolicy ExtendedFeatureBridge::CurrentItemPhysicsPolicy() const {
    auto& m=ModuleRegistry::Get(); return {m.Float("item_physics","rotation_speed",1.0f),m.Float("item_physics","ground_tilt",90.0f),m.Float("item_physics","bob_strength",0.2f)};
}
KillSoundPolicy ExtendedFeatureBridge::CurrentKillSoundPolicy() const {
    auto& m=ModuleRegistry::Get(); auto* mod=m.Find("kill_sounds"); int preset=0; if(mod){ if(auto* o=m.Option(*mod,"sound");o&&o->type==OptionType::Choice)preset=o->choiceIndex; } return {m.Float("kill_sounds","volume",0.8f),preset};
}
NickHiderPolicy ExtendedFeatureBridge::CurrentNickHiderPolicy() const {
    auto& m=ModuleRegistry::Get(); return {m.Bool("nick_hider","hide_self",true),m.Bool("nick_hider","hide_others",false),m.Text("nick_hider","replacement","Player")};
}
PackOrganizerPolicy ExtendedFeatureBridge::CurrentPackOrganizerPolicy() const {
    auto& m=ModuleRegistry::Get(); return {m.Bool("pack_organizer","favorites_first",true),m.Bool("pack_organizer","compact",false),m.Text("pack_organizer","search","")};
}

}
