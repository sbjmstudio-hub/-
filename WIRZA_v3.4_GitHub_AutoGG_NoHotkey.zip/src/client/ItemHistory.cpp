#include "ItemHistory.h"
#include "GameDataBridge.h"
#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <unordered_set>
#include <windows.h>

namespace wirza {
namespace {
std::wstring appDataDir(){
    wchar_t* env=nullptr; size_t len=0;
    if(_wdupenv_s(&env,&len,L"APPDATA")!=0 || !env) return L".";
    std::wstring p(env); free(env); p+=L"\\WIRZA Client";
    std::error_code ec; std::filesystem::create_directories(p,ec); return p;
}
std::string cleanId(std::string id){
    while(!id.empty() && (id.back()=='\r' || id.back()=='\n')) id.pop_back();
    return id;
}
}

ItemHistory& ItemHistory::Get(){ static ItemHistory h; return h; }
std::wstring ItemHistory::filePath() const { return appDataDir()+L"\\item_history.txt"; }

void ItemHistory::Initialize(){
    std::scoped_lock lock(mutex_);
    if(initialized_) return;
    initialized_=true;
    std::ifstream in(std::filesystem::path(filePath()),std::ios::binary);
    std::string line;
    while(std::getline(in,line)){
        line=cleanId(line);
        if(line.empty()) continue;
        if(std::find(items_.begin(),items_.end(),line)==items_.end()) items_.push_back(line);
    }
    std::sort(items_.begin(),items_.end());
}

void ItemHistory::saveUnlocked() const {
    std::ofstream out(std::filesystem::path(filePath()),std::ios::binary|std::ios::trunc);
    for(const auto& id:items_) out<<id<<"\n";
}

void ItemHistory::Refresh(){
    Initialize();
    const auto& bridge=GameDataBridge::Get();
    if(!bridge.InventoryReady()) return;

    std::vector<std::string> seen;
    const auto& p=bridge.Player();
    for(const auto& slot:p.inventory) if(slot.valid && !slot.itemId.empty()) seen.push_back(slot.itemId);
    if(p.heldItem.valid && !p.heldItem.itemId.empty()) seen.push_back(p.heldItem.itemId);
    for(const auto& a:p.armor) if(a.valid && !a.itemId.empty()) seen.push_back(a.itemId);
    if(seen.empty()) return;

    bool changed=false;
    std::scoped_lock lock(mutex_);
    for(auto& id:seen){
        id=cleanId(id);
        if(id.empty()) continue;
        if(std::find(items_.begin(),items_.end(),id)==items_.end()){
            items_.push_back(id); changed=true;
        }
    }
    if(changed){
        std::sort(items_.begin(),items_.end());
        items_.erase(std::unique(items_.begin(),items_.end()),items_.end());
        if(items_.size()>1024) items_.erase(items_.begin(),items_.begin()+(items_.size()-1024));
        saveUnlocked();
    }
}

std::vector<std::string> ItemHistory::Items() const {
    std::scoped_lock lock(mutex_); return items_;
}
bool ItemHistory::Has(const std::string& id) const {
    std::scoped_lock lock(mutex_); return std::find(items_.begin(),items_.end(),id)!=items_.end();
}

}
