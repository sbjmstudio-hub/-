#include "RuntimeStats.h"
#include <windows.h>
#include <psapi.h>
#include <ctime>
#include <cstdio>
namespace wirza {
RuntimeStats& RuntimeStats::Get(){ static RuntimeStats s; return s; }
void RuntimeStats::Initialize(){ started_=Clock::now(); }
double RuntimeStats::PlaytimeSeconds() const {
    return std::chrono::duration<double>(Clock::now()-started_).count();
}
uint64_t RuntimeStats::WorkingSetBytes() const {
    PROCESS_MEMORY_COUNTERS_EX pmc{};
    if(GetProcessMemoryInfo(GetCurrentProcess(), reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&pmc), sizeof(pmc)))
        return static_cast<uint64_t>(pmc.WorkingSetSize);
    return 0;
}
std::string RuntimeStats::ClockText() const {
    std::time_t t=std::time(nullptr);
    std::tm local{};
    localtime_s(&local,&t);
    char b[32]{};
    std::snprintf(b,sizeof(b),"%02d:%02d:%02d",local.tm_hour,local.tm_min,local.tm_sec);
    return b;
}
}
