#pragma once

#include <atomic>
#include <cstddef>
#include <chrono>
#include <mutex>

namespace wirza {

enum class MemoryWriteState {
    NotInitialized,
    Ready,
    FovSignatureMissing,
    HookFailed
};

// Local-only Minecraft memory/render bridge.
//
// This class intentionally limits writes to cosmetic/UI state:
//   - camera/FOV return value (hooked getter)
//   - GuiData scale/reciprocal/size fields
//
// It does not write reach, damage, movement speed, knockback, packets,
// inventory contents, or other server-visible gameplay state.
class MemoryWriteBridge {
public:
    static MemoryWriteBridge& Get();

    bool Install();
    void Shutdown();
    void Tick();

    MemoryWriteState State() const { return state_.load(); }
    bool FovReady() const { return fovReady_.load(); }
    bool GuiScaleReady() const { return guiScaleReady_.load(); }
    bool LightingReady() const { return lightingReady_.load(); }
    const char* StatusText() const;

    // Ratio used only by WIRZA's own world-space overlay projection.
    // 1.0 means no zoom; 0.333 means 30-degree view from a 90-degree base.
    float ZoomProjectionRatio() const { return zoomProjectionRatio_.load(); }

    // When GUI Scale is configured as HUD-only, Minecraft GuiData is left
    // untouched and this multiplier is applied only to WIRZA HUD windows.
    float HudOnlyScale() const;

    // Hook callback policy entry. Public only so the local trampoline can call it.
    float AdjustFov(float vanillaFov);
    float AdjustGamma(float vanillaGamma);

private:
    struct Vec2 { float x=0.0f; float y=0.0f; };

    struct GuiBackup {
        bool valid=false;
        void* gui=nullptr;
        float scale=1.0f;
    };

    bool applyGuiScale();
    void restoreGuiScale();
    bool validateGuiData(void* gui,Vec2& screen,float& scale,float& frac) const;
    static bool writableAddress(const void* p,size_t bytes);
    static bool writeBytes(void* dst,const void* src,size_t bytes);

    std::atomic<MemoryWriteState> state_{MemoryWriteState::NotInitialized};
    std::atomic<bool> fovReady_{false};
    std::atomic<bool> guiScaleReady_{false};
    std::atomic<bool> lightingReady_{false};
    std::atomic<float> zoomProjectionRatio_{1.0f};

    mutable std::mutex guiMutex_;
    GuiBackup guiBackup_{};

    std::mutex fovMutex_;
    bool fovBaselineValid_=false;
    float vanillaBaseline_=90.0f;
    float currentMainFov_=90.0f;
    std::chrono::steady_clock::time_point lastFovTime_{};
};

}
