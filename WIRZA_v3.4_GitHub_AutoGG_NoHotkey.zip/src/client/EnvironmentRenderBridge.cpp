#include "EnvironmentRenderBridge.h"
#include "EnvironmentRenderSignatureProfiles.h"
#include "Diagnostics.h"
#include "ModuleRegistry.h"
#include "PatternScan.h"

#include <MinHook.h>
#include <windows.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <string>

namespace wirza {
namespace {
using FogColorRefV1Fn=EnvironmentColorV1&(__fastcall*)(void*,EnvironmentColorV1&,EnvironmentColorV1 const&,float);
using FogScalarsOpaqueV1Fn=void(__fastcall*)(void*,void*,float);
using OverlayAlphaRefV1Fn=void(__fastcall*)(void*,float&);

FogColorRefV1Fn g_originalFogColor=nullptr;
FogScalarsOpaqueV1Fn g_originalFogScalars=nullptr;
OverlayAlphaRefV1Fn g_originalFireOverlay=nullptr;
OverlayAlphaRefV1Fn g_originalWaterOverlay=nullptr;
OverlayAlphaRefV1Fn g_originalBlockOverlay=nullptr;

EnvironmentRenderBridge* g_bridge=nullptr;
const EnvironmentRenderSignatureProfile* g_profile=nullptr;

Color4 optionColor(const ModuleRegistry& mods,const char* moduleId,const char* key,Color4 fallback){
    const auto* module=mods.Find(moduleId);
    if(!module) return fallback;
    const auto* option=mods.Option(*module,key);
    return (option && option->type==OptionType::Color) ? option->colorValue : fallback;
}

uintptr_t resolveTarget(HMODULE module,std::string_view pattern,bool rel32,int displacementOffset,int instructionLength){
    if(pattern.empty()) return 0;
    uintptr_t result=FindPattern(module,pattern);
    if(!result) return 0;
    if(rel32) result=ResolveRel32(result,displacementOffset,instructionLength);
    if(!ReadableAddress(reinterpret_cast<void*>(result),16)) return 0;
    return result;
}

bool createAndEnable(void* target,void* detour,void** original){
    if(!target || !detour || !original) return false;
    if(MH_CreateHook(target,detour,original)!=MH_OK) return false;
    if(MH_EnableHook(target)!=MH_OK){
        MH_RemoveHook(target);
        *original=nullptr;
        return false;
    }
    return true;
}

void removeHook(void*& target){
    if(target){
        MH_DisableHook(target);
        MH_RemoveHook(target);
        target=nullptr;
    }
}

EnvironmentColorV1& __fastcall hookFogColorRefV1(void* dimension,EnvironmentColorV1& result,
                                                  EnvironmentColorV1 const& baseColor,float brightness){
    EnvironmentColorV1& color=g_originalFogColor
        ? g_originalFogColor(dimension,result,baseColor,brightness)
        : result;
    if(g_bridge) g_bridge->ApplyFogColor(color);
    return color;
}

void __fastcall hookFogScalarsOpaqueV1(void* self,void* fogState,float partialTick){
    if(g_originalFogScalars) g_originalFogScalars(self,fogState,partialTick);
    if(g_bridge && fogState) g_bridge->ApplyFogScalars(fogState);
}

void __fastcall hookFireOverlayAlphaRefV1(void* self,float& opacity){
    // AlphaRefV1 contract: opacity is an input consumed by the verified vanilla
    // renderer, so WIRZA scales it before delegating to vanilla.
    if(g_bridge) g_bridge->ApplyOverlayOpacity(ScreenOverlayKind::Fire,opacity);
    if(g_originalFireOverlay) g_originalFireOverlay(self,opacity);
}
void __fastcall hookWaterOverlayAlphaRefV1(void* self,float& opacity){
    if(g_bridge) g_bridge->ApplyOverlayOpacity(ScreenOverlayKind::Water,opacity);
    if(g_originalWaterOverlay) g_originalWaterOverlay(self,opacity);
}
void __fastcall hookBlockOverlayAlphaRefV1(void* self,float& opacity){
    if(g_bridge) g_bridge->ApplyOverlayOpacity(ScreenOverlayKind::InBlock,opacity);
    if(g_originalBlockOverlay) g_originalBlockOverlay(self,opacity);
}
}

EnvironmentRenderBridge& EnvironmentRenderBridge::Get(){ static EnvironmentRenderBridge b; return b; }

bool EnvironmentRenderBridge::Install(){
    Uninstall();
    state_=EnvironmentRenderBridgeState::NotInitialized;
    g_bridge=this;

    const std::string version=Diagnostics::Get().GameVersion();
    const auto* profile=VerifiedEnvironmentRenderProfileFor(version);
    if(!profile){
        state_=EnvironmentRenderBridgeState::NoVerifiedProfile;
        return false;
    }
    g_profile=profile;

    HMODULE mc=GetModuleHandleW(nullptr);
    if(!mc){
        state_=EnvironmentRenderBridgeState::SignatureMissing;
        return false;
    }

    bool requestedAny=false;
    bool missingAny=false;
    bool hookFailure=false;
    int readyCount=0;
    int requestedCount=0;

    if(!profile->fogColorPattern.empty()){
        requestedAny=true; ++requestedCount;
        const uintptr_t address=resolveTarget(mc,profile->fogColorPattern,profile->fogColorResolveRel32,
            profile->fogColorDisplacementOffset,profile->fogColorInstructionLength);
        if(!address) missingAny=true;
        else if(profile->fogColorAbi!=EnvironmentFogColorAbi::DimensionBrightnessFogColorRefV1) hookFailure=true;
        else{
            fogColorTarget_=reinterpret_cast<void*>(address);
            if(createAndEnable(fogColorTarget_,reinterpret_cast<void*>(&hookFogColorRefV1),
                reinterpret_cast<void**>(&g_originalFogColor))){ fogColorReady_=true; ++readyCount; }
            else{ fogColorTarget_=nullptr; hookFailure=true; }
        }
    }

    if(!profile->fogScalarsPattern.empty()){
        requestedAny=true; ++requestedCount;
        const uintptr_t address=resolveTarget(mc,profile->fogScalarsPattern,profile->fogScalarsResolveRel32,
            profile->fogScalarsDisplacementOffset,profile->fogScalarsInstructionLength);
        if(!address) missingAny=true;
        else if(profile->fogScalarsAbi!=EnvironmentFogScalarsAbi::OpaqueFogStateRefV1) hookFailure=true;
        else{
            fogScalarsTarget_=reinterpret_cast<void*>(address);
            if(createAndEnable(fogScalarsTarget_,reinterpret_cast<void*>(&hookFogScalarsOpaqueV1),
                reinterpret_cast<void**>(&g_originalFogScalars))){ fogScalarsReady_=true; ++readyCount; }
            else{ fogScalarsTarget_=nullptr; hookFailure=true; }
        }
    }

    bool overlayRequested=false;
    if(!profile->fireOverlayPattern.empty()){
        requestedAny=true; overlayRequested=true; ++requestedCount;
        const uintptr_t address=resolveTarget(mc,profile->fireOverlayPattern,profile->fireOverlayResolveRel32,
            profile->fireOverlayDisplacementOffset,profile->fireOverlayInstructionLength);
        if(!address) missingAny=true;
        else if(profile->overlayAbi!=EnvironmentOverlayAbi::AlphaRefV1) hookFailure=true;
        else{
            fireOverlayTarget_=reinterpret_cast<void*>(address);
            if(createAndEnable(fireOverlayTarget_,reinterpret_cast<void*>(&hookFireOverlayAlphaRefV1),
                reinterpret_cast<void**>(&g_originalFireOverlay))) ++readyCount;
            else{ fireOverlayTarget_=nullptr; hookFailure=true; }
        }
    }
    if(!profile->waterOverlayPattern.empty()){
        requestedAny=true; overlayRequested=true; ++requestedCount;
        const uintptr_t address=resolveTarget(mc,profile->waterOverlayPattern,profile->waterOverlayResolveRel32,
            profile->waterOverlayDisplacementOffset,profile->waterOverlayInstructionLength);
        if(!address) missingAny=true;
        else if(profile->overlayAbi!=EnvironmentOverlayAbi::AlphaRefV1) hookFailure=true;
        else{
            waterOverlayTarget_=reinterpret_cast<void*>(address);
            if(createAndEnable(waterOverlayTarget_,reinterpret_cast<void*>(&hookWaterOverlayAlphaRefV1),
                reinterpret_cast<void**>(&g_originalWaterOverlay))) ++readyCount;
            else{ waterOverlayTarget_=nullptr; hookFailure=true; }
        }
    }
    if(!profile->blockOverlayPattern.empty()){
        requestedAny=true; overlayRequested=true; ++requestedCount;
        const uintptr_t address=resolveTarget(mc,profile->blockOverlayPattern,profile->blockOverlayResolveRel32,
            profile->blockOverlayDisplacementOffset,profile->blockOverlayInstructionLength);
        if(!address) missingAny=true;
        else if(profile->overlayAbi!=EnvironmentOverlayAbi::AlphaRefV1) hookFailure=true;
        else{
            blockOverlayTarget_=reinterpret_cast<void*>(address);
            if(createAndEnable(blockOverlayTarget_,reinterpret_cast<void*>(&hookBlockOverlayAlphaRefV1),
                reinterpret_cast<void**>(&g_originalBlockOverlay))) ++readyCount;
            else{ blockOverlayTarget_=nullptr; hookFailure=true; }
        }
    }

    // Overlay is considered ready only if every overlay path that the profile
    // claims to support installed successfully. A profile may intentionally
    // expose just one or two verified overlay paths.
    if(overlayRequested){
        bool ok=true;
        if(!profile->fireOverlayPattern.empty() && !fireOverlayTarget_) ok=false;
        if(!profile->waterOverlayPattern.empty() && !waterOverlayTarget_) ok=false;
        if(!profile->blockOverlayPattern.empty() && !blockOverlayTarget_) ok=false;
        overlayReady_=ok;
    }

    if(!requestedAny){
        state_=EnvironmentRenderBridgeState::NoVerifiedProfile;
        return false;
    }
    if(readyCount==0){
        if(hookFailure) state_=EnvironmentRenderBridgeState::HookFailed;
        else if(missingAny) state_=EnvironmentRenderBridgeState::SignatureMissing;
        else state_=EnvironmentRenderBridgeState::NoVerifiedProfile;
        return false;
    }

    state_=(readyCount==requestedCount && !missingAny && !hookFailure)
        ? EnvironmentRenderBridgeState::Ready
        : EnvironmentRenderBridgeState::PartialReady;
    return true;
}

void EnvironmentRenderBridge::Uninstall(){
    removeHook(fogColorTarget_);
    removeHook(fogScalarsTarget_);
    removeHook(fireOverlayTarget_);
    removeHook(waterOverlayTarget_);
    removeHook(blockOverlayTarget_);
    g_originalFogColor=nullptr;
    g_originalFogScalars=nullptr;
    g_originalFireOverlay=nullptr;
    g_originalWaterOverlay=nullptr;
    g_originalBlockOverlay=nullptr;
    g_profile=nullptr;
    g_bridge=nullptr;
    fogColorReady_=false;
    fogScalarsReady_=false;
    overlayReady_=false;
    state_=EnvironmentRenderBridgeState::NotInitialized;
}

const char* EnvironmentRenderBridge::StatusText() const{
    switch(state_.load()){
        case EnvironmentRenderBridgeState::NotInitialized: return "Not initialized";
        case EnvironmentRenderBridgeState::NoVerifiedProfile: return "Unsupported build - no verified environment-render signature profile";
        case EnvironmentRenderBridgeState::SignatureMissing: return "Verified environment-render signature not found - safely disabled";
        case EnvironmentRenderBridgeState::HookFailed: return "Environment-render hook failed - safely disabled";
        case EnvironmentRenderBridgeState::PartialReady: return "Partial ready (only verified environment render paths active)";
        case EnvironmentRenderBridgeState::Ready: return "Ready (client-only fog / screen-overlay visuals)";
    }
    return "Unknown";
}

void EnvironmentRenderBridge::ApplyFogColor(EnvironmentColorV1& color) const{
    auto& mods=ModuleRegistry::Get();
    const auto* module=mods.Find("fog");
    if(!module || !module->enabled) return;

    const Color4 target=optionColor(mods,"fog","fog_color",{0.75f,0.82f,0.90f,1.0f});
    const float mix=std::clamp(target.a,0.0f,1.0f);
    color.r=std::clamp(color.r+(target.r-color.r)*mix,0.0f,1.0f);
    color.g=std::clamp(color.g+(target.g-color.g)*mix,0.0f,1.0f);
    color.b=std::clamp(color.b+(target.b-color.b)*mix,0.0f,1.0f);
    // Preserve the engine's alpha; fog color customization is RGB-only.
}

void EnvironmentRenderBridge::ApplyFogScalars(void* fogState) const{
    auto& mods=ModuleRegistry::Get();
    const auto* module=mods.Find("fog");
    if(!module || !module->enabled || !fogState || !g_profile) return;

    const float densityScale=std::clamp(mods.Float("fog","density",1.0f),0.0f,2.0f);
    const float startScale=std::clamp(mods.Float("fog","start_scale",1.0f),0.1f,2.0f);
    auto* base=reinterpret_cast<unsigned char*>(fogState);

    float* start=nullptr;
    float* end=nullptr;
    float* density=nullptr;
    if(g_profile->fogStartOffset>=0){
        auto* p=base+g_profile->fogStartOffset;
        if(ReadableAddress(p,sizeof(float))) start=reinterpret_cast<float*>(p);
    }
    if(g_profile->fogEndOffset>=0){
        auto* p=base+g_profile->fogEndOffset;
        if(ReadableAddress(p,sizeof(float))) end=reinterpret_cast<float*>(p);
    }
    if(g_profile->fogDensityOffset>=0){
        auto* p=base+g_profile->fogDensityOffset;
        if(ReadableAddress(p,sizeof(float))) density=reinterpret_cast<float*>(p);
    }

    if(density && std::isfinite(*density)) *density=std::max(0.0f,*density*densityScale);
    if(start && std::isfinite(*start)){
        const float original=*start;
        float adjusted=original*startScale;
        if(end && std::isfinite(*end)) adjusted=std::min(adjusted,*end);
        *start=adjusted;
    }
}

void EnvironmentRenderBridge::ApplyOverlayOpacity(ScreenOverlayKind kind,float& opacity) const{
    auto& mods=ModuleRegistry::Get();
    const auto* module=mods.Find("overlay_mod");
    if(!module || !module->enabled || !std::isfinite(opacity)) return;

    float factor=1.0f;
    switch(kind){
        case ScreenOverlayKind::Fire: factor=mods.Float("overlay_mod","fire_opacity",0.5f); break;
        case ScreenOverlayKind::Water: factor=mods.Float("overlay_mod","water_opacity",0.7f); break;
        case ScreenOverlayKind::InBlock: factor=mods.Float("overlay_mod","block_opacity",0.7f); break;
    }
    factor=std::clamp(factor,0.0f,1.0f);
    // Settings are a multiplier of vanilla opacity: 1 = vanilla, 0 = hidden.
    opacity=std::clamp(opacity,0.0f,1.0f)*factor;
}

} // namespace wirza
