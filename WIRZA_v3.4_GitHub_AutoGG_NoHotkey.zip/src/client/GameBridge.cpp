#include "GameBridge.h"
#include "MemoryWriteBridge.h"

namespace wirza {

bool GameBridge::Install(){
    return MemoryWriteBridge::Get().Install();
}

void GameBridge::Uninstall(){
    MemoryWriteBridge::Get().Shutdown();
}

bool GameBridge::ZoomSupported(){
    return MemoryWriteBridge::Get().FovReady();
}

const char* GameBridge::ZoomStatus(){
    return MemoryWriteBridge::Get().StatusText();
}

float GameBridge::ZoomModifier(){
    return MemoryWriteBridge::Get().ZoomProjectionRatio();
}

void GameBridge::ApplyZoom(void*){
    // Kept for source/API compatibility with older WIRZA batches.
    // Camera FOV is now handled by MemoryWriteBridge's verified getFov hook.
}

}
