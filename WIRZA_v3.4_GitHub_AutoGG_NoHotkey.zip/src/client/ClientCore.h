#pragma once
namespace wirza { class ClientCore { public: static unsigned long Run(void* module); }; }
