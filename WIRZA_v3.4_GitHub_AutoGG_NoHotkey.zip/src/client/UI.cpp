#include "UI.h"
#include "Settings.h"
#include "Metrics.h"
#include "Input.h"
#include "Timers.h"
#include "GameBridge.h"
#include "MemoryWriteBridge.h"
#include "D3D12Hooks.h"
#include "Diagnostics.h"
#include "GameDataBridge.h"
#include "ItemHistory.h"
#include "ServerPolicy.h"
#include "FirstPersonRenderBridge.h"
#include "ItemMaterialRenderBridge.h"
#include "ActorOverlayRenderBridge.h"
#include "EnvironmentRenderBridge.h"
#include "ExtendedFeatureBridge.h"
#include "RadioPlayer.h"
#include "ToggleInputController.h"
#include "AutoGGController.h"
#include "LogoTexture.h"
#include "ModuleRegistry.h"
#include "RuntimeStats.h"
#include "VisualEffects.h"
#include "ProfileManager.h"
#include <imgui.h>
#include <backends/imgui_impl_win32.h>
#include <algorithm>
#include <cstdio>
#include <string>
#include <functional>
#include <cctype>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <sstream>
#include <cmath>

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

namespace wirza {
namespace {
bool g_menu=false; int g_category=0; char g_search[64]{}; bool g_lastMenu=false; char g_profileName[64]="Default"; int g_selectedModule=0;
char g_itemSearch[96]{}; HWND g_gameHwnd=nullptr; float g_menuOpenAnim=0.0f;
std::unordered_map<ImGuiID,float> g_anim;

bool sendEscapeToGame(HWND hwnd){
    if(!hwnd) return false;
    const UINT scan=MapVirtualKeyW(VK_ESCAPE,MAPVK_VK_TO_VSC);
    const LPARAM down=1 | (static_cast<LPARAM>(scan)<<16);
    const LPARAM up=down | (static_cast<LPARAM>(1)<<30) | (static_cast<LPARAM>(1)<<31);
    DWORD_PTR ignored=0;
    const auto flags=SMTO_ABORTIFHUNG|SMTO_BLOCK;
    const LRESULT a=SendMessageTimeoutW(hwnd,WM_KEYDOWN,VK_ESCAPE,down,flags,100,&ignored);
    const LRESULT b=SendMessageTimeoutW(hwnd,WM_KEYUP,VK_ESCAPE,up,flags,100,&ignored);
    return a!=0 && b!=0;
}

void theme(){
    ImGuiStyle& st=ImGui::GetStyle();
    st.WindowRounding=13; st.ChildRounding=9; st.FrameRounding=7; st.PopupRounding=9;
    st.ScrollbarRounding=9; st.GrabRounding=10; st.TabRounding=8;
    st.WindowPadding={14,14}; st.FramePadding={10,7}; st.ItemSpacing={9,9}; st.ItemInnerSpacing={7,6};
    st.WindowBorderSize=1.0f; st.ChildBorderSize=1.0f; st.FrameBorderSize=0.0f;
    auto& c=st.Colors;
    c[ImGuiCol_WindowBg]={0.025f,0.040f,0.065f,0.975f};
    c[ImGuiCol_ChildBg]={0.035f,0.052f,0.080f,0.94f};
    c[ImGuiCol_PopupBg]={0.028f,0.043f,0.070f,0.985f};
    c[ImGuiCol_Border]={0.115f,0.155f,0.225f,0.95f};
    c[ImGuiCol_Text]={0.94f,0.955f,1.0f,1.0f}; c[ImGuiCol_TextDisabled]={0.57f,0.62f,0.72f,1.0f};
    c[ImGuiCol_FrameBg]={0.035f,0.050f,0.075f,1.0f}; c[ImGuiCol_FrameBgHovered]={0.075f,0.070f,0.145f,1.0f}; c[ImGuiCol_FrameBgActive]={0.16f,0.11f,0.32f,1.0f};
    c[ImGuiCol_CheckMark]={0.72f,0.52f,1.0f,1.0f}; c[ImGuiCol_SliderGrab]={0.48f,0.29f,0.92f,1.0f}; c[ImGuiCol_SliderGrabActive]={0.68f,0.43f,1.0f,1.0f};
    c[ImGuiCol_Button]={0.18f,0.12f,0.38f,1.0f}; c[ImGuiCol_ButtonHovered]={0.27f,0.17f,0.56f,1.0f}; c[ImGuiCol_ButtonActive]={0.38f,0.22f,0.78f,1.0f};
    c[ImGuiCol_Header]={0.16f,0.10f,0.34f,1.0f}; c[ImGuiCol_HeaderHovered]={0.25f,0.15f,0.52f,1.0f}; c[ImGuiCol_HeaderActive]={0.35f,0.20f,0.72f,1.0f};
    c[ImGuiCol_Separator]={0.12f,0.16f,0.23f,0.92f};
}



float approach(float current,float target,float speed=14.0f){
    if(!Settings::Get().animations) return target;
    const float dt=std::clamp(ImGui::GetIO().DeltaTime,0.0f,0.05f);
    const float a=1.0f-std::exp(-speed*dt);
    return current+(target-current)*a;
}

float anim(ImGuiID id,float target,float speed=14.0f){
    float& v=g_anim[id]; v=approach(v,target,speed); return v;
}

ImVec4 mix(const ImVec4& a,const ImVec4& b,float t){
    return {a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,a.z+(b.z-a.z)*t,a.w+(b.w-a.w)*t};
}

bool animatedToggle(const char* label,bool* value,bool enabled=true){
    const ImVec2 size{38.0f,21.0f};
    const ImGuiID id=ImGui::GetID(label);
    ImGui::InvisibleButton(label,size);
    bool changed=false;
    if(enabled && ImGui::IsItemClicked()){ *value=!*value; changed=true; }
    const float t=anim(id,*value?1.0f:0.0f,18.0f);
    const float hover=anim(id^0x5A5A5A5Au,ImGui::IsItemHovered()?1.0f:0.0f,18.0f);
    const ImVec2 p=ImGui::GetItemRectMin();
    const ImVec2 q=ImGui::GetItemRectMax();
    auto* dl=ImGui::GetWindowDrawList();
    ImVec4 off={0.15f,0.18f,0.24f,1.0f}, on={0.34f,0.17f,0.85f,1.0f};
    ImVec4 bg=mix(off,on,t); bg=mix(bg,{0.43f,0.25f,0.96f,1.0f},hover*0.20f);
    if(!enabled) bg={0.10f,0.12f,0.16f,0.72f};
    dl->AddRectFilled(p,q,ImGui::ColorConvertFloat4ToU32(bg),size.y*0.5f);
    const float r=8.0f; const float cx=p.x+10.5f+t*(size.x-21.0f);
    dl->AddCircleFilled({cx,p.y+size.y*0.5f},r,IM_COL32(245,247,255,255));
    return changed;
}

bool categoryButton(const char* label,int index){
    ImGui::PushID(index);
    const ImVec2 size{ImGui::GetContentRegionAvail().x,38.0f};
    const ImGuiID id=ImGui::GetID("##cat");
    ImGui::InvisibleButton("##cat",size);
    const bool selected=g_category==index;
    if(ImGui::IsItemClicked()) g_category=index;
    const float active=anim(id,selected?1.0f:0.0f,16.0f);
    const float hover=anim(id^0x77777777u,ImGui::IsItemHovered()?1.0f:0.0f,16.0f);
    const auto p=ImGui::GetItemRectMin(), q=ImGui::GetItemRectMax();
    auto* dl=ImGui::GetWindowDrawList();
    ImVec4 bg=mix({0,0,0,0},{0.23f,0.13f,0.55f,0.96f},active);
    bg=mix(bg,{0.10f,0.09f,0.20f,0.78f},hover*(1.0f-active)*0.75f);
    if(active>0.01f || hover>0.01f) dl->AddRectFilled(p,q,ImGui::ColorConvertFloat4ToU32(bg),7.0f);
    if(active>0.01f) dl->AddRectFilled({p.x,p.y+6},{p.x+2.5f,p.y+q.y-p.y-6},IM_COL32(139,80,255,(int)(255*active)),2.0f);
    dl->AddText({p.x+14,p.y+10},selected?IM_COL32(245,242,255,255):IM_COL32(200,207,224,255),label);
    ImGui::PopID(); return selected;
}

std::vector<std::string> splitItems(const std::string& text){
    std::vector<std::string> out; std::stringstream ss(text); std::string x;
    while(std::getline(ss,x,';')) if(!x.empty() && std::find(out.begin(),out.end(),x)==out.end()) out.push_back(x);
    return out;
}
std::string joinItems(const std::vector<std::string>& items){
    std::string out; for(const auto& x:items){ if(!out.empty())out+=';'; out+=x; } return out;
}
std::string compactItem(std::string id){
    if(id.rfind("minecraft:",0)==0) id.erase(0,10);
    std::replace(id.begin(),id.end(),'_',' '); return id;
}

int moduleUiCategory(const ModuleConfig& m){
    static const std::unordered_set<std::string> pvp{"cps","reach_display","armor_status","totem_counter","potion_counter","hit_color","damage_tint"};
    static const std::unordered_set<std::string> world{"direction_hud","waila","waypoints","server_address","horse_stats","fog"};
    static const std::unordered_set<std::string> move{"toggle_sneak_sprint","momentum","zoom","fov"};
    if(pvp.contains(m.id)) return 3;
    if(world.contains(m.id)) return 4;
    if(move.contains(m.id)) return 5;
    if(m.hud || m.category=="HUD") return 1;
    if(m.category=="Visual" || m.category=="Camera") return 2;
    return 6;
}

bool moduleVisibleInCategory(const ModuleConfig& m){
    if(g_category==0) return true;
    if(g_category>=1 && g_category<=6) return moduleUiCategory(m)==g_category;
    return false;
}

const char* moduleDescription(const ModuleConfig& m){
    if(m.id=="fps") return "Current Minecraft render FPS";
    if(m.id=="cps") return "Click count in the last second";
    if(m.id=="keystrokes") return "Animated keyboard and mouse state";
    if(m.id=="timer") return "Countdown timer";
    if(m.id=="stopwatch") return "Count-up stopwatch";
    if(m.id=="crosshair") return "Custom crosshair overlay";
    if(m.id=="zoom") return "Smooth FOV zoom";
    if(m.id=="gui_scale") return "Minecraft / WIRZA HUD scale";
    if(m.id=="item_counter") return "Choose any item you have owned";
    if(m.id=="direction_hud") return "Top-center animated compass";
    if(m.id=="toggle_sneak_sprint") return "Toggle sprint and sneak";
    if(m.id=="lighting") return "Brightness / gamma";
    if(m.id=="armor_status") return "Your armor and durability";
    if(m.id=="reach_display") return "Display-only last hit distance";
    return "Configurable WIRZA module";
}

bool matchSearch(const char* name){ if(g_search[0]=='\0')return true; std::string a(name),b(g_search); std::transform(a.begin(),a.end(),a.begin(),::tolower); std::transform(b.begin(),b.end(),b.begin(),::tolower); return a.find(b)!=std::string::npos; }

void moduleCard(const char* id,const char* name,const char* desc,bool& value){
    if(!matchSearch(name))return;
    ImGui::PushID(id); ImGui::BeginChild(id,ImVec2(0,78),true,ImGuiWindowFlags_NoScrollbar);
    ImGui::TextUnformatted(name); ImGui::SameLine(ImGui::GetWindowWidth()-56); ImGui::Checkbox("##toggle",&value);
    ImGui::TextDisabled("%s",desc); ImGui::EndChild(); ImGui::PopID();
}


bool drawModuleOption(ModuleOption& o){
    bool changed=false;
    ImGui::PushID(o.key.c_str());
    switch(o.type){
        case OptionType::Bool:
            ImGui::TextUnformatted(o.label.c_str()); ImGui::SameLine(ImGui::GetContentRegionAvail().x-30.0f);
            changed=animatedToggle("##bool",&o.boolValue,true);
            break;
        case OptionType::Float:
            changed=ImGui::SliderFloat(o.label.c_str(),&o.floatValue,o.floatMin,o.floatMax,"%.2f");
            break;
        case OptionType::Int:
            changed=ImGui::SliderInt(o.label.c_str(),&o.intValue,o.intMin,o.intMax);
            break;
        case OptionType::Color: {
            float c[4]{o.colorValue.r,o.colorValue.g,o.colorValue.b,o.colorValue.a};
            if(ImGui::ColorEdit4(o.label.c_str(),c)){
                o.colorValue={c[0],c[1],c[2],c[3]};
                changed=true;
            }
            break;
        }
        case OptionType::Choice: {
            const char* preview=(o.choiceIndex>=0 && o.choiceIndex<(int)o.choices.size())?o.choices[o.choiceIndex].c_str():"";
            if(ImGui::BeginCombo(o.label.c_str(),preview)){
                for(int i=0;i<(int)o.choices.size();++i){
                    const bool selected=i==o.choiceIndex;
                    if(ImGui::Selectable(o.choices[i].c_str(),selected)){o.choiceIndex=i;changed=true;}
                    if(selected)ImGui::SetItemDefaultFocus();
                }
                ImGui::EndCombo();
            }
            break;
        }
        case OptionType::Text: {
            char buf[512]{};
            strncpy_s(buf,o.textValue.c_str(),sizeof(buf)-1);
            if(ImGui::InputText(o.label.c_str(),buf,sizeof(buf))){
                o.textValue=buf; changed=true;
            }
            break;
        }
    }
    ImGui::PopID();
    return changed;
}

void drawHudStyleEditor(ModuleConfig& m){
    if(!m.hud)return;
    ImGui::SeparatorText("HUD appearance");
    ImGui::SliderFloat("HUD scale",&m.hudStyle.scale,0.5f,3.0f,"%.2fx");
    ImGui::SliderFloat("Text size",&m.hudStyle.textSize,0.5f,2.5f,"%.2fx");
    ImGui::SliderFloat("Opacity",&m.hudStyle.opacity,0.1f,1.0f,"%.2f");
    ImGui::SliderFloat("Corner radius",&m.hudStyle.cornerRadius,0.0f,18.0f,"%.1f");
    ImGui::TextUnformatted("Background"); ImGui::SameLine(); animatedToggle("##hudbg",&m.hudStyle.background,true);

    float text[4]{m.hudStyle.textColor.r,m.hudStyle.textColor.g,m.hudStyle.textColor.b,m.hudStyle.textColor.a};
    if(ImGui::ColorEdit4("Text color",text))m.hudStyle.textColor={text[0],text[1],text[2],text[3]};

    float bg[4]{m.hudStyle.backgroundColor.r,m.hudStyle.backgroundColor.g,m.hudStyle.backgroundColor.b,m.hudStyle.backgroundColor.a};
    if(ImGui::ColorEdit4("Background color",bg))m.hudStyle.backgroundColor={bg[0],bg[1],bg[2],bg[3]};

    float accent[4]{m.hudStyle.accentColor.r,m.hudStyle.accentColor.g,m.hudStyle.accentColor.b,m.hudStyle.accentColor.a};
    if(ImGui::ColorEdit4("Accent color",accent))m.hudStyle.accentColor={accent[0],accent[1],accent[2],accent[3]};
}

void registryModuleCard(ModuleConfig& m,int index){
    if(!matchSearch(m.name.c_str()) || !moduleVisibleInCategory(m)) return;
    const bool allowed=ServerPolicy::Get().AllowedModule(m.id);
    ImGui::PushID(m.id.c_str());
    ImGui::BeginChild("##tile",ImVec2(0,94),true,ImGuiWindowFlags_NoScrollbar);
    const auto wp=ImGui::GetWindowPos(); const auto ws=ImGui::GetWindowSize();
    const float hov=anim(ImGui::GetID("##tilehover"),ImGui::IsWindowHovered()?1.0f:0.0f,14.0f);
    if(hov>0.01f) ImGui::GetWindowDrawList()->AddRect(wp,{wp.x+ws.x,wp.y+ws.y},IM_COL32(117,74,238,(int)(110*hov)),8.0f,0,1.3f);

    ImGui::TextUnformatted(m.name.c_str());
    ImGui::SameLine(ImGui::GetWindowWidth()-52.0f);
    ImGui::BeginDisabled(!allowed);
    if(animatedToggle("##enabled",&m.enabled,allowed)) ModuleRegistry::Get().Save();
    ImGui::EndDisabled();
    ImGui::TextDisabled("%s",moduleDescription(m));
    ImGui::SetCursorPosY(ImGui::GetWindowHeight()-26.0f);
    if(!allowed){
        ImGui::TextColored({0.80f,0.60f,1.0f,1.0f},"Server Safe Mode");
    }else{
        ImGui::TextDisabled("%s",ModuleRegistry::Get().StateText(m.state));
    }
    ImGui::SameLine(ImGui::GetWindowWidth()-34.0f);
    if(ImGui::SmallButton("...")){ g_selectedModule=index; }
    if(!allowed && ImGui::IsItemHovered()) ImGui::SetTooltip("%s",ServerPolicy::Get().Reason(m.id));
    ImGui::EndChild(); ImGui::PopID();
}


void placeWindow(const char* name,HudPosition& p, bool editor, float scale, const std::function<void()>& body){
    auto& settings=Settings::Get();
    scale*=MemoryWriteBridge::Get().HudOnlyScale();
    ImGui::SetNextWindowPos({p.x,p.y},ImGuiCond_Once);
    ImGuiWindowFlags f=ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_AlwaysAutoResize|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoFocusOnAppearing;
    if(!editor) f|=ImGuiWindowFlags_NoInputs|ImGuiWindowFlags_NoMove;
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{12*scale,8*scale}); ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,9*scale);
    ImGui::PushStyleColor(ImGuiCol_WindowBg,settings.hudBackground?ImVec4(0.025f,0.045f,0.075f,0.88f):ImVec4(0,0,0,0));
    ImGui::PushStyleColor(ImGuiCol_Border,{0.18f,0.23f,0.34f,0.92f});
    ImGui::Begin(name,nullptr,f); ImGui::SetWindowFontScale(scale);
    if(settings.hudShadow){ const auto a=ImGui::GetWindowPos(), z=ImGui::GetWindowSize(); ImGui::GetBackgroundDrawList()->AddRectFilled({a.x+4,a.y+5},{a.x+z.x+4,a.y+z.y+5},IM_COL32(0,0,0,70),10*scale); }
    body();
    if(editor && settings.savePosition){ auto pos=ImGui::GetWindowPos(); p.x=pos.x; p.y=pos.y; }
    ImGui::End(); ImGui::PopStyleColor(2); ImGui::PopStyleVar(2);
}


void placeModuleWindow(ModuleConfig& m,const char* id,bool edit,const std::function<void()>& fn){
    auto& p=m.hudStyle; auto& settings=Settings::Get();
    const float globalHudScale=MemoryWriteBridge::Get().HudOnlyScale();
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,std::max(8.0f,p.cornerRadius)*globalHudScale);
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha,p.opacity);
    ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(p.textColor.r,p.textColor.g,p.textColor.b,p.textColor.a));
    const bool bg=settings.hudBackground && p.background;
    ImGui::PushStyleColor(ImGuiCol_WindowBg,ImVec4(p.backgroundColor.r,p.backgroundColor.g,p.backgroundColor.b,bg?p.backgroundColor.a:0.0f));
    ImGui::PushStyleColor(ImGuiCol_Border,ImVec4(0.16f,0.21f,0.31f,0.92f));
    ImGui::SetNextWindowPos({p.x,p.y},ImGuiCond_Always); ImGui::SetNextWindowBgAlpha(bg?p.backgroundColor.a:0.0f);
    int flags=ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_AlwaysAutoResize|ImGuiWindowFlags_NoSavedSettings;
    if(!edit) flags|=ImGuiWindowFlags_NoInputs|ImGuiWindowFlags_NoMove;
    ImGui::Begin(id,nullptr,flags); ImGui::SetWindowFontScale(p.textSize*p.scale*globalHudScale);
    if(settings.hudShadow){ const auto a=ImGui::GetWindowPos(), z=ImGui::GetWindowSize(); ImGui::GetBackgroundDrawList()->AddRectFilled({a.x+4,a.y+5},{a.x+z.x+4,a.y+z.y+5},IM_COL32(0,0,0,65),10.0f); }
    fn();
    if(edit && settings.savePosition){ const auto pos=ImGui::GetWindowPos(); p.x=pos.x; p.y=pos.y; }
    ImGui::End(); ImGui::PopStyleColor(3); ImGui::PopStyleVar(2);
}



void keyBox(const char* label,bool down){
    ImGui::PushID(label);
    const ImGuiID id=ImGui::GetID("##key"); const float t=anim(id,down?1.0f:0.0f,22.0f);
    ImVec4 col=mix({0.055f,0.075f,0.11f,0.94f},{0.30f,0.16f,0.70f,1.0f},t);
    ImGui::PushStyleColor(ImGuiCol_Button,col); ImGui::PushStyleColor(ImGuiCol_ButtonHovered,col); ImGui::PushStyleColor(ImGuiCol_ButtonActive,col);
    ImGui::Button(label,{42,36}); ImGui::PopStyleColor(3); ImGui::PopID();
}




Color4 optionColor(ModuleConfig& m,const char* key,Color4 fallback){
    if(auto* o=ModuleRegistry::Get().Option(m,key); o && o->type==OptionType::Color) return o->colorValue;
    return fallback;
}

const char* bearingLabel(int deg){
    deg=(deg%360+360)%360;
    switch(deg){ case 0:return "N"; case 45:return "NE"; case 90:return "E"; case 135:return "SE"; case 180:return "S"; case 225:return "SW"; case 270:return "W"; case 315:return "NW"; default:return nullptr; }
}
void drawCompassHud(ModuleConfig& m){
    auto& bridge=GameDataBridge::Get(); if(!bridge.PlayerReady()) return;
    auto& io=ImGui::GetIO(); auto* dl=ImGui::GetForegroundDrawList();
    float yaw=bridge.Yaw(); while(yaw<0)yaw+=360.0f; while(yaw>=360.0f)yaw-=360.0f;
    float bearing=std::fmod(yaw+180.0f,360.0f); // Minecraft yaw 180 == north
    const float center=io.DisplaySize.x*0.5f; const float y=8.0f+std::max(0.0f,m.hudStyle.y-20.0f);
    const float width=620.0f*m.hudStyle.scale; const float pxPerDeg=width/120.0f;
    dl->AddRectFilled({center-width*0.5f,y},{center+width*0.5f,y+45.0f},IM_COL32(7,17,31,82),8.0f);
    int base=(static_cast<int>(std::floor(bearing/15.0f))*15);
    for(int k=-6;k<=6;++k){
        int deg=(base+k*15)%360; if(deg<0)deg+=360;
        float d=static_cast<float>(deg)-bearing; while(d>180)d-=360; while(d<-180)d+=360;
        const float x=center+d*pxPerDeg; if(x<center-width*0.5f+10 || x>center+width*0.5f-10) continue;
        const bool nearCenter=std::fabs(d)<7.5f;
        const ImU32 col=nearCenter?IM_COL32(169,105,255,255):IM_COL32(226,232,246,(std::abs(k)<=4)?235:135);
        dl->AddLine({x,y+4},{x,y+(deg%45==0?15.0f:10.0f)},col,deg%45==0?2.0f:1.0f);
        char b[16]{}; const char* card=bearingLabel(deg);
        if(card) snprintf(b,sizeof(b),"%s",card); else snprintf(b,sizeof(b),"%d",deg);
        const auto ts=ImGui::CalcTextSize(b); dl->AddText({x-ts.x*0.5f,y+19},col,b);
    }
}

void drawCrosshair(){
    auto* m=ModuleRegistry::Get().Find("crosshair");
    if(!m || !m->enabled || UI::MenuOpen()) return;

    auto& mods=ModuleRegistry::Get();
    auto& io=ImGui::GetIO();
    const ImVec2 c{io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f};

    float length=mods.Float("crosshair","length",8.0f);
    float gap=mods.Float("crosshair","gap",3.0f);
    float thickness=mods.Float("crosshair","thickness",2.0f);
    Color4 color{1,1,1,1};
    if(auto* o=mods.Option(*m,"color");o && o->type==OptionType::Color)color=o->colorValue;

    const ImU32 col=ImGui::ColorConvertFloat4ToU32({color.r,color.g,color.b,color.a});
    auto* dl=ImGui::GetForegroundDrawList();

    dl->AddLine({c.x-gap-length,c.y},{c.x-gap,c.y},col,thickness);
    dl->AddLine({c.x+gap,c.y},{c.x+gap+length,c.y},col,thickness);
    dl->AddLine({c.x,c.y-gap-length},{c.x,c.y-gap},col,thickness);
    dl->AddLine({c.x,c.y+gap},{c.x,c.y+gap+length},col,thickness);
}

std::string fmtTimer(double sec,bool hundredths){
    if(sec<0) sec=0;
    int total=static_cast<int>(sec); int h=total/3600,m=(total%3600)/60,s=total%60; char b[64]{};
    if(hundredths){ int cs=static_cast<int>((sec-total)*100.0); snprintf(b,sizeof(b),"%02d:%02d:%02d.%02d",h,m,s,cs); }
    else if(h>0) snprintf(b,sizeof(b),"%02d:%02d:%02d",h,m,s); else snprintf(b,sizeof(b),"%02d:%02d",m,s);
    return b;
}
}

void UI::Initialize(HWND hwnd){ g_gameHwnd=hwnd; theme(); ModuleRegistry::Get().Initialize(); ItemHistory::Get().Initialize(); Timer().SetDuration(ModuleRegistry::Get().Int("timer","duration_seconds",Settings::Get().timerSeconds)); }
void UI::Shutdown(){ RadioPlayer::Get().Shutdown(); ServerPolicy::Get().RestoreSuppressed(); Settings::Get().Save(); ModuleRegistry::Get().Save(); }
bool UI::MenuOpen(){return g_menu;} bool UI::WantsInput(){return g_menu||Settings::Get().hudEdit;}
void UI::NewFrame(HWND hwnd){
    Input::Get().Update(hwnd); Metrics::Get().OnFrame();
    ServerPolicy::Get().RefreshAndEnforce();
    RadioPlayer::Get().Update();
    AutoGGController::Get().Update(hwnd,Input::Get().State().foreground && !g_menu && !Settings::Get().hudEdit);
    ToggleInputController::Get().Update(hwnd,Input::Get().State().foreground && !g_menu && !Settings::Get().hudEdit);
    if(Input::Get().ConsumeRightShiftPressed()){
        if(!g_menu){
            // Release any latched movement key before WIRZA begins consuming input.
            ToggleInputController::Get().ReleaseAll(hwnd);
            // Open Minecraft's own pause screen first, while WIRZA is not yet
            // consuming keyboard input. The WIRZA panel is then drawn above it.
            sendEscapeToGame(hwnd);
            g_menuOpenAnim=0.0f; g_menu=true;
        }else{
            // Stop consuming input before forwarding ESC so Minecraft can close
            // its native pause screen and return to gameplay.
            g_menu=false;
            Settings::Get().hudEdit=false;
            Settings::Get().Save();
            sendEscapeToGame(hwnd);
        }
    }
    ImGui::GetIO().MouseDrawCursor=g_menu||Settings::Get().hudEdit;
    if(g_menu||Settings::Get().hudEdit){ ClipCursor(nullptr); ReleaseCapture(); }
    if(g_lastMenu&&!g_menu) Settings::Get().Save();
    g_lastMenu=g_menu;
}
LRESULT UI::WndProc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp,bool& handled){
    if(!g_menu && !Settings::Get().hudEdit && ToggleInputController::Get().ProcessWndProc(hwnd,msg,wp,lp)){ handled=true; return 0; }
    // Zoom FOV adjustment works while C is held during gameplay.
    if(msg==WM_MOUSEWHEEL && !g_menu && !Settings::Get().hudEdit){
        auto& mods=ModuleRegistry::Get();
        auto* zoom=mods.Find("zoom");
        const auto& input=Input::Get().State();
        if(zoom && zoom->enabled && input.foreground && input.c){
            auto* target=mods.Option(*zoom,"target_fov");
            auto* step=mods.Option(*zoom,"wheel_step");
            if(target && step && target->type==OptionType::Float && step->type==OptionType::Float){
                const int delta=GET_WHEEL_DELTA_WPARAM(wp);
                target->floatValue += (delta>0 ? -step->floatValue : step->floatValue);
                target->floatValue=std::clamp(target->floatValue,target->floatMin,target->floatMax);
                mods.Save();
                handled=true;
                return 0;
            }
        }
    }

    if(WantsInput()){
        ImGui_ImplWin32_WndProcHandler(hwnd,msg,wp,lp);
        switch(msg){
            case WM_INPUT: case WM_MOUSEMOVE:
            case WM_LBUTTONDOWN: case WM_LBUTTONUP:
            case WM_RBUTTONDOWN: case WM_RBUTTONUP:
            case WM_MOUSEWHEEL:
            case WM_KEYDOWN: case WM_KEYUP: case WM_CHAR:
                handled=true; return 0;
            default: break;
        }
    }
    handled=false;
    return 0;
}

void UI::Render(){ VisualEffects::Render(); if(!g_menu || Settings::Get().hudEdit) DrawHud(); drawCrosshair(); if(g_menu)DrawMenu(); }

void UI::DrawHud(){
    auto& s=Settings::Get();
    if(s.hideAllHud)return;
    const auto& in=Input::Get().State();
    if(s.hideWhenNotMinecraft && !in.foreground && !s.hudEdit) return;
    const float z=s.hudScale;
    auto& mods=ModuleRegistry::Get();

    auto enabled=[&](const char* id,bool fallback=false){
        auto* m=mods.Find(id);
        return m?m->enabled:fallback;
    };

    if(enabled("fps",s.fps)) placeWindow("##WIRZA_FPS",s.fpsPos,s.hudEdit,z,[&]{ ImGui::Text("FPS"); ImGui::TextColored({0.65f,0.35f,1,1},"%d",Metrics::Get().Fps()); });
    if(enabled("cps",s.cps)) placeWindow("##WIRZA_CPS",s.cpsPos,s.hudEdit,z,[&]{ ImGui::Text("CPS"); ImGui::TextColored({0.65f,0.35f,1,1},"%d",Metrics::Get().TotalCps()); });
    if(enabled("keystrokes",s.wasd)) placeWindow("##WIRZA_KEYS",s.wasdPos,s.hudEdit,z,[&]{
        ImGui::Indent(45); keyBox("W",in.w); ImGui::Unindent(45);
        keyBox("A",in.a); ImGui::SameLine(); keyBox("S",in.s); ImGui::SameLine(); keyBox("D",in.d);
        ImGui::Button(in.space?"SPACE *":"SPACE",{130,28});
        ImGui::Text("%s  %s",in.shift?"SHIFT":"shift",in.ctrl?"CTRL":"ctrl");
        ImGui::Text("LMB %d   RMB %d",Metrics::Get().LeftCps(),Metrics::Get().RightCps());
    });
    if(enabled("timer",s.timer)) placeWindow("##WIRZA_TIMER",s.timerPos,s.hudEdit,z,[&]{ ImGui::Text("Timer"); auto t=fmtTimer(Timer().Remaining(),false); ImGui::TextColored({0.66f,0.42f,1,1},"%s",t.c_str()); });
    if(enabled("stopwatch",s.stopwatch)) placeWindow("##WIRZA_STOPWATCH",s.stopwatchPos,s.hudEdit,z,[&]{ ImGui::Text("Stopwatch"); auto t=fmtTimer(Stopwatch().Elapsed(),true); ImGui::TextColored({0.65f,0.35f,1,1},"%s",t.c_str()); });


    if(auto* m=mods.Find("playtime"); m && m->enabled){
        HudPosition p{m->hudStyle.x,m->hudStyle.y};
        placeWindow("##WIRZA_PLAYTIME",p,s.hudEdit,m->hudStyle.scale,[&]{ auto t=fmtTimer(RuntimeStats::Get().PlaytimeSeconds(),false); ImGui::Text("Playtime"); ImGui::Text("%s",t.c_str()); });
        if(s.hudEdit){m->hudStyle.x=p.x;m->hudStyle.y=p.y;}
    }
    if(auto* m=mods.Find("memory_usage"); m && m->enabled){
        HudPosition p{m->hudStyle.x,m->hudStyle.y};
        placeWindow("##WIRZA_MEMORY",p,s.hudEdit,m->hudStyle.scale,[&]{
            const double mib=RuntimeStats::Get().WorkingSetBytes()/(1024.0*1024.0);
            ImGui::Text("Memory"); ImGui::Text("%.0f MiB",mib);
        });
        if(s.hudEdit){m->hudStyle.x=p.x;m->hudStyle.y=p.y;}
    }



    auto& bridge=GameDataBridge::Get();

    if(auto* m=mods.Find("direction_hud"); m && m->enabled && ServerPolicy::Get().AllowedModule(m->id)) drawCompassHud(*m);


    if(auto* m=mods.Find("item_counter"); m && m->enabled && ServerPolicy::Get().AllowedModule(m->id)){
        placeModuleWindow(*m,"##WIRZA_ITEM_COUNTER",s.hudEdit,[&]{
            if(!bridge.InventoryReady()){ ImGui::Text("Item Counter"); ImGui::TextDisabled("Waiting for inventory"); return; }
            auto selected=splitItems(mods.Text("item_counter","selected_items","minecraft:totem_of_undying"));
            const bool showZero=mods.Bool("item_counter","show_zero",true);
            const bool compact=mods.Bool("item_counter","compact_names",true);
            const int warn=mods.Int("item_counter","warn_below",1);
            if(selected.empty()){ ImGui::Text("Item Counter"); ImGui::TextDisabled("Select items in WIRZA menu"); return; }
            int shown=0;
            for(const auto& id:selected){
                const int count=bridge.CountExactItem(id);
                if(!showZero && count==0) continue;
                std::string name=compact?compactItem(id):id;
                if(count<=warn) ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(0.80f,0.58f,1.0f,1.0f));
                ImGui::Text("%s",name.c_str()); ImGui::SameLine(); ImGui::Text("%d",count);
                if(count<=warn) ImGui::PopStyleColor();
                ++shown;
            }
            if(shown==0) ImGui::TextDisabled("No selected items in inventory");
        });
    }


    if(auto* m=mods.Find("totem_counter"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_TOTEM_COUNTER",s.hudEdit,[&]{
            if(!bridge.InventoryReady()){
                ImGui::Text("Totems: --");
            }else{
                const int count=bridge.CountItemContains("totem");
                ImGui::Text("Totems: %d",count);
            }
        });
    }

    if(auto* m=mods.Find("potion_counter"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_POTION_COUNTER",s.hudEdit,[&]{
            if(!bridge.InventoryReady()){
                ImGui::Text("Potions: --");
            }else{
                ImGui::Text("Potions: %d",bridge.CountItemContains("potion"));
            }
        });
    }


    if(auto* m=mods.Find("armor_status"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_ARMOR_STATUS",s.hudEdit,[&]{
            if(!bridge.ArmorReady()){
                ImGui::Text("Armor: --");
                ImGui::TextDisabled("Waiting for armor data");
            }else{
                const bool showDur=mods.Bool("armor_status","show_durability",true);
                const int low=mods.Int("armor_status","low_durability",20);
                const bool vertical=([&]{
                    auto* o=mods.Option(*m,"layout");
                    return o && o->type==OptionType::Choice && o->choiceIndex==1;
                })();

                int shown=0;
                for(int i=0;i<4;++i){
                    const auto& a=bridge.Player().armor[i];
                    if(!a.valid) continue;
                    const std::string label=!a.itemId.empty()?a.itemId:a.translateName;
                    if(!vertical && shown>0) ImGui::SameLine();
                    if(showDur && a.maxDamage>0){
                        const bool warn=a.durabilityPercent<=low;
                        if(warn) ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(1.0f,0.25f,0.2f,1.0f));
                        ImGui::Text("%s %.0f%%",label.c_str(),a.durabilityPercent);
                        if(warn) ImGui::PopStyleColor();
                    }else{
                        ImGui::Text("%s",label.c_str());
                    }
                    ++shown;
                }
                if(mods.Bool("armor_status","show_held_item",true) && bridge.Player().heldItem.valid){
                    if(!vertical && shown>0) ImGui::SameLine();
                    ImGui::Text("Hand: %s",bridge.Player().heldItem.itemId.c_str());
                }
                if(shown==0) ImGui::Text("Armor: none");
            }
        });
    }

    if(auto* m=mods.Find("ping"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_PING",s.hudEdit,[&]{
            if(!bridge.NetworkReady()){
                ImGui::Text("Ping: --");
            }else{
                ImGui::Text("Ping: %d%s",bridge.Network().pingMs,
                    mods.Bool("ping","show_ms",true) ? " ms" : "");
            }
        });
    }

    if(auto* m=mods.Find("server_address"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_SERVER",s.hudEdit,[&]{
            if(!bridge.NetworkReady()){
                ImGui::Text("Server: Local / --");
            }else{
                const auto& n=bridge.Network();
                std::string text;
                if(mods.Bool("server_address","prefer_hostname",true) && !n.unresolvedUrl.empty())
                    text=n.unresolvedUrl;
                else if(!n.hostIp.empty()) text=n.hostIp;
                else text=n.unresolvedUrl;

                if(!mods.Bool("server_address","hide_port",false) && n.port>0)
                    text += ":"+std::to_string(n.port);

                ImGui::Text("Server: %s",text.c_str());
                if(!n.region.empty()) ImGui::TextDisabled("%s",n.region.c_str());
            }
        });
    }

    if(auto* m=mods.Find("reach_display"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_REACH",s.hudEdit,[&]{
            const int timeout=mods.Int("reach_display","timeout_ms",2500);
            const int decimals=mods.Int("reach_display","decimals",2);
            if(!bridge.HasRecentReach(timeout)){
                ImGui::Text("Reach: --");
            }else{
                ImGui::Text(("Reach: %."+std::to_string(decimals)+"f%s").c_str(),
                    bridge.LastReach(),
                    mods.Bool("reach_display","show_blocks_suffix",true) ? " blocks" : "");
            }
        });
    }

    if(auto* m=mods.Find("waila"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_WAILA",s.hudEdit,[&]{
            if(!bridge.TargetReady()){
                ImGui::Text("WAILA: --");
            }else{
                const auto& t=bridge.Target();
                if(t.type==TargetType::Block && mods.Bool("waila","show_block",true)){
                    ImGui::Text("%s",t.name.c_str());
                    if(!t.identifier.empty()) ImGui::TextDisabled("%s",t.identifier.c_str());
                }else if(t.type==TargetType::Entity && mods.Bool("waila","show_entity",true)){
                    ImGui::Text("%s",t.name.c_str());
                    if(!t.identifier.empty()) ImGui::TextDisabled("%s",t.identifier.c_str());
                }else{
                    ImGui::Text("WAILA: hidden by settings");
                }
                if(mods.Bool("waila","show_distance",false))
                    ImGui::Text("%.2f blocks",t.distance);
            }
        });
    }

    if(auto* m=mods.Find("horse_stats"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_HORSE",s.hudEdit,[&]{
            if(!bridge.Horse().valid){
                ImGui::Text("Horse: --");
                ImGui::TextDisabled("Look at a horse");
            }else{
                const auto& h=bridge.Horse();
                ImGui::Text("%s",h.identifier.c_str());
                if(mods.Bool("horse_stats","show_health",true)){
                    if(h.health>=0.0f) ImGui::Text("Health: %.1f / %.1f",h.health,h.maxHealth);
                    else ImGui::TextDisabled("Health: adapter pending");
                }
                if(mods.Bool("horse_stats","show_speed",true))
                    ImGui::TextDisabled("Speed stat: adapter pending");
                if(mods.Bool("horse_stats","show_jump",true))
                    ImGui::TextDisabled("Jump stat: adapter pending");
            }
        });
    }

    if(auto* m=mods.Find("potion_effects"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_EFFECTS",s.hudEdit,[&]{
            if(!bridge.PotionEffectsReady()){
                ImGui::Text("Potion Effects");
                ImGui::TextDisabled("Unsupported by current verified adapter");
            }else if(bridge.PotionEffects().empty()){
                ImGui::Text("Potion Effects: none");
            }else{
                for(const auto& e:bridge.PotionEffects()){
                    ImGui::Text("%s %d",e.name.c_str(),e.amplifier+1);
                }
            }
        });
    }

    auto& ext=ExtendedFeatureBridge::Get();
    if(auto* m=mods.Find("scoreboard"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_SCOREBOARD",s.hudEdit,[&]{
            const auto& snap=ext.Scoreboard();
            if(!snap.ready){ ImGui::Text("Scoreboard"); ImGui::TextDisabled("Adapter pending"); return; }
            ImGui::TextUnformatted(snap.title.c_str()); ImGui::Separator();
            const bool hide=mods.Bool("scoreboard","hide_numbers",false);
            for(const auto& row:snap.rows){ if(hide) ImGui::Text("%s",row.first.c_str()); else ImGui::Text("%s  %d",row.first.c_str(),row.second); }
        });
    }
    if(auto* m=mods.Find("boss_bar"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_BOSSBAR",s.hudEdit,[&]{
            const auto& snap=ext.BossBar();
            if(!snap.ready){ ImGui::Text("Boss Bar"); ImGui::TextDisabled("Adapter pending"); return; }
            ImGui::TextUnformatted(snap.title.c_str());
            const auto c=optionColor(*m,"bar_color",{0.65f,0.35f,1.0f,1.0f});
            ImGui::PushStyleColor(ImGuiCol_PlotHistogram,{c.r,c.g,c.b,c.a});
            ImGui::ProgressBar(std::clamp(snap.progress,0.0f,1.0f),{260.0f*mods.Float("boss_bar","scale",1.0f),0});
            ImGui::PopStyleColor();
        });
    }
    if(auto* m=mods.Find("chat_mod"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_CHAT",s.hudEdit,[&]{
            const auto& snap=ext.Chat();
            if(!snap.ready){ ImGui::Text("Chat Mod"); ImGui::TextDisabled("Adapter pending"); return; }
            const bool timestamps=mods.Bool("chat_mod","timestamps",false);
            const int start=std::max(0,(int)snap.lines.size()-8);
            for(int i=start;i<(int)snap.lines.size();++i){
                if(timestamps){
                    std::time_t tt=std::chrono::system_clock::to_time_t(snap.lines[i].received); std::tm tm{}; localtime_s(&tm,&tt);
                    char tb[16]{}; std::strftime(tb,sizeof(tb),"%H:%M",&tm); ImGui::TextDisabled("[%s]",tb); ImGui::SameLine();
                }
                ImGui::TextWrapped("%s",snap.lines[i].text.c_str());
            }
        });
    }
    if(auto* m=mods.Find("titles"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_TITLES",s.hudEdit,[&]{
            const auto& snap=ext.Title();
            if(!snap.ready){ ImGui::Text("Titles"); ImGui::TextDisabled("Adapter pending"); return; }
            const auto c=optionColor(*m,"title_color",{1,1,1,1});
            ImGui::PushStyleColor(ImGuiCol_Text,{c.r,c.g,c.b,c.a*mods.Float("titles","opacity",1.0f)});
            ImGui::SetWindowFontScale(m->hudStyle.textSize*m->hudStyle.scale*mods.Float("titles","scale",1.0f));
            ImGui::TextUnformatted(snap.title.c_str()); if(!snap.subtitle.empty()) ImGui::TextDisabled("%s",snap.subtitle.c_str());
            ImGui::PopStyleColor();
        });
    }
    if(auto* m=mods.Find("pack_display"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_PACK",s.hudEdit,[&]{
            const auto& snap=ext.Pack();
            if(!snap.ready){ ImGui::Text("Pack"); ImGui::TextDisabled("Adapter pending"); return; }
            if(mods.Bool("pack_display","show_name",true)){
                auto name=snap.name; const int mx=mods.Int("pack_display","max_name",32); if((int)name.size()>mx) name=name.substr(0,mx)+"...";
                ImGui::Text("Pack: %s",name.c_str());
            }
        });
    }

}

void UI::DrawMenu(){
    auto& settings=Settings::Get(); auto& io=ImGui::GetIO(); auto& mods=ModuleRegistry::Get();
    g_menuOpenAnim=approach(g_menuOpenAnim,1.0f,12.0f);

    auto* menuBlur=mods.Find("menu_blur");
    if(!menuBlur || !menuBlur->enabled){
        const int a=static_cast<int>(105.0f*g_menuOpenAnim);
        ImGui::GetBackgroundDrawList()->AddRectFilled({0,0},io.DisplaySize,IM_COL32(2,6,13,a));
    }

    ImVec2 target{1220.f,720.f};
    target.x=std::min(target.x,std::max(720.f,io.DisplaySize.x-36.f));
    target.y=std::min(target.y,std::max(520.f,io.DisplaySize.y-36.f));
    const float sc=0.965f+0.035f*g_menuOpenAnim;
    ImVec2 panel{target.x*sc,target.y*sc};
    ImGui::SetNextWindowPos({io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f},ImGuiCond_Always,{0.5f,0.5f});
    ImGui::SetNextWindowSize(panel,ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(0.975f);
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha,0.65f+0.35f*g_menuOpenAnim);
    ImGui::Begin("##WIRZA_CLIENT_MENU",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoSavedSettings);

    // Header matching the supplied dark/navy + purple reference.
    ImGui::BeginChild("##header",{0,46},false,ImGuiWindowFlags_NoScrollbar);
    if(LogoTexture::Ready()){ ImGui::Image(LogoTexture::Id(),{28,28}); ImGui::SameLine(); }
    ImGui::SetCursorPosY(12.0f); ImGui::Text("WIRZA CLIENT MENU");
    ImGui::SameLine(); ImGui::TextColored({0.62f,0.43f,1.0f,1.0f},"  v3.4");
    const char* server=ServerPolicy::Get().ServerName();
    ImGui::SameLine(ImGui::GetWindowWidth()-430.0f);
    if(ServerPolicy::Get().IsProtectedServer()) ImGui::TextColored({0.72f,0.52f,1.0f,1.0f},"Server Safe: %s",server);
    else ImGui::TextDisabled("%s",server);
    ImGui::SameLine(ImGui::GetWindowWidth()-184.0f); ImGui::TextDisabled("Right Shift: close");
    ImGui::SameLine(ImGui::GetWindowWidth()-34.0f);
    if(ImGui::SmallButton("X")){
        g_menu=false; settings.hudEdit=false; settings.Save();
        if(g_gameHwnd) sendEscapeToGame(g_gameHwnd);
    }
    ImGui::EndChild();
    ImGui::Separator();

    const float sidebar=190.0f;
    ImGui::BeginChild("##sidebar",{sidebar,0},false);
    ImGui::TextDisabled("MODULES");
    categoryButton("All Modules",0); categoryButton("HUD",1); categoryButton("Visual",2);
    categoryButton("PvP",3); categoryButton("World",4); categoryButton("Movement",5); categoryButton("Misc",6);
    ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();
    categoryButton("Profiles",7); categoryButton("Settings",8);

    ImGui::SetCursorPosY(std::max(ImGui::GetCursorPosY(),ImGui::GetWindowHeight()-128.0f));
    ImGui::Separator();
    ImGui::TextDisabled("OBS GAME CAPTURE");
    ImGui::TextWrapped("%s",D3D12Hooks::RendererReady()?"Minecraft backbuffer active":"Waiting for Minecraft D3D12");
    if(ServerPolicy::Get().IsProtectedServer()){
        ImGui::TextColored({0.67f,0.45f,1.0f,1.0f},"Safe Mode locked ON");
    }
    ImGui::EndChild(); ImGui::SameLine();

    ImGui::BeginChild("##main",{0,0},false);

    if(g_category==7){
        ImGui::Text("Profiles"); ImGui::TextDisabled("Save a complete WIRZA layout and module configuration.");
        ImGui::Spacing(); ImGui::SetNextItemWidth(280); ImGui::InputText("Profile name",g_profileName,sizeof(g_profileName));
        if(ImGui::Button("Save profile",{120,34})){ settings.Save(); mods.Save(); ProfileManager::Get().SaveProfile(g_profileName); }
        ImGui::SameLine(); if(ImGui::Button("Load profile",{120,34})) ProfileManager::Get().LoadProfile(g_profileName);
        ImGui::SameLine(); if(ImGui::Button("Delete profile",{120,34})) ProfileManager::Get().DeleteProfile(g_profileName);
        ImGui::SeparatorText("Saved profiles");
        auto profiles=ProfileManager::Get().ListProfiles();
        if(profiles.empty()) ImGui::TextDisabled("No saved profiles yet.");
        for(const auto& p:profiles){
            ImGui::BeginChild(("##profile_"+p).c_str(),{0,42},true); ImGui::TextUnformatted(p.c_str()); ImGui::SameLine(ImGui::GetWindowWidth()-110);
            if(ImGui::SmallButton(("Load##"+p).c_str())){ strncpy_s(g_profileName,p.c_str(),sizeof(g_profileName)-1); ProfileManager::Get().LoadProfile(p); }
            ImGui::EndChild();
        }
        ImGui::EndChild(); ImGui::End(); ImGui::PopStyleVar(); return;
    }

    if(g_category==8){
        ImGui::Text("Settings"); ImGui::TextDisabled("WIRZA UI, HUD and capture behavior");
        ImGui::SeparatorText("HUD / Animation");
        auto settingToggle=[&](const char* label,bool& v,const char* help){
            ImGui::BeginChild((std::string("##set_")+label).c_str(),{0,46},true);
            ImGui::TextUnformatted(label); if(help){ImGui::SameLine();ImGui::TextDisabled("  %s",help);} ImGui::SameLine(ImGui::GetWindowWidth()-55);
            if(animatedToggle("##v",&v,true)) settings.Save();
            ImGui::EndChild();
        };
        settingToggle("HUD Editor",settings.hudEdit,"drag HUD modules");
        settingToggle("HUD Background",settings.hudBackground,"dark translucent cards");
        settingToggle("HUD Shadow",settings.hudShadow,"soft card shadow");
        settingToggle("Hide when not in Minecraft",settings.hideWhenNotMinecraft,"only draw while game is active");
        settingToggle("Save Position",settings.savePosition,"remember dragged HUD positions");
        settingToggle("Animations",settings.animations,"menu, switches and key transitions");
        ImGui::SetNextItemWidth(280); if(ImGui::SliderFloat("Global HUD Scale",&settings.hudScale,0.60f,2.00f,"%.2fx")) settings.Save();
        ImGui::SeparatorText("Timer / Stopwatch");
        auto* timerMod=mods.Find("timer");
        int timerSec=mods.Int("timer","duration_seconds",600);
        int mins=timerSec/60, secs=timerSec%60;
        ImGui::SetNextItemWidth(90); ImGui::InputInt("Minutes",&mins); ImGui::SameLine(); ImGui::SetNextItemWidth(90); ImGui::InputInt("Seconds",&secs);
        mins=std::clamp(mins,0,999); secs=std::clamp(secs,0,59); int total=std::max(1,mins*60+secs);
        if(timerMod){ if(auto* o=mods.Option(*timerMod,"duration_seconds"); o && o->intValue!=total){ o->intValue=total; Timer().SetDuration(total); mods.Save(); } }
        if(ImGui::Button(Timer().Running()?"Pause Timer":"Start Timer")) Timer().StartPause();
        ImGui::SameLine(); if(ImGui::Button("Reset Timer")) Timer().Reset();
        ImGui::SameLine(); if(ImGui::Button(Stopwatch().Running()?"Pause Stopwatch":"Start Stopwatch")) Stopwatch().StartPause();
        ImGui::SameLine(); if(ImGui::Button("Reset Stopwatch")) Stopwatch().Reset();
        ImGui::SeparatorText("Diagnostics");
        ImGui::Text("OBS: %s",D3D12Hooks::CaptureStatus());
        ImGui::Text("Game data: %s",GameDataBridge::Get().StateText());
        ImGui::Text("Memory bridge: %s",MemoryWriteBridge::Get().StatusText());
        ImGui::Text("Server policy: %s",ServerPolicy::Get().ServerName());
        if(ImGui::Button("Reset HUD positions")){
            settings.fpsPos={20,20};settings.cpsPos={20,72};settings.wasdPos={20,124};settings.mousePos={20,250};settings.timerPos={20,330};settings.stopwatchPos={20,385}; settings.Save();
        }
        ImGui::EndChild(); ImGui::End(); ImGui::PopStyleVar(); return;
    }

    ImGui::Text(g_category==0?"All Modules":g_category==1?"HUD":g_category==2?"Visual":g_category==3?"PvP":g_category==4?"World":g_category==5?"Movement":"Misc");
    ImGui::SameLine(ImGui::GetWindowWidth()-365.0f); ImGui::SetNextItemWidth(235); ImGui::InputTextWithHint("##search","Search modules...",g_search,sizeof(g_search));
    ImGui::SameLine(); if(ImGui::Button("Save",{92,0})){ settings.Save(); mods.Save(); }

    ImGui::Spacing();
    ImGui::BeginChild("##module_grid",{0,355},false);
    if(ImGui::BeginTable("##grid",4,ImGuiTableFlags_SizingStretchSame|ImGuiTableFlags_PadOuterX)){
        int visible=0;
        auto& all=mods.All();
        for(int i=0;i<(int)all.size();++i){
            auto& m=all[i]; if(!matchSearch(m.name.c_str()) || !moduleVisibleInCategory(m)) continue;
            ImGui::TableNextColumn(); registryModuleCard(m,i); ++visible;
        }
        ImGui::EndTable();
        if(visible==0) ImGui::TextDisabled("No modules match this category/search.");
    }
    ImGui::EndChild();

    ImGui::SeparatorText("Module Settings");
    auto& all=mods.All();
    if(!all.empty()){
        g_selectedModule=std::clamp(g_selectedModule,0,(int)all.size()-1);
        auto& selected=all[g_selectedModule]; const bool allowed=ServerPolicy::Get().AllowedModule(selected.id);
        ImGui::TextUnformatted(selected.name.c_str()); ImGui::SameLine(); ImGui::TextDisabled("%s",ModuleRegistry::Get().StateText(selected.state));
        ImGui::SameLine(ImGui::GetWindowWidth()-55.0f); ImGui::BeginDisabled(!allowed); if(animatedToggle("##selected_enabled",&selected.enabled,allowed)) mods.Save(); ImGui::EndDisabled();
        ImGui::TextDisabled("%s",moduleDescription(selected));
        if(!allowed) ImGui::TextColored({0.75f,0.52f,1.0f,1.0f},"%s",ServerPolicy::Get().Reason(selected.id));

        if(selected.hud) drawHudStyleEditor(selected);

        bool changed=false;
        if(selected.id=="item_counter"){
            ImGui::SeparatorText("Tracked items - discovered from your inventory");
            ImGui::SetNextItemWidth(260); ImGui::InputTextWithHint("##itemsearch","Search items...",g_itemSearch,sizeof(g_itemSearch));
            auto* selectedOpt=mods.Option(selected,"selected_items");
            std::vector<std::string> chosen=selectedOpt?splitItems(selectedOpt->textValue):std::vector<std::string>{};
            auto items=ItemHistory::Get().Items();
            for(const auto& c:chosen) if(std::find(items.begin(),items.end(),c)==items.end()) items.push_back(c);
            std::sort(items.begin(),items.end());
            ImGui::BeginChild("##item_picker",{0,145},true);
            if(items.empty()) ImGui::TextDisabled("Pick up or hold items in Minecraft; they will appear here automatically.");
            std::string q=compactItem(g_itemSearch); std::transform(q.begin(),q.end(),q.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
            for(const auto& id:items){
                std::string display=compactItem(id), low=display; std::transform(low.begin(),low.end(),low.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
                if(!q.empty() && low.find(q)==std::string::npos && id.find(g_itemSearch)==std::string::npos) continue;
                bool on=std::find(chosen.begin(),chosen.end(),id)!=chosen.end();
                ImGui::PushID(id.c_str()); ImGui::TextUnformatted(display.c_str()); ImGui::SameLine(ImGui::GetWindowWidth()-52.0f);
                if(animatedToggle("##pick",&on,true)){
                    auto it=std::find(chosen.begin(),chosen.end(),id);
                    if(on && it==chosen.end()) chosen.push_back(id); else if(!on && it!=chosen.end()) chosen.erase(it);
                    if(selectedOpt) selectedOpt->textValue=joinItems(chosen);
                    changed=true;
                }
                ImGui::PopID();
            }
            ImGui::EndChild();
        }

        if(!selected.options.empty()) ImGui::SeparatorText("Options");
        for(auto& option:selected.options){
            if(selected.id=="item_counter" && option.key=="selected_items") continue;
            changed|=drawModuleOption(option);
        }
        if(selected.id=="timer"){
            const int sec=mods.Int("timer","duration_seconds",600); Timer().SetDuration(sec);
            if(ImGui::Button(Timer().Running()?"Pause":"Start")) Timer().StartPause();
            ImGui::SameLine(); if(ImGui::Button("Reset")) Timer().Reset();
        }
        if(selected.id=="stopwatch"){
            if(ImGui::Button(Stopwatch().Running()?"Pause":"Start")) Stopwatch().StartPause();
            ImGui::SameLine(); if(ImGui::Button("Reset")) Stopwatch().Reset();
        }
        if(selected.id=="radio"){
            if(ImGui::Button("Play station")) RadioPlayer::Get().PlayConfigured();
            ImGui::SameLine(); if(ImGui::Button("Stop")) RadioPlayer::Get().Stop();
        }
        if(changed) mods.Save();
    }

    ImGui::EndChild(); ImGui::End(); ImGui::PopStyleVar();
}

}