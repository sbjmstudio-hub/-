#pragma once
#include <atomic>

namespace wirza {

struct ActorOverlayColorV1 {
    float r=1.0f;
    float g=1.0f;
    float b=1.0f;
    float a=1.0f;
};

enum class ActorOverlayBridgeState {
    NotInitialized,
    NoVerifiedProfile,
    SignatureMissing,
    HookFailed,
    Ready
};

// Client-side actor render-color bridge used by Hit Color only.
// It never changes Actor health, invulnerability, attacks, packets or reach.
class ActorOverlayRenderBridge {
public:
    static ActorOverlayRenderBridge& Get();

    bool Install();
    void Uninstall();

    ActorOverlayBridgeState State() const { return state_.load(); }
    bool Supported() const { return state_.load()==ActorOverlayBridgeState::Ready; }
    const char* StatusText() const;

    void Apply(ActorOverlayColorV1& color, void* actor) const;

private:
    std::atomic<ActorOverlayBridgeState> state_{ActorOverlayBridgeState::NotInitialized};
    void* target_=nullptr;
};

} // namespace wirza
