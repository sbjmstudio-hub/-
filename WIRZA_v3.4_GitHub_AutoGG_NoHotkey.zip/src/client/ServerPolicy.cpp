#include "ServerPolicy.h"
#include "GameDataBridge.h"
#include "ModuleRegistry.h"
#include <algorithm>
#include <cctype>
#include <unordered_set>

namespace wirza {
namespace {
std::string lower(std::string s){ for(char& c:s)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c))); return s; }
bool has(const std::string& s,const char* token){ return s.find(token)!=std::string::npos; }

const std::unordered_set<std::string>& hiveAllowed(){
    // Hive official allow-list intersection represented by WIRZA modules. Auto GG is explicitly allowed by Hive.
    static const std::unordered_set<std::string> s{
        "cps","armor_status","fov","zoom","lighting","toggle_sneak_sprint","auto_gg"
    }; return s;
}
const std::unordered_set<std::string>& lifeboatAllowed(){
    // Lifeboat explicitly lists fullbright, FOV/zoom, CPS/reach display and self armor HUD.
    static const std::unordered_set<std::string> s{
        "cps","reach_display","armor_status","fov","zoom","lighting"
    }; return s;
}
const std::unordered_set<std::string>& conservativeAllowed(){
    static const std::unordered_set<std::string> s{
        "fps","cps","keystrokes","armor_status","fov","zoom","lighting","memory_usage","playtime"
    }; return s;
}
const std::unordered_set<std::string>& cubeBlocked(){
    // CubeCraft permits many cosmetic clients/mods, but advantage-providing or ambiguous
    // information/automation features are kept off by WIRZA Server Safe Mode.
    static const std::unordered_set<std::string> s{
        "waypoints","waila","horse_stats","auto_gg","nick_hider"
    }; return s;
}
}

ServerPolicy& ServerPolicy::Get(){ static ServerPolicy p; return p; }

KnownServer ServerPolicy::detect() const {
    const auto& n=GameDataBridge::Get().Network();
    if(!n.valid || !n.connected) return KnownServer::Local;
    const std::string h=lower(n.unresolvedUrl+" "+n.hostIp);
    if(has(h,"hivebedrock") || has(h,"playhive")) return KnownServer::Hive;
    if(has(h,"cubecraft")) return KnownServer::CubeCraft;
    if(has(h,"lbsg") || has(h,"lifeboat")) return KnownServer::Lifeboat;
    if(has(h,"megasmp") || has(h,"mega-smp") || has(h,"inpvp")) return KnownServer::MegaSMP;
    return KnownServer::OtherMultiplayer;
}

const char* ServerPolicy::ServerName() const {
    switch(server_.load()){
        case KnownServer::Local:return "Singleplayer / local";
        case KnownServer::Hive:return "The Hive";
        case KnownServer::CubeCraft:return "CubeCraft";
        case KnownServer::Lifeboat:return "Lifeboat";
        case KnownServer::MegaSMP:return "MegaSMP";
        case KnownServer::OtherMultiplayer:return "Other multiplayer";
    }
    return "Unknown";
}

bool ServerPolicy::AllowedModule(const std::string& id) const {
    const auto server=server_.load();
    if(server==KnownServer::Local) return true;
    if(server==KnownServer::Hive) return hiveAllowed().contains(id);
    if(server==KnownServer::Lifeboat) return lifeboatAllowed().contains(id);
    if(server==KnownServer::CubeCraft) return !cubeBlocked().contains(id);
    // MegaSMP explicitly bans hacked clients/macros/autoclickers. Its public rules do
    // not publish a WIRZA-style cosmetic allow-list, so use a conservative local-HUD set.
    if(server==KnownServer::MegaSMP) return conservativeAllowed().contains(id);
    return conservativeAllowed().contains(id);
}

const char* ServerPolicy::Reason(const std::string& id) const {
    if(AllowedModule(id)) return "Allowed by WIRZA Server Safe Mode";
    const auto server=server_.load();
    if(server==KnownServer::Hive) return "Disabled: not on Hive's published allow-list";
    if(server==KnownServer::Lifeboat) return "Disabled: not on Lifeboat's published acceptable-mod list";
    if(server==KnownServer::CubeCraft) return "Disabled: WIRZA treats this module as advantage/automation-sensitive";
    if(server==KnownServer::MegaSMP) return "Disabled: MegaSMP-safe conservative profile";
    return "Disabled: unknown multiplayer rules; conservative profile";
}

void ServerPolicy::restoreSuppressedUnlocked(){
    auto& mods=ModuleRegistry::Get();
    for(const auto& id:suppressed_) if(auto* m=mods.Find(id)) m->enabled=true;
    suppressed_.clear();
}

void ServerPolicy::RestoreSuppressed(){
    std::scoped_lock lock(suppressedMutex_);
    restoreSuppressedUnlocked();
}

void ServerPolicy::RefreshAndEnforce(){
    const auto detected=detect();
    const auto previous=server_.exchange(detected);
    std::scoped_lock lock(suppressedMutex_);
    if(previous!=detected) restoreSuppressedUnlocked();
    if(detected==KnownServer::Local) return;
    for(auto& m:ModuleRegistry::Get().All()){
        if(m.enabled && !AllowedModule(m.id)){ suppressed_.insert(m.id); m.enabled=false; }
    }
}

}
