#include "Timers.h"
#include <algorithm>
namespace wirza {
void Countdown::SetDuration(int s){ duration_=std::max(1,s); if(!running_) stored_=duration_; }
void Countdown::StartPause(){
    if(running_){ stored_=Remaining(); running_=false; }
    else { if(stored_<=0.0) stored_=duration_; started_=Clock::now(); running_=true; }
}
void Countdown::Reset(){ running_=false; stored_=duration_; }
double Countdown::Remaining() const { if(!running_) return stored_; auto e=std::chrono::duration<double>(Clock::now()-started_).count(); return std::max(0.0,stored_-e); }
void StopwatchTimer::StartPause(){ if(running_){ stored_=Elapsed(); running_=false; } else { started_=Clock::now(); running_=true; } }
void StopwatchTimer::Reset(){ running_=false; stored_=0.0; }
double StopwatchTimer::Elapsed() const { return running_?stored_+std::chrono::duration<double>(Clock::now()-started_).count():stored_; }
Countdown& Timer(){ static Countdown t; return t; } StopwatchTimer& Stopwatch(){ static StopwatchTimer s; return s; }
}
