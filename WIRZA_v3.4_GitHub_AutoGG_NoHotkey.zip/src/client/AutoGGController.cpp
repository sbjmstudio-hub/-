#include "AutoGGController.h"
#include "ExtendedFeatureBridge.h"
#include "ModuleRegistry.h"
#include "ServerPolicy.h"
#include <algorithm>
#include <cctype>
#include <chrono>
#include <sstream>

namespace wirza {
namespace {
std::string lowerAscii(std::string s){
    for(char& c:s) c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return s;
}

bool hasToken(const std::string& s,const char* token){
    return s.find(token)!=std::string::npos;
}
}

AutoGGController& AutoGGController::Get(){ static AutoGGController c; return c; }

void AutoGGController::tapKey(WORD vk){
    INPUT in[2]{};
    in[0].type=INPUT_KEYBOARD; in[0].ki.wVk=vk;
    in[1]=in[0]; in[1].ki.dwFlags=KEYEVENTF_KEYUP;
    SendInput(2,in,sizeof(INPUT));
}

void AutoGGController::typeUnicode(const std::string& text){
    if(text.empty()) return;
    int n=MultiByteToWideChar(CP_UTF8,0,text.c_str(),-1,nullptr,0);
    if(n<=1) return;
    std::wstring w(static_cast<size_t>(n),L'\0');
    MultiByteToWideChar(CP_UTF8,0,text.c_str(),-1,w.data(),n);
    w.resize(static_cast<size_t>(n-1));
    for(wchar_t ch:w){
        INPUT in[2]{};
        in[0].type=INPUT_KEYBOARD; in[0].ki.wScan=ch; in[0].ki.dwFlags=KEYEVENTF_UNICODE;
        in[1]=in[0]; in[1].ki.dwFlags=KEYEVENTF_UNICODE|KEYEVENTF_KEYUP;
        SendInput(2,in,sizeof(INPUT));
    }
}

void AutoGGController::queueGG(int delayMs){
    if(phase_!=0) return;
    pending_="gg";
    due_=std::chrono::steady_clock::now()+std::chrono::milliseconds(std::clamp(delayMs,0,3000));
    phase_=1;
    status_="Victory detected - gg queued";
}

void AutoGGController::cancelPending(){
    pending_.clear();
    phase_=0;
}

bool AutoGGController::containsVictoryPhrase(const std::string& text){
    if(text.empty()) return false;
    const std::string s=lowerAscii(text);

    // Strong self-result phrases only. Intentionally do not match generic "winner"
    // because many servers show "Winner: <other player>" after a loss.
    return hasToken(s,"victory") ||
           hasToken(s,"you won") ||
           hasToken(s,"you win") ||
           hasToken(s,"you have won") ||
           hasToken(s,"won the game") ||
           hasToken(s,"match won") ||
           hasToken(text,"勝利") ||
           hasToken(text,"優勝");
}

bool AutoGGController::titleShowsVictory() const {
    const auto& t=ExtendedFeatureBridge::Get().Title();
    if(!t.ready) return false;
    // A verified adapter should clear `ready` when the result title is gone.
    // Do not require life01 because some Bedrock builds/adapters may not expose
    // a reliable remaining-lifetime value.
    return containsVictoryPhrase(t.title) || containsVictoryPhrase(t.subtitle);
}

bool AutoGGController::observeFreshVictoryChat(std::chrono::steady_clock::time_point now){
    const auto& chat=ExtendedFeatureBridge::Get().Chat();
    if(!chat.ready || chat.lines.empty()) return false;

    const auto systemNow=std::chrono::system_clock::now();
    for(auto it=chat.lines.rbegin(); it!=chat.lines.rend(); ++it){
        if(!containsVictoryPhrase(it->text)) continue;
        // Chat fallback only accepts timestamped recent lines to avoid reusing stale
        // snapshots and sending gg again after a menu/reload.
        if(it->received.time_since_epoch().count()==0) continue;
        const auto age=systemNow-it->received;
        if(age<std::chrono::system_clock::duration::zero() || age>std::chrono::seconds(8)) continue;

        const auto stamp=std::chrono::duration_cast<std::chrono::milliseconds>(it->received.time_since_epoch()).count();
        const std::string key=std::to_string(stamp)+"|"+it->text;
        if(key==lastVictoryChatKey_) return true;
        lastVictoryChatKey_=key;
        lastVictoryEvidence_=now;
        if(!sentForRound_){
            const int delay=ModuleRegistry::Get().Int("auto_gg","delay_ms",350);
            queueGG(delay);
            sentForRound_=true;
        }
        return true;
    }
    return false;
}

void AutoGGController::Update(HWND, bool gameplayActive){
    auto& mods=ModuleRegistry::Get();
    auto* mod=mods.Find("auto_gg");
    const auto now=std::chrono::steady_clock::now();

    if(!mod || !mod->enabled){
        cancelPending();
        previousTitleVictory_=false;
        sentForRound_=false;
        status_="Disabled";
        return;
    }

    if(ServerPolicy::Get().IsProtectedServer() && !ServerPolicy::Get().AllowedModule("auto_gg")){
        cancelPending();
        previousTitleVictory_=false;
        sentForRound_=false;
        status_="Blocked by Server Safe Mode";
        return;
    }

    // Do not synthesize keyboard input while Minecraft/WIRZA is not in a gameplay-ready state.
    // Victory observation can remain armed, but queued input waits until gameplayActive is true.
    const bool titleVictory=titleShowsVictory();
    if(titleVictory){
        lastVictoryEvidence_=now;
        if(!previousTitleVictory_ && !sentForRound_){
            const int delay=mods.Int("auto_gg","delay_ms",350);
            queueGG(delay);
            sentForRound_=true;
        }
    }
    previousTitleVictory_=titleVictory;

    bool chatVictory=false;
    if(mods.Bool("auto_gg","chat_fallback",true))
        chatVictory=observeFreshVictoryChat(now);

    // Re-arm only after the previous result has been gone for a while. This prevents
    // repeated gg messages from one persistent victory screen while still allowing the
    // next match to trigger another single message.
    if(!titleVictory && !chatVictory && lastVictoryEvidence_.time_since_epoch().count()!=0){
        const int resetSeconds=mods.Int("auto_gg","rearm_seconds",10);
        if(now-lastVictoryEvidence_>=std::chrono::seconds(std::clamp(resetSeconds,5,30))){
            sentForRound_=false;
            lastVictoryEvidence_={};
            status_="Armed";
        }
    }

    if(!gameplayActive) return;

    if(phase_==1 && now>=due_){
        // Use Minecraft's vanilla chat UI rather than packet fabrication.
        tapKey('T');
        due_=now+std::chrono::milliseconds(60);
        phase_=2;
        status_="Opening chat";
    }else if(phase_==2 && now>=due_){
        typeUnicode(pending_);
        tapKey(VK_RETURN);
        pending_.clear();
        phase_=0;
        status_="Sent gg";
    }
}

}
