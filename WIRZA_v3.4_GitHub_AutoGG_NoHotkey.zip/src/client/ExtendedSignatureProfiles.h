#pragma once
#include <array>
#include <string_view>

namespace wirza {

struct ExtendedFeatureSignatureProfile {
    std::string_view gameVersion;
    // Hook ABIs/signatures for particle, scoreboard, boss bar, chat, titles,
    // pack display and tooltip scrolling are added only after exact-build testing.
};

inline constexpr std::array<ExtendedFeatureSignatureProfile,0> kVerifiedExtendedProfiles{};

inline const ExtendedFeatureSignatureProfile* VerifiedExtendedProfileFor(std::string_view version){
    for(const auto& p:kVerifiedExtendedProfiles) if(p.gameVersion==version) return &p;
    return nullptr;
}

}
