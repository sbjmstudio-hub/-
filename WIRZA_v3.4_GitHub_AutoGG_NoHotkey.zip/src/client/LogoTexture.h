#pragma once
#include <windows.h>
#include <d3d12.h>
#include <imgui.h>

namespace wirza {
class LogoTexture {
public:
    static bool Initialize(ID3D12Device* device,
                           ID3D12CommandQueue* queue,
                           D3D12_CPU_DESCRIPTOR_HANDLE srvCpu,
                           D3D12_GPU_DESCRIPTOR_HANDLE srvGpu);
    static void Shutdown();
    static ImTextureID Id();
    static int Width();
    static int Height();
    static bool Ready();
};
}
