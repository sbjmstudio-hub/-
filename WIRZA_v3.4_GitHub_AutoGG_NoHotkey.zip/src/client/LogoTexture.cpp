#include "LogoTexture.h"
#include "LogoData.h"
#include <wincodec.h>
#include <wrl/client.h>
#include <vector>
#include <cstdint>
#include <cstring>

using Microsoft::WRL::ComPtr;

namespace wirza {
namespace {
ComPtr<ID3D12Resource> g_texture;
ImTextureID g_id = nullptr;
int g_width = 0;
int g_height = 0;

bool loadPng(std::vector<uint8_t>& rgba, UINT& width, UINT& height){
    HRESULT co = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    const bool shouldUninit = SUCCEEDED(co);

    ComPtr<IWICImagingFactory> factory;
    HRESULT hr = CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER,
                                  IID_PPV_ARGS(&factory));
    if(FAILED(hr)){
        if(shouldUninit) CoUninitialize();
        return false;
    }

    ComPtr<IWICStream> stream;
    hr = factory->CreateStream(&stream);
    if(SUCCEEDED(hr)){
        hr = stream->InitializeFromMemory(
            const_cast<BYTE*>(reinterpret_cast<const BYTE*>(kWirzaLogoPng)),
            static_cast<DWORD>(kWirzaLogoPngSize));
    }
    if(FAILED(hr)){
        if(shouldUninit) CoUninitialize();
        return false;
    }

    ComPtr<IWICBitmapDecoder> decoder;
    hr = factory->CreateDecoderFromStream(stream.Get(), nullptr,
                                          WICDecodeMetadataCacheOnLoad, &decoder);
    if(FAILED(hr)){
        if(shouldUninit) CoUninitialize();
        return false;
    }

    ComPtr<IWICBitmapFrameDecode> frame;
    hr = decoder->GetFrame(0, &frame);
    if(FAILED(hr) || FAILED(frame->GetSize(&width, &height)) || width == 0 || height == 0){
        if(shouldUninit) CoUninitialize();
        return false;
    }

    ComPtr<IWICFormatConverter> converter;
    hr = factory->CreateFormatConverter(&converter);
    if(SUCCEEDED(hr)){
        hr = converter->Initialize(frame.Get(), GUID_WICPixelFormat32bppRGBA,
                                   WICBitmapDitherTypeNone, nullptr, 0.0,
                                   WICBitmapPaletteTypeCustom);
    }
    if(FAILED(hr)){
        if(shouldUninit) CoUninitialize();
        return false;
    }

    rgba.resize(static_cast<size_t>(width) * static_cast<size_t>(height) * 4u);
    hr = converter->CopyPixels(nullptr, width * 4u, static_cast<UINT>(rgba.size()), rgba.data());
    if(shouldUninit) CoUninitialize();
    return SUCCEEDED(hr);
}

bool uploadTexture(ID3D12Device* device, ID3D12CommandQueue* queue,
                   const std::vector<uint8_t>& rgba, UINT width, UINT height,
                   D3D12_CPU_DESCRIPTOR_HANDLE srvCpu,
                   D3D12_GPU_DESCRIPTOR_HANDLE srvGpu){
    if(!device || !queue || rgba.empty()) return false;

    D3D12_RESOURCE_DESC desc{};
    desc.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
    desc.Width = width;
    desc.Height = height;
    desc.DepthOrArraySize = 1;
    desc.MipLevels = 1;
    desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    desc.SampleDesc.Count = 1;
    desc.Layout = D3D12_TEXTURE_LAYOUT_UNKNOWN;
    desc.Flags = D3D12_RESOURCE_FLAG_NONE;

    D3D12_HEAP_PROPERTIES defaultHeap{};
    defaultHeap.Type = D3D12_HEAP_TYPE_DEFAULT;
    HRESULT hr = device->CreateCommittedResource(&defaultHeap, D3D12_HEAP_FLAG_NONE, &desc,
                                                  D3D12_RESOURCE_STATE_COPY_DEST, nullptr,
                                                  IID_PPV_ARGS(&g_texture));
    if(FAILED(hr)) return false;

    D3D12_PLACED_SUBRESOURCE_FOOTPRINT footprint{};
    UINT numRows = 0;
    UINT64 rowSize = 0;
    UINT64 uploadBytes = 0;
    device->GetCopyableFootprints(&desc, 0, 1, 0, &footprint, &numRows, &rowSize, &uploadBytes);

    D3D12_RESOURCE_DESC uploadDesc{};
    uploadDesc.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER;
    uploadDesc.Width = uploadBytes;
    uploadDesc.Height = 1;
    uploadDesc.DepthOrArraySize = 1;
    uploadDesc.MipLevels = 1;
    uploadDesc.SampleDesc.Count = 1;
    uploadDesc.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;

    D3D12_HEAP_PROPERTIES uploadHeap{};
    uploadHeap.Type = D3D12_HEAP_TYPE_UPLOAD;
    ComPtr<ID3D12Resource> upload;
    hr = device->CreateCommittedResource(&uploadHeap, D3D12_HEAP_FLAG_NONE, &uploadDesc,
                                         D3D12_RESOURCE_STATE_GENERIC_READ, nullptr,
                                         IID_PPV_ARGS(&upload));
    if(FAILED(hr)){
        g_texture.Reset();
        return false;
    }

    uint8_t* mapped = nullptr;
    D3D12_RANGE noRead{0,0};
    if(FAILED(upload->Map(0, &noRead, reinterpret_cast<void**>(&mapped)))){
        g_texture.Reset();
        return false;
    }
    const size_t srcPitch = static_cast<size_t>(width) * 4u;
    for(UINT y=0; y<height; ++y){
        memcpy(mapped + footprint.Offset + static_cast<size_t>(y) * footprint.Footprint.RowPitch,
               rgba.data() + static_cast<size_t>(y) * srcPitch,
               srcPitch);
    }
    upload->Unmap(0, nullptr);

    ComPtr<ID3D12CommandAllocator> alloc;
    ComPtr<ID3D12GraphicsCommandList> list;
    if(FAILED(device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, IID_PPV_ARGS(&alloc))) ||
       FAILED(device->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, alloc.Get(), nullptr,
                                        IID_PPV_ARGS(&list)))){
        g_texture.Reset();
        return false;
    }

    D3D12_TEXTURE_COPY_LOCATION dst{};
    dst.pResource = g_texture.Get();
    dst.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
    dst.SubresourceIndex = 0;
    D3D12_TEXTURE_COPY_LOCATION src{};
    src.pResource = upload.Get();
    src.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
    src.PlacedFootprint = footprint;
    list->CopyTextureRegion(&dst, 0, 0, 0, &src, nullptr);

    D3D12_RESOURCE_BARRIER barrier{};
    barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barrier.Transition.pResource = g_texture.Get();
    barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;
    barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
    list->ResourceBarrier(1, &barrier);
    if(FAILED(list->Close())){
        g_texture.Reset();
        return false;
    }

    ID3D12CommandList* lists[] = { list.Get() };
    queue->ExecuteCommandLists(1, lists);

    ComPtr<ID3D12Fence> uploadFence;
    if(FAILED(device->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&uploadFence)))){
        g_texture.Reset();
        return false;
    }
    HANDLE eventHandle = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    if(!eventHandle){
        g_texture.Reset();
        return false;
    }
    queue->Signal(uploadFence.Get(), 1);
    if(uploadFence->GetCompletedValue() < 1){
        uploadFence->SetEventOnCompletion(1, eventHandle);
        WaitForSingleObject(eventHandle, INFINITE);
    }
    CloseHandle(eventHandle);

    D3D12_SHADER_RESOURCE_VIEW_DESC srv{};
    srv.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
    srv.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    srv.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2D;
    srv.Texture2D.MipLevels = 1;
    device->CreateShaderResourceView(g_texture.Get(), &srv, srvCpu);

    g_id = reinterpret_cast<ImTextureID>(srvGpu.ptr);
    g_width = static_cast<int>(width);
    g_height = static_cast<int>(height);
    return true;
}
}

bool LogoTexture::Initialize(ID3D12Device* device, ID3D12CommandQueue* queue,
                             D3D12_CPU_DESCRIPTOR_HANDLE srvCpu,
                             D3D12_GPU_DESCRIPTOR_HANDLE srvGpu){
    Shutdown();
    std::vector<uint8_t> rgba;
    UINT width = 0, height = 0;
    if(!loadPng(rgba, width, height)) return false;
    return uploadTexture(device, queue, rgba, width, height, srvCpu, srvGpu);
}

void LogoTexture::Shutdown(){
    g_texture.Reset();
    g_id = nullptr;
    g_width = 0;
    g_height = 0;
}
ImTextureID LogoTexture::Id(){ return g_id; }
int LogoTexture::Width(){ return g_width; }
int LogoTexture::Height(){ return g_height; }
bool LogoTexture::Ready(){ return g_id != nullptr; }
}
