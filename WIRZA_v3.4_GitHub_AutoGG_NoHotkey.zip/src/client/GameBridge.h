#pragma once
#include <atomic>
namespace wirza {
class GameBridge {
public:
    static bool Install();
    static void Uninstall();
    static bool ZoomSupported();
    static const char* ZoomStatus();
    static float ZoomModifier();
    // Internal hook callback entry; public only so the local hook trampoline can call it.
    static void ApplyZoom(void* levelRenderer);
};
}
