#pragma once
#include <atomic>

namespace wirza {

struct EnvironmentColorV1 {
    float r=1.0f;
    float g=1.0f;
    float b=1.0f;
    float a=1.0f;
};

enum class ScreenOverlayKind {
    Fire,
    Water,
    InBlock
};

enum class EnvironmentRenderBridgeState {
    NotInitialized,
    NoVerifiedProfile,
    SignatureMissing,
    HookFailed,
    PartialReady,
    Ready
};

// Client-only visual bridge for Fog / Fog Customizer and Overlay Mod.
// It does not alter world fog definitions, player state, blocks, packets,
// movement, damage or server-visible data.
class EnvironmentRenderBridge {
public:
    static EnvironmentRenderBridge& Get();

    bool Install();
    void Uninstall();

    EnvironmentRenderBridgeState State() const { return state_.load(); }
    bool Supported() const {
        const auto s=state_.load();
        return s==EnvironmentRenderBridgeState::PartialReady || s==EnvironmentRenderBridgeState::Ready;
    }
    const char* StatusText() const;

    bool FogColorReady() const { return fogColorReady_.load(); }
    bool FogScalarsReady() const { return fogScalarsReady_.load(); }
    bool OverlayReady() const { return overlayReady_.load(); }

    void ApplyFogColor(EnvironmentColorV1& color) const;
    void ApplyFogScalars(void* fogState) const;
    void ApplyOverlayOpacity(ScreenOverlayKind kind,float& opacity) const;

private:
    std::atomic<EnvironmentRenderBridgeState> state_{EnvironmentRenderBridgeState::NotInitialized};
    std::atomic<bool> fogColorReady_{false};
    std::atomic<bool> fogScalarsReady_{false};
    std::atomic<bool> overlayReady_{false};
    void* fogColorTarget_=nullptr;
    void* fogScalarsTarget_=nullptr;
    void* fireOverlayTarget_=nullptr;
    void* waterOverlayTarget_=nullptr;
    void* blockOverlayTarget_=nullptr;
};

} // namespace wirza
