#pragma once
#include <windows.h>

namespace wirza {

class ToggleInputController {
public:
    static ToggleInputController& Get();
    void Update(HWND hwnd,bool gameplayActive);
    bool ProcessWndProc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp);
    void ReleaseAll(HWND hwnd);
    bool SprintLatched() const { return sprintLatched_; }
    bool SneakLatched() const { return sneakLatched_; }

private:
    bool processKey(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp,int key,bool enabled,bool& latched);
    bool sprintLatched_=false;
    bool sneakLatched_=false;
    bool previouslyActive_=false;
};

}
