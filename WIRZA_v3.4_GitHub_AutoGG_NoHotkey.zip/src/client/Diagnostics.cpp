#include "Diagnostics.h"
#include <windows.h>
#include <tlhelp32.h>
#include <vector>
#include <string>
#include <cstdio>

namespace wirza {

Diagnostics& Diagnostics::Get(){ static Diagnostics d; return d; }

std::string Diagnostics::GameVersion() const {
    wchar_t exe[MAX_PATH]{};
    GetModuleFileNameW(nullptr,exe,MAX_PATH);

    DWORD dummy=0;
    DWORD size=GetFileVersionInfoSizeW(exe,&dummy);
    if(!size) return "Unknown";

    std::vector<unsigned char> data(size);
    if(!GetFileVersionInfoW(exe,0,size,data.data())) return "Unknown";

    VS_FIXEDFILEINFO* ffi=nullptr;
    UINT len=0;
    if(!VerQueryValueW(data.data(),L"\\",reinterpret_cast<void**>(&ffi),&len) || !ffi)
        return "Unknown";

    char b[64]{};
    snprintf(b,sizeof(b),"%u.%u.%u.%u",
        HIWORD(ffi->dwFileVersionMS),LOWORD(ffi->dwFileVersionMS),
        HIWORD(ffi->dwFileVersionLS),LOWORD(ffi->dwFileVersionLS));
    return b;
}

bool Diagnostics::ObsRunning() const {
    PROCESSENTRY32W pe{sizeof(pe)};
    HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
    if(snap==INVALID_HANDLE_VALUE) return false;
    bool found=false;
    if(Process32FirstW(snap,&pe)){
        do{
            if(_wcsicmp(pe.szExeFile,L"obs64.exe")==0 || _wcsicmp(pe.szExeFile,L"obs32.exe")==0){
                found=true;
                break;
            }
        }while(Process32NextW(snap,&pe));
    }
    CloseHandle(snap);
    return found;
}

}
