#include "ActorOverlayRenderBridge.h"
#include "ActorOverlaySignatureProfiles.h"
#include "Diagnostics.h"
#include "GameDataBridge.h"
#include "ModuleRegistry.h"
#include "PatternScan.h"

#include <MinHook.h>
#include <windows.h>

#include <algorithm>

namespace wirza {
namespace {
using GetOverlayColorV1Fn = ActorOverlayColorV1*(__fastcall*)(void*, ActorOverlayColorV1*, void*);
GetOverlayColorV1Fn g_original=nullptr;
ActorOverlayRenderBridge* g_bridge=nullptr;
const ActorOverlaySignatureProfile* g_profile=nullptr;

Color4 optionColor(const ModuleRegistry& mods,const char* moduleId,const char* key,Color4 fallback){
    const auto* module=mods.Find(moduleId);
    if(!module) return fallback;
    const auto* option=mods.Option(*module,key);
    return (option && option->type==OptionType::Color) ? option->colorValue : fallback;
}

void* actorFromContext(void* context){
    if(!context || !g_profile) return nullptr;
    const auto offset=g_profile->actorPointerOffset;
    auto* slot=reinterpret_cast<unsigned char*>(context)+offset;
    if(!ReadableAddress(slot,sizeof(void*))) return nullptr;
    void* actor=*reinterpret_cast<void**>(slot);
    return ReadableAddress(actor,sizeof(void*)) ? actor : nullptr;
}

ActorOverlayColorV1* __fastcall hookGetOverlayColorV1(void* self,ActorOverlayColorV1* out,void* context){
    ActorOverlayColorV1* result=g_original ? g_original(self,out,context) : out;
    ActorOverlayColorV1* color=result ? result : out;
    if(g_bridge && color){
        if(void* actor=actorFromContext(context)) g_bridge->Apply(*color,actor);
    }
    return result;
}
}

ActorOverlayRenderBridge& ActorOverlayRenderBridge::Get(){ static ActorOverlayRenderBridge b; return b; }

bool ActorOverlayRenderBridge::Install(){
    state_=ActorOverlayBridgeState::NotInitialized;
    g_bridge=this;
    g_profile=nullptr;

    const std::string version=Diagnostics::Get().GameVersion();
    const auto* profile=VerifiedActorOverlayProfileFor(version);
    if(!profile || profile->pattern.empty()){
        state_=ActorOverlayBridgeState::NoVerifiedProfile;
        return false;
    }
    if(profile->abi!=ActorOverlayAbi::GetOverlayColorV1){
        state_=ActorOverlayBridgeState::HookFailed;
        return false;
    }

    HMODULE mc=GetModuleHandleW(nullptr);
    uintptr_t result=FindPattern(mc,profile->pattern);
    if(!result){ state_=ActorOverlayBridgeState::SignatureMissing; return false; }
    if(profile->resolveRel32Call)
        result=ResolveRel32(result,profile->displacementOffset,profile->instructionLength);
    if(!ReadableAddress(reinterpret_cast<void*>(result),16)){
        state_=ActorOverlayBridgeState::SignatureMissing;
        return false;
    }

    g_profile=profile;
    target_=reinterpret_cast<void*>(result);
    if(MH_CreateHook(target_,reinterpret_cast<void*>(&hookGetOverlayColorV1),reinterpret_cast<void**>(&g_original))!=MH_OK){
        target_=nullptr;
        g_profile=nullptr;
        state_=ActorOverlayBridgeState::HookFailed;
        return false;
    }
    if(MH_EnableHook(target_)!=MH_OK){
        MH_RemoveHook(target_);
        target_=nullptr;
        g_original=nullptr;
        g_profile=nullptr;
        state_=ActorOverlayBridgeState::HookFailed;
        return false;
    }

    state_=ActorOverlayBridgeState::Ready;
    return true;
}

void ActorOverlayRenderBridge::Uninstall(){
    if(target_){ MH_DisableHook(target_); MH_RemoveHook(target_); }
    target_=nullptr;
    g_original=nullptr;
    g_profile=nullptr;
    g_bridge=nullptr;
    state_=ActorOverlayBridgeState::NotInitialized;
}

const char* ActorOverlayRenderBridge::StatusText() const{
    switch(state_.load()){
        case ActorOverlayBridgeState::NotInitialized: return "Not initialized";
        case ActorOverlayBridgeState::NoVerifiedProfile: return "Unsupported build - no verified actor-overlay signature profile";
        case ActorOverlayBridgeState::SignatureMissing: return "Verified actor-overlay signature not found - safely disabled";
        case ActorOverlayBridgeState::HookFailed: return "Actor-overlay hook failed - safely disabled";
        case ActorOverlayBridgeState::Ready: return "Ready (client-only Hit Color actor overlay)";
    }
    return "Unknown";
}

void ActorOverlayRenderBridge::Apply(ActorOverlayColorV1& color,void* actor) const{
    auto& mods=ModuleRegistry::Get();
    const auto* module=mods.Find("hit_color");
    if(!module || !module->enabled || !actor) return;

    const int duration=std::clamp(mods.Int("hit_color","duration_ms",350),50,1500);
    if(!GameDataBridge::Get().IsRecentHitActor(actor,duration)) return;

    const Color4 target=optionColor(mods,"hit_color","hit_color",{1.0f,0.0f,0.0f,1.0f});
    const float strength=std::clamp(mods.Float("hit_color","strength",1.0f),0.0f,1.0f);
    color.r=std::clamp(color.r+(target.r-color.r)*strength,0.0f,1.0f);
    color.g=std::clamp(color.g+(target.g-color.g)*strength,0.0f,1.0f);
    color.b=std::clamp(color.b+(target.b-color.b)*strength,0.0f,1.0f);
    color.a=std::clamp(std::max(color.a,target.a*strength),0.0f,1.0f);
}

} // namespace wirza
