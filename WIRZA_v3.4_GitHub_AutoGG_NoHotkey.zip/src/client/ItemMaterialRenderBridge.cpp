#include "ItemMaterialRenderBridge.h"
#include "MaterialSignatureProfiles.h"
#include "PatternScan.h"
#include "Diagnostics.h"
#include <MinHook.h>
#include <windows.h>
#include <algorithm>
#include <cctype>
#include <cmath>
#include <string>

namespace wirza {
namespace {
using MaterialPassRefV1Fn = void(__fastcall*)(void*, MaterialPassRefV1&);
MaterialPassRefV1Fn g_original=nullptr;
ItemMaterialRenderBridge* g_bridge=nullptr;

bool containsAsciiInsensitive(const char* raw,const char* token){
    if(!raw || !token) return false;
    std::string value(raw);
    std::string needle(token);
    std::transform(value.begin(),value.end(),value.begin(),[](unsigned char c){ return static_cast<char>(std::tolower(c)); });
    std::transform(needle.begin(),needle.end(),needle.begin(),[](unsigned char c){ return static_cast<char>(std::tolower(c)); });
    return value.find(needle)!=std::string::npos;
}

bool isPotionIdentifier(const char* id){
    if(!id) return false;
    return containsAsciiInsensitive(id,"potion") ||
           containsAsciiInsensitive(id,"splash_potion") ||
           containsAsciiInsensitive(id,"lingering_potion");
}

Color4 optionColor(const ModuleRegistry& mods,const char* moduleId,const char* key,Color4 fallback){
    const auto* module=mods.Find(moduleId);
    if(!module) return fallback;
    const auto* option=mods.Option(*module,key);
    return (option && option->type==OptionType::Color) ? option->colorValue : fallback;
}

float clamp01(float v){ return std::clamp(v,0.0f,1.0f); }

Color4 blendAndBoost(const Color4& source,const Color4& target,float strength,float pulse){
    const float mixAmount=std::clamp(strength,0.0f,1.0f);
    const float boost=1.0f + std::max(0.0f,strength-1.0f)*0.45f;
    Color4 out{};
    out.r=clamp01((source.r*(1.0f-mixAmount)+target.r*mixAmount)*boost*pulse);
    out.g=clamp01((source.g*(1.0f-mixAmount)+target.g*mixAmount)*boost*pulse);
    out.b=clamp01((source.b*(1.0f-mixAmount)+target.b*mixAmount)*boost*pulse);
    out.a=clamp01(source.a*(1.0f-mixAmount)+target.a*mixAmount);
    return out;
}

void __fastcall hookMaterialPassRefV1(void* self,MaterialPassRefV1& pass){
    // The exact build profile guarantees that this hook runs immediately before
    // the item's glint/material pass. Modify only the local render parameters,
    // then continue through Minecraft's original rendering path.
    if(g_bridge) g_bridge->Apply(pass);
    g_original(self,pass);
}
}

ItemMaterialRenderBridge& ItemMaterialRenderBridge::Get(){ static ItemMaterialRenderBridge b; return b; }

bool ItemMaterialRenderBridge::Install(){
    state_=MaterialBridgeState::NotInitialized;
    g_bridge=this;

    const std::string version=Diagnostics::Get().GameVersion();
    const auto* profile=VerifiedMaterialProfileFor(version);
    if(!profile || profile->pattern.empty()){
        state_=MaterialBridgeState::NoVerifiedProfile;
        return false;
    }

    HMODULE mc=GetModuleHandleW(nullptr);
    uintptr_t result=FindPattern(mc,profile->pattern);
    if(!result){ state_=MaterialBridgeState::SignatureMissing; return false; }
    if(profile->resolveRel32Call)
        result=ResolveRel32(result,profile->displacementOffset,profile->instructionLength);
    if(!ReadableAddress(reinterpret_cast<void*>(result),16)){
        state_=MaterialBridgeState::SignatureMissing;
        return false;
    }

    if(profile->abi!=MaterialPassAbi::MaterialPassRefV1){
        state_=MaterialBridgeState::HookFailed;
        return false;
    }

    target_=reinterpret_cast<void*>(result);
    if(MH_CreateHook(target_,reinterpret_cast<void*>(&hookMaterialPassRefV1),reinterpret_cast<void**>(&g_original))!=MH_OK){
        target_=nullptr;
        state_=MaterialBridgeState::HookFailed;
        return false;
    }
    if(MH_EnableHook(target_)!=MH_OK){
        MH_RemoveHook(target_);
        target_=nullptr;
        g_original=nullptr;
        state_=MaterialBridgeState::HookFailed;
        return false;
    }

    state_=MaterialBridgeState::Ready;
    return true;
}

void ItemMaterialRenderBridge::Uninstall(){
    if(target_){ MH_DisableHook(target_); MH_RemoveHook(target_); }
    target_=nullptr;
    g_original=nullptr;
    g_bridge=nullptr;
    state_=MaterialBridgeState::NotInitialized;
}

const char* ItemMaterialRenderBridge::StatusText() const{
    switch(state_.load()){
        case MaterialBridgeState::NotInitialized: return "Not initialized";
        case MaterialBridgeState::NoVerifiedProfile: return "Unsupported build - no verified item/material signature profile";
        case MaterialBridgeState::SignatureMissing: return "Verified material profile signature not found - safely disabled";
        case MaterialBridgeState::HookFailed: return "Item/material hook failed - safely disabled";
        case MaterialBridgeState::Ready: return "Ready (client-only glint/material visuals)";
    }
    return "Unknown";
}

void ItemMaterialRenderBridge::Apply(MaterialPassRefV1& pass) const{
    auto& mods=ModuleRegistry::Get();
    const auto* glint=mods.Find("glint_colorizer");
    const auto* shiny=mods.Find("shiny_pots");
    const bool glintEnabled=glint && glint->enabled;
    const bool shinyEnabled=shiny && shiny->enabled;
    if(!glintEnabled && !shinyEnabled) return;

    const bool potion=isPotionIdentifier(pass.itemIdentifier);

    // Shiny Pots: request the normal Bedrock glint pass for potion-family items.
    // This only changes the local material request; it never modifies ItemStack
    // data, enchantments, packets or inventory state.
    if(shinyEnabled && potion){
        const Color4 shine=optionColor(mods,"shiny_pots","shine_color",{1.0f,1.0f,1.0f,1.0f});
        const float strength=std::clamp(mods.Float("shiny_pots","strength",1.0f),0.0f,2.0f);
        if(strength>0.0f){
            pass.requestGlint=1;
            pass.glintColor=blendAndBoost(pass.glintColor,shine,strength,1.0f);
        }
    }

    // Glint Colorizer applies only when vanilla or WIRZA has requested a glint
    // pass. Animation speed changes a subtle brightness pulse, not game timing.
    if(glintEnabled && (pass.vanillaGlint || pass.requestGlint)){
        const Color4 target=optionColor(mods,"glint_colorizer","glint_color",{0.65f,0.35f,1.0f,1.0f});
        const float strength=std::clamp(mods.Float("glint_colorizer","strength",1.0f),0.0f,2.0f);
        const float speed=std::clamp(mods.Float("glint_colorizer","speed",1.0f),0.1f,3.0f);
        const float wave=0.92f + 0.08f*std::sin(pass.animationTimeSeconds*6.28318530718f*speed);
        const float pulse=1.0f + (wave-1.0f)*std::clamp(strength,0.0f,1.0f);
        pass.glintColor=blendAndBoost(pass.glintColor,target,strength,pulse);
    }
}

}
