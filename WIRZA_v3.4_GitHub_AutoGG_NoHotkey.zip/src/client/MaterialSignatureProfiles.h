#pragma once
#include <array>
#include <string_view>

namespace wirza {

enum class MaterialPassAbi {
    MaterialPassRefV1
};

// This profile is intentionally strict. A record may only be added after the
// exact Minecraft for Windows executable version and the MaterialPassRefV1 ABI
// have both been verified on a real Windows machine.
struct MaterialSignatureProfile {
    std::string_view gameVersion;
    std::string_view pattern;
    bool resolveRel32Call=false;
    int displacementOffset=1;
    int instructionLength=5;
    MaterialPassAbi abi=MaterialPassAbi::MaterialPassRefV1;
};

// No guessed fallback. Alpha 4D ships the real module logic and adapter, while
// runtime activation waits for an exact verified Bedrock build profile.
inline constexpr std::array<MaterialSignatureProfile,0> kVerifiedMaterialProfiles{};

inline const MaterialSignatureProfile* VerifiedMaterialProfileFor(std::string_view gameVersion) {
    for (const auto& profile : kVerifiedMaterialProfiles) {
        if (profile.gameVersion == gameVersion) return &profile;
    }
    return nullptr;
}

}
