#pragma once
#include "ModuleRegistry.h"
#include <atomic>
#include <cstdint>

namespace wirza {

// Adapter contract used only by a version profile whose ABI has been verified.
// This is NOT assumed to be a universal Minecraft structure.
struct MaterialPassRefV1 {
    const char* itemIdentifier=nullptr;  // UTF-8 identifier, e.g. minecraft:diamond_sword
    Color4 glintColor{1.0f,1.0f,1.0f,1.0f};
    float animationTimeSeconds=0.0f;
    std::uint8_t vanillaGlint=0;
    std::uint8_t requestGlint=0;
    std::uint8_t reserved0=0;
    std::uint8_t reserved1=0;
};

enum class MaterialBridgeState {
    NotInitialized,
    NoVerifiedProfile,
    SignatureMissing,
    HookFailed,
    Ready
};

class ItemMaterialRenderBridge {
public:
    static ItemMaterialRenderBridge& Get();

    bool Install();
    void Uninstall();

    bool Supported() const { return state_.load() == MaterialBridgeState::Ready; }
    MaterialBridgeState State() const { return state_.load(); }
    const char* StatusText() const;

    // Pure visual policy. The verified adapter calls this before the normal
    // material pass. No packet, combat, inventory or server state is modified.
    void Apply(MaterialPassRefV1& pass) const;

private:
    std::atomic<MaterialBridgeState> state_{MaterialBridgeState::NotInitialized};
    void* target_=nullptr;
};

}
