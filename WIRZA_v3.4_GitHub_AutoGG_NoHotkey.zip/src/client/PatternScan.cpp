#include "PatternScan.h"
#include <vector>
#include <sstream>
#include <string>

namespace wirza {
namespace {
std::vector<int> parse(std::string_view p){
    std::vector<int> out; std::istringstream ss{std::string(p)}; std::string tok;
    while(ss>>tok){ if(tok=="?"||tok=="??") out.push_back(-1); else out.push_back(std::stoi(tok,nullptr,16)); }
    return out;
}
}
uintptr_t FindPattern(HMODULE module,std::string_view pattern){
    if(!module) return 0; auto base=reinterpret_cast<uint8_t*>(module);
    auto dos=reinterpret_cast<IMAGE_DOS_HEADER*>(base); if(dos->e_magic!=IMAGE_DOS_SIGNATURE) return 0;
    auto nt=reinterpret_cast<IMAGE_NT_HEADERS*>(base+dos->e_lfanew); if(nt->Signature!=IMAGE_NT_SIGNATURE) return 0;
    size_t size=nt->OptionalHeader.SizeOfImage; auto pat=parse(pattern); if(pat.empty()||pat.size()>size) return 0;
    for(size_t i=0;i+pat.size()<=size;++i){ bool ok=true; for(size_t j=0;j<pat.size();++j){ if(pat[j]>=0&&base[i+j]!=static_cast<uint8_t>(pat[j])){ok=false;break;} } if(ok)return reinterpret_cast<uintptr_t>(base+i); }
    return 0;
}
uintptr_t ResolveRel32(uintptr_t ins,int off,int len){ auto rel=*reinterpret_cast<int32_t*>(ins+off); return ins+len+rel; }
bool ReadableAddress(const void* p,size_t bytes){
    if(!p) return false; MEMORY_BASIC_INFORMATION mbi{}; if(!VirtualQuery(p,&mbi,sizeof(mbi)))return false;
    if(mbi.State!=MEM_COMMIT || (mbi.Protect&(PAGE_NOACCESS|PAGE_GUARD)))return false;
    auto start=reinterpret_cast<uintptr_t>(p), end=start+bytes; auto regionEnd=reinterpret_cast<uintptr_t>(mbi.BaseAddress)+mbi.RegionSize; return end<=regionEnd;
}
}
