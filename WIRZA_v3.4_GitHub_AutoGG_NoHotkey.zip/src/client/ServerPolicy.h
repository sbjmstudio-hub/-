#pragma once
#include <string>
#include <atomic>
#include <mutex>
#include <unordered_set>

namespace wirza {

enum class KnownServer {
    Local,
    Hive,
    CubeCraft,
    Lifeboat,
    MegaSMP,
    OtherMultiplayer
};

class ServerPolicy {
public:
    static ServerPolicy& Get();
    void RefreshAndEnforce();
    void RestoreSuppressed();
    KnownServer Server() const { return server_.load(); }
    const char* ServerName() const;
    bool IsProtectedServer() const { return server_.load()!=KnownServer::Local; }
    bool AllowedModule(const std::string& moduleId) const;
    const char* Reason(const std::string& moduleId) const;

private:
    KnownServer detect() const;
    void restoreSuppressedUnlocked();
    std::atomic<KnownServer> server_{KnownServer::Local};
    std::mutex suppressedMutex_;
    std::unordered_set<std::string> suppressed_;
};

}
