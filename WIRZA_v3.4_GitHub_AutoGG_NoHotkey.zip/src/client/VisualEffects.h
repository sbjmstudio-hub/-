#pragma once
#include <imgui.h>

namespace wirza {

// Alpha 4 visual layer.
// Everything in this class is client-side rendering only. It never changes
// packets, reach, movement, or server-visible game state.
class VisualEffects {
public:
    static void SetMotionTexture(ImTextureID texture, bool ready);
    static void Render();
    static bool MotionCaptureRequested();

private:
    static void DrawMotionBlur();
    static void DrawLightingOverlay();
    static void DrawDamageTint();
    static void DrawBlockOutline();
    static void DrawWaypoints();
    static void DrawMomentum();
    static void DrawMenuBackdrop();
};

}
