#pragma once
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <string>
#include <vector>
#include <mutex>

namespace wirza {

struct BridgeVec2 {
    float x=0.0f;
    float y=0.0f;
};

struct BridgeVec3 {
    float x=0.0f;
    float y=0.0f;
    float z=0.0f;
};

struct InventorySlotSnapshot {
    bool valid=false;
    int slot=-1;
    int count=0;
    int damage=0;
    int maxDamage=0;
    std::string itemId;
    std::string translateName;
};

struct ArmorSlotSnapshot {
    bool valid=false;
    int slot=-1;
    int count=0;
    int damage=0;
    int maxDamage=0;
    float durabilityPercent=0.0f;
    std::string itemId;
    std::string translateName;
};

struct NetworkSnapshot {
    bool valid=false;
    bool connected=false;
    std::string hostIp;
    std::string unresolvedUrl;
    std::string region;
    int port=0;
    int pingMs=0;
};

enum class TargetType {
    None,
    Block,
    Entity
};

struct TargetSnapshot {
    bool valid=false;
    TargetType type=TargetType::None;
    std::string name;
    std::string identifier;
    BridgeVec3 position{};
    BridgeVec3 rayStart{};
    bool blockOriginValid=false;
    BridgeVec3 blockOrigin{};
    float distance=0.0f;
};

struct HorseSnapshot {
    bool valid=false;
    std::string identifier;
    float health=-1.0f;
    float maxHealth=-1.0f;
    float currentSpeed=0.0f;
    bool jumpStrengthAvailable=false;
    float jumpStrength=0.0f;
};

struct PotionEffectSnapshot {
    std::string name;
    int amplifier=0;
    int durationTicks=0;
};

struct PlayerSnapshot {
    bool valid=false;
    bool healthValid=false;
    float health=0.0f;
    float maxHealth=0.0f;
    BridgeVec3 position{};
    BridgeVec3 velocity{};
    BridgeVec2 rotation{};
    int selectedSlot=0;
    std::array<InventorySlotSnapshot,36> inventory{};
    std::array<ArmorSlotSnapshot,4> armor{};
    InventorySlotSnapshot heldItem{};
};

enum class BridgeState {
    NotInitialized,
    SignatureMissing,
    PlatformUnavailable,
    ClientInstanceUnavailable,
    LocalPlayerUnavailable,
    BasicPlayerReady,
    InventoryReady,
    ExtendedReady
};

class GameDataBridge {
public:
    static GameDataBridge& Get();

    bool Install();
    void Uninstall();
    void Refresh();

    BridgeState State() const { return state_; }
    const char* StateText() const;

    const PlayerSnapshot& Player() const { return player_; }
    const NetworkSnapshot& Network() const { return network_; }
    const TargetSnapshot& Target() const { return target_; }
    const HorseSnapshot& Horse() const { return horse_; }
    const std::vector<PotionEffectSnapshot>& PotionEffects() const { return effects_; }

    bool PlayerReady() const;
    bool InventoryReady() const;
    bool ArmorReady() const { return armorReady_; }
    bool NetworkReady() const { return network_.valid; }
    bool TargetReady() const { return target_.valid; }
    bool PotionEffectsReady() const { return effectsReady_; }

    int CountItemContains(const std::string& token) const;
    int CountExactItem(const std::string& itemId) const;
    std::string HeldItemIdCopy() const;
    void* ClientInstanceRaw() const { return lastClientInstance_.load(); }

    float Yaw() const { return player_.rotation.y; }
    float Pitch() const { return player_.rotation.x; }
    const char* CardinalDirection() const;

    float LastReach() const { return lastReach_; }
    bool HasRecentReach(int timeoutMs) const;
    bool HasRecentDamage(int timeoutMs) const;
    long long LastDamageAgeMs() const;
    bool IsRecentHitActor(void* actor,int timeoutMs) const;

private:
    uintptr_t platformGlobalSlot_=0;
    uintptr_t attackTarget_=0;
    uintptr_t pingTarget_=0;

    BridgeState state_=BridgeState::NotInitialized;
    PlayerSnapshot player_{};
    NetworkSnapshot network_{};
    TargetSnapshot target_{};
    HorseSnapshot horse_{};
    std::vector<PotionEffectSnapshot> effects_;

    bool armorReady_=false;
    bool effectsReady_=false;

    int lastPingMs_=0;
    float lastReach_=0.0f;
    std::chrono::steady_clock::time_point lastReachTime_{};

    std::atomic<void*> lastClientInstance_{nullptr};
    void* lastLocalPlayer_=nullptr;

    mutable std::mutex combatVisualMutex_;
    bool healthBaselineValid_=false;
    void* healthOwner_=nullptr;
    float lastObservedHealth_=0.0f;
    float lastObservedMaxHealth_=0.0f;
    std::chrono::steady_clock::time_point lastDamageTime_{};
    std::chrono::steady_clock::time_point lastHealthObservationTime_{};
    void* lastHitActor_=nullptr;
    uint32_t lastHitEntityRawId_=0;
    std::chrono::steady_clock::time_point lastHitTime_{};

    mutable std::mutex heldItemMutex_;
    std::string heldItemIdCache_;

    void clearVolatileSnapshots();
    void refreshNetwork(void* clientInstance);
    void refreshTarget(void* clientInstance, void* localPlayer);
    void refreshArmor(void* localPlayer);
    void refreshHorse(void* localPlayer);
    void observeLocalHealth(void* localPlayer,float health,float maxHealth);
    void recordHitTarget(void* actor);

    static void* __fastcall HookActorAttack(void* obj, void* ret, void* target, void* cause, void* a4);
    static int __fastcall HookAveragePing(void* obj, char* guidOrAddress);
};

}
