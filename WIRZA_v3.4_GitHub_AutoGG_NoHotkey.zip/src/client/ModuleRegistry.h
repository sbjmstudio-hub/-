#pragma once
#include <string>
#include <vector>

namespace wirza {

enum class ModuleState {
    Implemented,
    Partial,
    Planned,
    BedrockAlternative,
    NotApplicable
};

enum class OptionType {
    Bool,
    Float,
    Int,
    Color,
    Choice,
    Text
};

struct Color4 {
    float r=1.0f, g=1.0f, b=1.0f, a=1.0f;
};

struct ModuleOption {
    std::string key;
    std::string label;
    OptionType type=OptionType::Bool;

    bool boolValue=false;

    float floatValue=0.0f;
    float floatMin=0.0f;
    float floatMax=1.0f;

    int intValue=0;
    int intMin=0;
    int intMax=100;

    Color4 colorValue{};

    int choiceIndex=0;
    std::vector<std::string> choices;

    std::string textValue;
};

struct HudStyle {
    float x = 20.0f;
    float y = 20.0f;
    float scale = 1.0f;
    float opacity = 0.86f;
    float textSize = 1.0f;
    float cornerRadius = 6.0f;
    Color4 backgroundColor{0.04f,0.025f,0.07f,0.86f};
    Color4 textColor{0.93f,0.95f,1.0f,1.0f};
    Color4 accentColor{0.65f,0.35f,1.0f,1.0f};
    bool background = true;
};

struct ModuleConfig {
    std::string id;
    std::string name;
    std::string category;
    bool enabled = false;
    ModuleState state = ModuleState::Planned;
    bool hud = false;
    HudStyle hudStyle{};
    std::vector<ModuleOption> options;
};

class ModuleRegistry {
public:
    static ModuleRegistry& Get();
    void Initialize();
    void Load();
    void Save() const;

    ModuleConfig* Find(const std::string& id);
    const ModuleConfig* Find(const std::string& id) const;

    ModuleOption* Option(ModuleConfig& module, const std::string& key);
    const ModuleOption* Option(const ModuleConfig& module, const std::string& key) const;

    float Float(const std::string& moduleId,const std::string& key,float fallback) const;
    int Int(const std::string& moduleId,const std::string& key,int fallback) const;
    bool Bool(const std::string& moduleId,const std::string& key,bool fallback) const;
    std::string Text(const std::string& moduleId,const std::string& key,const std::string& fallback={}) const;

    std::vector<ModuleConfig>& All() { return modules_; }
    const std::vector<ModuleConfig>& All() const { return modules_; }

    const char* StateText(ModuleState state) const;
    std::wstring FilePath() const;

private:
    std::vector<ModuleConfig> modules_;
};

}
