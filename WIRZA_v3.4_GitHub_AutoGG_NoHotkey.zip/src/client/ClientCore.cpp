#include "ClientCore.h"
#include "ModuleRegistry.h"
#include "RuntimeStats.h"
#include "D3D12Hooks.h"
#include "GameBridge.h"
#include "MemoryWriteBridge.h"
#include "GameDataBridge.h"
#include "ItemHistory.h"
#include "FirstPersonRenderBridge.h"
#include "ItemMaterialRenderBridge.h"
#include "ActorOverlayRenderBridge.h"
#include "EnvironmentRenderBridge.h"
#include "ExtendedFeatureBridge.h"
#include "Settings.h"
#include <MinHook.h>
#include <windows.h>

namespace wirza {
unsigned long ClientCore::Run(void*){
    Settings::Get().Load();
    ModuleRegistry::Get().Load();
    RuntimeStats::Get().Initialize();
    ItemHistory::Get().Initialize();
    if(MH_Initialize()!=MH_OK) return 10;
    if(!D3D12Hooks::Install()){ MH_Uninitialize(); return 20; }
    // Zoom is optional/version-bound. Failure here must not stop HUD/menu modules.
    GameBridge::Install();
    GameDataBridge::Get().Install();
    // First-person visuals are build-bound. No verified profile means safe no-op.
    FirstPersonRenderBridge::Get().Install();
    // Item/material visuals are also build-bound and use exact verified profiles only.
    ItemMaterialRenderBridge::Get().Install();
    // Hit Color uses the actor overlay render path and is exact-build gated.
    ActorOverlayRenderBridge::Get().Install();
    // Fog/overlay visuals use only exact-build verified environment render adapters.
    EnvironmentRenderBridge::Get().Install();
    // Scoreboard/boss/chat/title/pack/tooltip/particle adapters are also exact-build gated.
    ExtendedFeatureBridge::Get().Install();
    // Stay resident until Minecraft exits. F10 is an emergency HUD/menu shutdown request,
    // but we intentionally do not FreeLibrary from a live render hook.
    while(true){
        GameDataBridge::Get().Refresh();
        ItemHistory::Get().Refresh();
        MemoryWriteBridge::Get().Tick();
        Sleep(100);
    }
}
}

