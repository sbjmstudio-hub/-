#pragma once
#include <chrono>
#include <deque>

namespace wirza {

class Metrics {
public:
    static Metrics& Get();

    void OnFrame();
    void OnInput(bool leftDown, bool rightDown);

    int Fps() const { return fps_; }
    int LeftCps() const;
    int RightCps() const;
    int TotalCps() const { return LeftCps() + RightCps(); }

    double SecondsSinceLeftClick() const;

private:
    Metrics() = default;
    using Clock = std::chrono::steady_clock;

    Clock::time_point sampleStart_ = Clock::now();
    Clock::time_point lastLeftClick_{};
    int frameCount_ = 0;
    int fps_ = 0;
    bool prevLeft_ = false, prevRight_ = false;

    std::deque<Clock::time_point> leftClicks_, rightClicks_;
    void trim(std::deque<Clock::time_point>& q) const;
};

}
