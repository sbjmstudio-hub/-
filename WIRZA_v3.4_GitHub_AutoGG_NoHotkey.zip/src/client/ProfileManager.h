#pragma once
#include <string>
#include <vector>

namespace wirza {

class ProfileManager {
public:
    static ProfileManager& Get();

    std::vector<std::string> ListProfiles() const;
    bool SaveProfile(const std::string& name);
    bool LoadProfile(const std::string& name);
    bool DeleteProfile(const std::string& name);

private:
    std::wstring ProfilesDir() const;
    static std::string SafeName(const std::string& name);
};

}
