#include "ColorPostProcess.h"
#include "ModuleRegistry.h"
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <algorithm>
#include <cstring>
#include <cmath>

using Microsoft::WRL::ComPtr;

namespace wirza {
namespace {
ComPtr<ID3D12RootSignature> g_root;
ComPtr<ID3D12PipelineState> g_pso;
bool g_ready=false;

constexpr const char* kShader=R"HLSL(
Texture2D sceneTex : register(t0);
SamplerState sceneSampler : register(s0);

cbuffer ColorParams : register(b0)
{
    float saturation;
    float contrast;
    float brightness;
    float padding;
};

struct VSOut
{
    float4 position : SV_Position;
    float2 uv : TEXCOORD0;
};

VSOut VSMain(uint vertexId : SV_VertexID)
{
    VSOut o;
    float2 pos;
    if (vertexId == 0) pos = float2(-1.0, -1.0);
    else if (vertexId == 1) pos = float2(-1.0, 3.0);
    else pos = float2(3.0, -1.0);

    o.position = float4(pos, 0.0, 1.0);
    // D3D texture origin is top-left for the copied swapchain texture.
    o.uv = float2((pos.x + 1.0) * 0.5, 1.0 - (pos.y + 1.0) * 0.5);
    return o;
}

float4 PSMain(VSOut i) : SV_Target
{
    float4 src = sceneTex.Sample(sceneSampler, i.uv);
    float3 rgb = src.rgb;
    float luma = dot(rgb, float3(0.2126, 0.7152, 0.0722));
    rgb = lerp(luma.xxx, rgb, saturation);
    rgb = (rgb - 0.5) * contrast + 0.5;
    rgb *= brightness;
    return float4(saturate(rgb), src.a);
}
)HLSL";

bool compileShader(const char* entry,const char* target,ComPtr<ID3DBlob>& out){
    UINT flags=D3DCOMPILE_ENABLE_STRICTNESS;
#ifdef _DEBUG
    flags|=D3DCOMPILE_DEBUG|D3DCOMPILE_SKIP_OPTIMIZATION;
#else
    flags|=D3DCOMPILE_OPTIMIZATION_LEVEL3;
#endif
    ComPtr<ID3DBlob> errors;
    return SUCCEEDED(D3DCompile(kShader,std::strlen(kShader),"WIRZA_ColorPostProcess",nullptr,nullptr,
                               entry,target,flags,0,&out,&errors));
}
}

bool ColorPostProcess::Initialize(ID3D12Device* device,DXGI_FORMAT renderTargetFormat){
    Shutdown();
    if(!device || renderTargetFormat==DXGI_FORMAT_UNKNOWN) return false;

    D3D12_DESCRIPTOR_RANGE range{};
    range.RangeType=D3D12_DESCRIPTOR_RANGE_TYPE_SRV;
    range.NumDescriptors=1;
    range.BaseShaderRegister=0;
    range.RegisterSpace=0;
    range.OffsetInDescriptorsFromTableStart=D3D12_DESCRIPTOR_RANGE_OFFSET_APPEND;

    D3D12_ROOT_PARAMETER params[2]{};
    params[0].ParameterType=D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
    params[0].DescriptorTable.NumDescriptorRanges=1;
    params[0].DescriptorTable.pDescriptorRanges=&range;
    params[0].ShaderVisibility=D3D12_SHADER_VISIBILITY_PIXEL;
    params[1].ParameterType=D3D12_ROOT_PARAMETER_TYPE_32BIT_CONSTANTS;
    params[1].Constants.ShaderRegister=0;
    params[1].Constants.RegisterSpace=0;
    params[1].Constants.Num32BitValues=4;
    params[1].ShaderVisibility=D3D12_SHADER_VISIBILITY_PIXEL;

    D3D12_STATIC_SAMPLER_DESC sampler{};
    sampler.Filter=D3D12_FILTER_MIN_MAG_MIP_LINEAR;
    sampler.AddressU=D3D12_TEXTURE_ADDRESS_MODE_CLAMP;
    sampler.AddressV=D3D12_TEXTURE_ADDRESS_MODE_CLAMP;
    sampler.AddressW=D3D12_TEXTURE_ADDRESS_MODE_CLAMP;
    sampler.MipLODBias=0.0f;
    sampler.MaxAnisotropy=1;
    sampler.ComparisonFunc=D3D12_COMPARISON_FUNC_ALWAYS;
    sampler.BorderColor=D3D12_STATIC_BORDER_COLOR_TRANSPARENT_BLACK;
    sampler.MinLOD=0.0f;
    sampler.MaxLOD=D3D12_FLOAT32_MAX;
    sampler.ShaderRegister=0;
    sampler.RegisterSpace=0;
    sampler.ShaderVisibility=D3D12_SHADER_VISIBILITY_PIXEL;

    D3D12_ROOT_SIGNATURE_DESC rootDesc{};
    rootDesc.NumParameters=2;
    rootDesc.pParameters=params;
    rootDesc.NumStaticSamplers=1;
    rootDesc.pStaticSamplers=&sampler;
    rootDesc.Flags=D3D12_ROOT_SIGNATURE_FLAG_ALLOW_INPUT_ASSEMBLER_INPUT_LAYOUT;

    ComPtr<ID3DBlob> serialized,errors;
    if(FAILED(D3D12SerializeRootSignature(&rootDesc,D3D_ROOT_SIGNATURE_VERSION_1,&serialized,&errors))) return false;
    if(FAILED(device->CreateRootSignature(0,serialized->GetBufferPointer(),serialized->GetBufferSize(),IID_PPV_ARGS(&g_root)))) return false;

    ComPtr<ID3DBlob> vs,ps;
    if(!compileShader("VSMain","vs_5_0",vs) || !compileShader("PSMain","ps_5_0",ps)){
        Shutdown(); return false;
    }

    D3D12_GRAPHICS_PIPELINE_STATE_DESC pso{};
    pso.pRootSignature=g_root.Get();
    pso.VS={vs->GetBufferPointer(),vs->GetBufferSize()};
    pso.PS={ps->GetBufferPointer(),ps->GetBufferSize()};
    pso.BlendState.AlphaToCoverageEnable=FALSE;
    pso.BlendState.IndependentBlendEnable=FALSE;
    D3D12_RENDER_TARGET_BLEND_DESC rtBlend{};
    rtBlend.BlendEnable=FALSE;
    rtBlend.LogicOpEnable=FALSE;
    rtBlend.SrcBlend=D3D12_BLEND_ONE;
    rtBlend.DestBlend=D3D12_BLEND_ZERO;
    rtBlend.BlendOp=D3D12_BLEND_OP_ADD;
    rtBlend.SrcBlendAlpha=D3D12_BLEND_ONE;
    rtBlend.DestBlendAlpha=D3D12_BLEND_ZERO;
    rtBlend.BlendOpAlpha=D3D12_BLEND_OP_ADD;
    rtBlend.LogicOp=D3D12_LOGIC_OP_NOOP;
    rtBlend.RenderTargetWriteMask=D3D12_COLOR_WRITE_ENABLE_ALL;
    for(auto& rt:pso.BlendState.RenderTarget) rt=rtBlend;

    pso.SampleMask=UINT_MAX;
    pso.RasterizerState.FillMode=D3D12_FILL_MODE_SOLID;
    pso.RasterizerState.CullMode=D3D12_CULL_MODE_NONE;
    pso.RasterizerState.FrontCounterClockwise=FALSE;
    pso.RasterizerState.DepthBias=D3D12_DEFAULT_DEPTH_BIAS;
    pso.RasterizerState.DepthBiasClamp=D3D12_DEFAULT_DEPTH_BIAS_CLAMP;
    pso.RasterizerState.SlopeScaledDepthBias=D3D12_DEFAULT_SLOPE_SCALED_DEPTH_BIAS;
    pso.RasterizerState.DepthClipEnable=TRUE;
    pso.RasterizerState.MultisampleEnable=FALSE;
    pso.RasterizerState.AntialiasedLineEnable=FALSE;
    pso.RasterizerState.ForcedSampleCount=0;
    pso.RasterizerState.ConservativeRaster=D3D12_CONSERVATIVE_RASTERIZATION_MODE_OFF;

    pso.DepthStencilState.DepthEnable=FALSE;
    pso.DepthStencilState.DepthWriteMask=D3D12_DEPTH_WRITE_MASK_ZERO;
    pso.DepthStencilState.DepthFunc=D3D12_COMPARISON_FUNC_ALWAYS;
    pso.DepthStencilState.StencilEnable=FALSE;
    pso.InputLayout={nullptr,0};
    pso.IBStripCutValue=D3D12_INDEX_BUFFER_STRIP_CUT_VALUE_DISABLED;
    pso.PrimitiveTopologyType=D3D12_PRIMITIVE_TOPOLOGY_TYPE_TRIANGLE;
    pso.NumRenderTargets=1;
    pso.RTVFormats[0]=renderTargetFormat;
    pso.DSVFormat=DXGI_FORMAT_UNKNOWN;
    pso.SampleDesc.Count=1;
    pso.SampleDesc.Quality=0;

    if(FAILED(device->CreateGraphicsPipelineState(&pso,IID_PPV_ARGS(&g_pso)))){
        Shutdown(); return false;
    }
    g_ready=true;
    return true;
}

void ColorPostProcess::Shutdown(){
    g_pso.Reset();
    g_root.Reset();
    g_ready=false;
}

bool ColorPostProcess::Requested(){
    auto& mods=ModuleRegistry::Get();
    auto* m=mods.Find("color_saturation");
    if(!g_ready || !m || !m->enabled) return false;
    const float s=mods.Float("color_saturation","saturation",1.0f);
    const float c=mods.Float("color_saturation","contrast",1.0f);
    const float b=mods.Float("color_saturation","brightness",1.0f);
    return std::abs(s-1.0f)>0.001f || std::abs(c-1.0f)>0.001f || std::abs(b-1.0f)>0.001f;
}

bool ColorPostProcess::Render(ID3D12GraphicsCommandList* cmd,D3D12_GPU_DESCRIPTOR_HANDLE sourceSrv,
                              UINT width,UINT height){
    if(!g_ready || !cmd || sourceSrv.ptr==0 || width==0 || height==0) return false;

    auto& mods=ModuleRegistry::Get();
    const float saturation=std::clamp(mods.Float("color_saturation","saturation",1.0f),0.0f,2.0f);
    const float contrast=std::clamp(mods.Float("color_saturation","contrast",1.0f),0.5f,1.8f);
    const float brightness=std::clamp(mods.Float("color_saturation","brightness",1.0f),0.5f,1.8f);
    const float constants[4]={saturation,contrast,brightness,0.0f};

    D3D12_VIEWPORT viewport{};
    viewport.Width=static_cast<float>(width);
    viewport.Height=static_cast<float>(height);
    viewport.MinDepth=0.0f;
    viewport.MaxDepth=1.0f;
    D3D12_RECT scissor{0,0,static_cast<LONG>(width),static_cast<LONG>(height)};

    cmd->SetGraphicsRootSignature(g_root.Get());
    cmd->SetPipelineState(g_pso.Get());
    cmd->RSSetViewports(1,&viewport);
    cmd->RSSetScissorRects(1,&scissor);
    cmd->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    cmd->SetGraphicsRootDescriptorTable(0,sourceSrv);
    cmd->SetGraphicsRoot32BitConstants(1,4,constants,0);
    cmd->DrawInstanced(3,1,0,0);
    return true;
}

}
