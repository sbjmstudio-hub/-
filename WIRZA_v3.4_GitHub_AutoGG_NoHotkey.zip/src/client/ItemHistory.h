#pragma once
#include <mutex>
#include <string>
#include <vector>

namespace wirza {

class ItemHistory {
public:
    static ItemHistory& Get();
    void Initialize();
    void Refresh();
    std::vector<std::string> Items() const;
    bool Has(const std::string& id) const;

private:
    void saveUnlocked() const;
    std::wstring filePath() const;
    mutable std::mutex mutex_;
    std::vector<std::string> items_;
    bool initialized_=false;
};

}
