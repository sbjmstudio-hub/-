#pragma once
#include <cstdint>
#include <string>
#include <chrono>
namespace wirza {
class RuntimeStats {
public:
    static RuntimeStats& Get();
    void Initialize();
    double PlaytimeSeconds() const;
    uint64_t WorkingSetBytes() const;
    std::string ClockText() const;
private:
    using Clock=std::chrono::steady_clock;
    Clock::time_point started_{Clock::now()};
};
}
