#include "FirstPersonRenderBridge.h"
#include "SignatureProfiles.h"
#include "PatternScan.h"
#include "Diagnostics.h"
#include "ModuleRegistry.h"
#include "GameDataBridge.h"
#include "Input.h"
#include <MinHook.h>
#include <windows.h>
#include <algorithm>
#include <chrono>
#include <cctype>
#include <cmath>
#include <cstring>
#include <string>

namespace wirza {
namespace {
using MatrixRefV1Fn = void(__fastcall*)(void*, FirstPersonMatrix4&, float);
MatrixRefV1Fn g_original=nullptr;
FirstPersonRenderBridge* g_bridge=nullptr;

constexpr float kPi=3.14159265358979323846f;

FirstPersonMatrix4 identity(){
    FirstPersonMatrix4 r{};
    r.m[0]=r.m[5]=r.m[10]=r.m[15]=1.0f;
    return r;
}

FirstPersonMatrix4 multiply(const FirstPersonMatrix4& a,const FirstPersonMatrix4& b){
    FirstPersonMatrix4 r{};
    // Column-major: r = a * b.
    for(int col=0;col<4;++col){
        for(int row=0;row<4;++row){
            float v=0.0f;
            for(int k=0;k<4;++k) v += a.m[k*4+row] * b.m[col*4+k];
            r.m[col*4+row]=v;
        }
    }
    return r;
}

void postMultiply(FirstPersonMatrix4& base,const FirstPersonMatrix4& t){ base=multiply(base,t); }

void translate(FirstPersonMatrix4& m,float x,float y,float z){
    auto t=identity(); t.m[12]=x; t.m[13]=y; t.m[14]=z; postMultiply(m,t);
}
void scale(FirstPersonMatrix4& m,float x,float y,float z){
    auto s=identity(); s.m[0]=x; s.m[5]=y; s.m[10]=z; postMultiply(m,s);
}
void rotateX(FirstPersonMatrix4& m,float deg){
    const float r=deg*kPi/180.0f,c=std::cos(r),s=std::sin(r); auto q=identity();
    q.m[5]=c; q.m[6]=s; q.m[9]=-s; q.m[10]=c; postMultiply(m,q);
}
void rotateY(FirstPersonMatrix4& m,float deg){
    const float r=deg*kPi/180.0f,c=std::cos(r),s=std::sin(r); auto q=identity();
    q.m[0]=c; q.m[2]=-s; q.m[8]=s; q.m[10]=c; postMultiply(m,q);
}
void rotateZ(FirstPersonMatrix4& m,float deg){
    const float r=deg*kPi/180.0f,c=std::cos(r),s=std::sin(r); auto q=identity();
    q.m[0]=c; q.m[1]=s; q.m[4]=-s; q.m[5]=c; postMultiply(m,q);
}

bool containsAsciiInsensitive(std::string value,const char* token){
    std::transform(value.begin(),value.end(),value.begin(),[](unsigned char c){
        return static_cast<char>(std::tolower(c));
    });
    return value.find(token)!=std::string::npos;
}

void __fastcall hookMatrixRefV1(void* self,FirstPersonMatrix4& matrix,float partialTick){
    // Apply after vanilla has produced its first-person model matrix. The profile
    // contract guarantees this target is first-person-only; no profile = no hook.
    g_original(self,matrix,partialTick);
    if(g_bridge) g_bridge->ApplyTransform(matrix,partialTick);
}
}

FirstPersonRenderBridge& FirstPersonRenderBridge::Get(){ static FirstPersonRenderBridge b; return b; }

bool FirstPersonRenderBridge::Install(){
    state_=FirstPersonBridgeState::NotInitialized;
    g_bridge=this;

    const std::string version=Diagnostics::Get().GameVersion();
    const auto* profile=VerifiedFirstPersonProfileFor(version);
    if(!profile || profile->pattern.empty()){
        state_=FirstPersonBridgeState::NoVerifiedProfile;
        return false;
    }

    HMODULE mc=GetModuleHandleW(nullptr);
    uintptr_t result=FindPattern(mc,profile->pattern);
    if(!result){ state_=FirstPersonBridgeState::SignatureMissing; return false; }
    if(profile->resolveRel32Call)
        result=ResolveRel32(result,profile->displacementOffset,profile->instructionLength);
    if(!ReadableAddress(reinterpret_cast<void*>(result),16)){
        state_=FirstPersonBridgeState::SignatureMissing;
        return false;
    }

    target_=reinterpret_cast<void*>(result);
    if(profile->abi!=FirstPersonAbi::MatrixRefV1){
        target_=nullptr; state_=FirstPersonBridgeState::HookFailed; return false;
    }
    if(MH_CreateHook(target_,reinterpret_cast<void*>(&hookMatrixRefV1),reinterpret_cast<void**>(&g_original))!=MH_OK){
        target_=nullptr; state_=FirstPersonBridgeState::HookFailed; return false;
    }
    if(MH_EnableHook(target_)!=MH_OK){
        MH_RemoveHook(target_); target_=nullptr; g_original=nullptr;
        state_=FirstPersonBridgeState::HookFailed; return false;
    }
    state_=FirstPersonBridgeState::Ready;
    return true;
}

void FirstPersonRenderBridge::Uninstall(){
    if(target_){ MH_DisableHook(target_); MH_RemoveHook(target_); }
    target_=nullptr; g_original=nullptr; g_bridge=nullptr;
    state_=FirstPersonBridgeState::NotInitialized;
}

const char* FirstPersonRenderBridge::StatusText() const{
    switch(state_.load()){
        case FirstPersonBridgeState::NotInitialized: return "Not initialized";
        case FirstPersonBridgeState::NoVerifiedProfile: return "Unsupported build - no verified first-person signature profile";
        case FirstPersonBridgeState::SignatureMissing: return "Verified profile signature not found - safely disabled";
        case FirstPersonBridgeState::HookFailed: return "First-person hook failed - safely disabled";
        case FirstPersonBridgeState::Ready: return "Ready (first-person visual transform)";
    }
    return "Unknown";
}

void FirstPersonRenderBridge::ApplyTransform(FirstPersonMatrix4& matrix,float){
    auto& mods=ModuleRegistry::Get();
    auto* item=mods.Find("item_customizer");
    auto* shield=mods.Find("shields");
    auto* old=mods.Find("one_seven_visuals");
    if((!item||!item->enabled) && (!shield||!shield->enabled) && (!old||!old->enabled)) return;

    // The cached identifier is copied by GameDataBridge; no game memory is
    // written and no packet is touched.
    const std::string held=GameDataBridge::Get().HeldItemIdCopy();
    const bool isShield=containsAsciiInsensitive(held,"shield");
    const bool isSword=containsAsciiInsensitive(held,"sword");

    if(item && item->enabled){
        const float x=mods.Float("item_customizer","x",0.0f);
        const float y=mods.Float("item_customizer","y",0.0f);
        const float s=std::clamp(mods.Float("item_customizer","scale",1.0f),0.3f,2.0f);
        const float r=mods.Float("item_customizer","rotation",0.0f);
        translate(matrix,x,y,0.0f);
        rotateZ(matrix,r);
        scale(matrix,s,s,s);
    }

    if(shield && shield->enabled && isShield){
        const float x=mods.Float("shields","x",0.0f);
        const float y=mods.Float("shields","y",0.0f);
        const float s=std::clamp(mods.Float("shields","scale",1.0f),0.3f,1.5f);
        translate(matrix,x,y,0.0f);
        scale(matrix,s,s,s);
    }

    if(old && old->enabled){
        const float visualScale=std::clamp(mods.Float("one_seven_visuals","scale",1.0f),0.5f,1.5f);
        scale(matrix,visualScale,visualScale,visualScale);

        const auto& input=Input::Get().State();
        static bool prevLeft=false;
        static auto swingStart=std::chrono::steady_clock::time_point{};
        if(input.foreground && input.left && !prevLeft) swingStart=std::chrono::steady_clock::now();
        prevLeft=input.left;

        if(mods.Bool("one_seven_visuals","old_swing",true) && swingStart.time_since_epoch().count()!=0){
            const float ms=std::chrono::duration<float,std::milli>(std::chrono::steady_clock::now()-swingStart).count();
            const float p=std::clamp(ms/260.0f,0.0f,1.0f);
            if(p<1.0f){
                const float wave=std::sin(std::sqrt(p)*kPi);
                // MCJE 1.7-inspired presentation only; this is not combat logic.
                translate(matrix,-0.10f*wave,-0.08f*wave,0.0f);
                rotateY(matrix,-18.0f*wave);
                rotateX(matrix,-55.0f*wave);
                rotateZ(matrix,-12.0f*wave);
            }
        }

        if(mods.Bool("one_seven_visuals","old_block",true) && input.foreground && input.right && isSword){
            // Visual sword-block pose. Bedrock has no networked 1.7 sword block;
            // this intentionally changes only the local first-person matrix.
            translate(matrix,-0.16f,0.08f,0.05f);
            rotateY(matrix,-32.0f);
            rotateX(matrix,-18.0f);
            rotateZ(matrix,-22.0f);
        }
    }
}

}
