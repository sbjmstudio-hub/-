# WIRZA v3.4

Minecraft for Windows 向けのネイティブ Windows クライアントです。

## GitHub Actions で Windows x64 をビルド

GitHub の **Actions** → **Build WIRZA Windows x64** → **Run workflow** でビルドできます。
完了後の Artifacts に `WIRZA-v3.4-Windows-x64` が生成されます。

生成ZIPの主なファイル:

- `WIRZA.Launcher.exe`
- `WIRZA.Client.dll`

詳細は [README_GITHUB_BUILD_JA.md](README_GITHUB_BUILD_JA.md) を参照してください。

## Status

55モジュール構成を維持しています。Screenshotはユーザー指定により未実装のままです。
Minecraft内部のbuild依存ABI/signatureが未検証の機能は `Partial` として安全側に留めています。

## Build requirements

- Windows x64
- Visual Studio 2022 / MSVC v143
- Windows SDK
- CMake 3.24+
- Git

依存ライブラリ（MinHook / Dear ImGui / EnTT）はCMake FetchContentで取得します。

## Safety scope

WIRZAはHUD・表示・読み取り・視覚カスタマイズ用途です。攻撃距離増加、KillAura、Fly、移動速度改変、パケット改変、アンチチート回避、ステルス化・AV回避は対象外です。
