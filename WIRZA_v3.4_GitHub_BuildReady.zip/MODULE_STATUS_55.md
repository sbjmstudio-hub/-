# WIRZA v3 - 55 Module Implementation Matrix

The user removed 38 modules from the original 93-feature plan.
The original number is kept here only as a reference.

Legend:
- Implemented = real working code in this source
- Partial = some working functionality remains to be completed
- Planned = registered independently, not yet wired to Minecraft

1. 2D Items — Partial (original #1)
2. Armor Status — Implemented (original #3)
3. Auto Text Actions — Partial (original #6)
4. Auto Text Hotkey — Partial (original #7)
5. Block Outline — Partial (original #8)
6. Boss Bar — Partial (original #9)
7. Chat Mod — Partial (original #10)
8. Clock — Implemented (original #12)
9. Color Saturation — Partial (original #13)
10. CPS — Implemented (original #17)
11. Crosshair — Implemented (original #18)
12. Damage Tint — Partial (original #19; read-only minecraft:health drop detector + timed D3D12/ImGui screen tint; absorption-only damage/runtime verification remain)
13. Direction HUD — Implemented (original #21)
14. Fog / Fog Customizer — Partial (original #23; fog-color + density/start policy wired through EnvironmentRenderBridge; exact current-build environment signature/offset profile required)
15. FOV — Partial (original #24)
16. FPS — Implemented (original #25)
17. Glint Colorizer — Partial (original #27; material-pass color policy ready, verified item/material signature profile required)
18. GUI Scale — Partial (original #28)
19. Hit Color — Partial (original #30; recent attacked-entity tracking + actor overlay color policy ready; exact current-build actor-overlay signature profile required)
20. Horse Stats — Partial (original #31)
21. Item Counter — Implemented (original #36)
22. Item Customizer — Partial (original #37; transform logic ready, verified first-person signature profile required)
23. Item Physics — Partial (original #38)
24. Keystrokes — Implemented (original #40)
25. Kill Sounds — Partial (original #41)
26. Lighting — Partial (original #42)
27. Memory Usage — Implemented (original #44)
28. Menu Blur — Partial (original #45)
29. Momentum — Partial (original #48)
30. Motion Blur — Partial (original #49)
31. Nick Hider — Partial (original #52)
32. 1.7 Visuals — Partial (original #53; local swing/block pose logic ready, verified first-person signature profile required)
33. Overlay Mod — Partial (original #54; fire/water/in-block opacity policy wired through EnvironmentRenderBridge; exact current-build overlay signature/ABI profile required)
34. Pack Display — Partial (original #55)
35. Pack Organizer — Partial (original #56)
36. Particle Changer — Partial (original #57)
37. Ping — Implemented (original #58)
38. Playtime — Implemented (original #59)
39. Potion Effects — Partial (original #60)
40. Radio / Lunar FM — Partial (original #63)
41. Reach Display — Implemented (original #64)
42. Scoreboard — Partial (original #68)
43. Screenshot / Screenshot Uploader — Planned (original #69)
44. Scrollable Tooltips — Partial (original #70)
45. Server Address — Implemented (original #71)
46. Shields — Partial (original #72; shield-only transform logic ready, verified first-person signature profile required)
47. Shiny Pots — Partial (original #73; potion filter/glint-request policy ready, verified item/material signature profile required)
48. Stopwatch — Implemented (original #78)
49. Titles — Partial (original #83)
50. Toggle Sneak / Toggle Sprint — Partial (original #85)
51. Totem Counter — Implemented (original #86)
52. WAILA — Partial (original #87)
53. Waypoints — Partial (original #88)
54. Zoom — Implemented (original #91)
55. Potion Counter — Implemented (original #92)

## Configuration status
All 55 remaining modules now have independent configurable settings. Runtime status above remains separate and honest.

## v3.3 Game Data Bridge
Real read-only bridge connections added:
- Direction HUD: LocalPlayer ActorRotation
- Item Counter: LocalPlayer inventory item IDs/names
- Totem Counter: LocalPlayer inventory
- Potion Counter: LocalPlayer inventory

The bridge uses signature/layout validation and reports Unsupported/Waiting instead of guessing memory addresses.


## v3.4 Alpha 3 — Data Bridge Batch 2
Connected in source:
- Armor Status: ECS ActorEquipmentComponent -> armor inventory -> item durability
- Ping: passive RakPeer average-ping hook
- Server Address: PacketSender -> NetworkSystem -> RemoteConnector -> GameConnectionInfo
- Reach Display: passive Actor::attack hook + current HitResult distance; display-only
- WAILA: real current HitResult; block target is resolved through BlockSource. Entity target uses ray/AABB matching.
- Horse Stats: horse target detection is connected, but hidden movement/jump attribute IDs are intentionally not guessed.
- Potion Effects: UI/capability path exists, but current MobEffect live-data ABI has not been safely verified and remains unsupported.

No module changes attack range, packet contents, or movement speed.


## v3.4 Alpha 4A — Visual Batch 1
Connected in source:
- Block Outline (Partial)
  - Uses the verified current HitResult block origin and ray-start camera position.
  - Projects the target block AABB into the D3D12/ImGui frame.
  - Line width, color, and fill opacity are configurable.
  - Uses the current WIRZA zoom FOV modifier so the overlay follows Zoom.
  - Exact alignment still requires Windows/Minecraft runtime verification.
- Motion Blur (Partial)
  - Keeps two D3D12 history textures and blends the previous Minecraft frame.
  - Captures before WIRZA HUD/menu rendering, avoiding recursive HUD smear.
  - Strength is configurable. The existing multi-sample setting is reserved for a later multi-history pass.
- Lighting (Partial)
  - Safe screen-space brightness/gamma approximation.
  - Does not rewrite Minecraft block-light or world-light values.
  - Full Bright currently means a brighter post-process, not a game-light override.
- Menu Blur (Partial)
  - Configurable menu dim/haze fallback is connected.
  - True sampled separable blur remains pending.

## v3.4 Alpha 4B — Color Post-process
Connected in source:
- Color Saturation (Partial)
  - D3D12 fullscreen post-process shader samples a copy of the current Minecraft backbuffer.
  - Saturation, contrast, and brightness are applied in the pixel shader.
  - The corrected frame is written before WIRZA HUD/menu drawing, so HUD colors are not modified.
  - Motion Blur history now captures the already color-corrected Minecraft frame, still before WIRZA HUD/menu.
  - No Minecraft offsets/signatures or server-visible state are touched.
  - Partial until Windows compile/runtime verification.

Alpha 4 visual list status:
- Particle Changer is now Partial through the ExtendedFeatureBridge policy contract.


## v3.4 Alpha 4D — Item / Material Visual Bridge
Connected in source:
- Glint Colorizer (Partial)
  - Shared ItemMaterialRenderBridge receives a verified pre-material-pass adapter context.
  - Configurable glint color, strength and animation speed modify local render parameters only.
  - The colorizer runs only when vanilla or WIRZA has requested a glint pass.
- Shiny Pots (Partial)
  - Potion-family item IDs request the normal local glint pass.
  - Shine color and strength are configurable; zero strength does not request extra glint.
  - No ItemStack/enchantment/inventory/network state is modified.
- MaterialSignatureProfiles.h is intentionally empty until an exact Minecraft for Windows build can be verified on a real Windows machine.


## v3.4 Alpha 4E — Combat Visuals
Connected in source:
- Damage Tint (Partial)
  - Reads the local player's `minecraft:health` attribute (ID 7) through the existing read-only ECS attribute bridge.
  - A health decrease records a local damage timestamp; the renderer draws a configurable full-screen tint with a quadratic fade.
  - The tint is drawn over Minecraft but before WIRZA HUD/menu, so WIRZA HUD colors stay unchanged.
  - No damage amount, health, packets or combat state are modified.
  - Absorption-only damage is not yet observable through the health-only path and Windows/Minecraft runtime verification remains pending.
- Hit Color (Partial)
  - The existing passive Actor::attack observation records the target Actor/entity id and timestamp.
  - ActorOverlayRenderBridge applies the configured color only to that recent target's render overlay.
  - ActorOverlaySignatureProfiles.h is intentionally empty until an exact Minecraft for Windows build, ABI and actor-pointer offset are verified.
  - No attack validity, reach, damage, invulnerability time or packets are changed.


## v3.4 Alpha 4F — Environment Visuals
Connected in source:
- Fog / Fog Customizer (Partial)
  - Added EnvironmentRenderBridge with an exact-build profile gate.
  - Fog color policy blends the configured RGB with the vanilla fog color while preserving engine alpha.
  - Fog density and fog-start scaling logic operates only through verified offsets in an opaque fog-state adapter.
  - No biome, resource-pack, world, packet or server state is modified.
- Overlay Mod (Partial)
  - Fire, water and in-block opacity are handled as separate local render paths.
  - Each configured value is a multiplier of vanilla opacity: 1.0 = vanilla, 0.0 = hidden.
  - No burning, underwater, suffocation or collision state is changed.
- EnvironmentRenderSignatureProfiles.h is intentionally empty until the exact Minecraft for Windows build, fog ABI/offsets and overlay ABI are verified on a real Windows machine.


## v3.4 Alpha 4G — Remaining modules sweep (Screenshot excluded)
Source-connected or adapter-contracted in this batch:
- 2D Items (Partial): configurable render policy; exact item renderer adapter pending.
- Auto Text Actions (Partial): delayed action queue entry point; verified game-event trigger pending.
- Auto Text Hotkey (Partial): hotkey -> vanilla chat open -> Unicode text -> Enter state machine; Windows/Minecraft runtime validation pending.
- GUI Scale (Partial): configurable scale policy; exact Minecraft GUI render adapter pending.
- Item Physics (Partial): rotation/tilt/bob policy; exact dropped-item renderer adapter pending.
- Kill Sounds (Partial): sound preset/volume policy; reliable kill-event adapter pending.
- Momentum (Partial): local horizontal velocity readout + optional history graph; runtime calibration pending.
- Nick Hider (Partial): replacement/hide policy; exact name/chat render adapters pending.
- Pack Organizer (Partial): favorites/compact/search policy; exact pack-screen adapter pending.
- Boss Bar, Chat Mod, Pack Display, Particle Changer, Radio, Scoreboard, Scrollable Tooltips, Titles, Toggle Sprint/Sneak and Waypoints were also moved to Partial in this batch.
- Screenshot / Screenshot Uploader intentionally remains Planned by user request.

Final source-state count for this package: 17 Implemented, 37 Partial, 1 Planned (Screenshot).
