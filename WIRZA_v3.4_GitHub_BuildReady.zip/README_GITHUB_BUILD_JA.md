# WIRZA v3.4 - GitHub Actions Build

このリポジトリは Minecraft for Windows 向け WIRZA v3.4 の Windows x64 ビルド用ソースです。

## GitHubだけでEXE/DLLを作る

1. このフォルダ一式を GitHub リポジトリへ置きます。
2. GitHub の **Actions** を開きます。
3. **Build WIRZA Windows x64** を選びます。
4. **Run workflow** を押します。
5. 完了後、Artifacts の **WIRZA-v3.4-Windows-x64** をダウンロードします。
6. ZIPの中には次が入ります。
   - `WIRZA.Launcher.exe`
   - `WIRZA.Client.dll`
   - ドキュメント
7. `WIRZA.Launcher.exe` と `WIRZA.Client.dll` は必ず同じフォルダに置いてください。

## ローカルWindows PCでビルドする場合

必要:
- Windows 10/11 x64
- Visual Studio 2022 Build Tools または Visual Studio 2022
- Desktop development with C++
- Windows SDK
- CMake 3.24+
- Git

PowerShell:

```powershell
cmake --preset windows-x64
cmake --build --preset windows-x64-release
```

## 実行について

`WIRZA.Launcher.exe` は Minecraft for Windows のプロセスを検出し、同じフォルダの `WIRZA.Client.dll` を読み込みます。
WIRZAは見た目・HUD・読み取り系を目的としており、攻撃距離増加、KillAura、Fly、速度改変、パケット改変、アンチチート回避などは対象外です。

## 現在の制約

- GitHub Actions用ビルド構成は用意されていますが、この作業環境では Windows/MSVC の実ビルド結果までは確認していません。
- `Partial` の機能は Minecraft の実際のbuildに対応する検証済みABI/signatureが必要な場合があります。
- Screenshot機能はユーザー指定により未実装のままです。
- 生成物はコード署名されていません。Windows SmartScreen等で警告される可能性があります。
