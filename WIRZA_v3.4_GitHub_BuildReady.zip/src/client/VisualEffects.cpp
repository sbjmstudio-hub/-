#include "VisualEffects.h"
#include "GameDataBridge.h"
#include "GameBridge.h"
#include "ModuleRegistry.h"
#include "UI.h"
#include <imgui.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdio>
#include <cmath>
#include <sstream>
#include <string>
#include <vector>

namespace wirza {
namespace {
ImTextureID g_motionTexture=nullptr;
bool g_motionReady=false;

constexpr float kPi=3.14159265358979323846f;

ImU32 toU32(const Color4& c,float alphaScale=1.0f){
    return ImGui::ColorConvertFloat4ToU32(ImVec4(
        std::clamp(c.r,0.0f,1.0f),
        std::clamp(c.g,0.0f,1.0f),
        std::clamp(c.b,0.0f,1.0f),
        std::clamp(c.a*alphaScale,0.0f,1.0f)));
}

Color4 optionColor(ModuleConfig& m,const char* key,Color4 fallback){
    auto* o=ModuleRegistry::Get().Option(m,key);
    return (o && o->type==OptionType::Color)?o->colorValue:fallback;
}

struct V3 { float x,y,z; };
V3 sub(const V3& a,const V3& b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
float dot(const V3& a,const V3& b){return a.x*b.x+a.y*b.y+a.z*b.z;}
V3 cross(const V3& a,const V3& b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}

bool project(const V3& world,const V3& camera,float yawDeg,float pitchDeg,float fovDeg,const ImVec2& size,ImVec2& out){
    const float yaw=yawDeg*kPi/180.0f;
    const float pitch=pitchDeg*kPi/180.0f;
    const float cp=std::cos(pitch),sp=std::sin(pitch);
    const float cy=std::cos(yaw),sy=std::sin(yaw);

    // Minecraft convention: yaw 0 faces +Z; positive pitch looks down.
    const V3 forward{-sy*cp,-sp,cy*cp};
    const V3 right{cy,0.0f,sy};
    const V3 up=cross(forward,right);
    const V3 d=sub(world,camera);

    const float z=dot(d,forward);
    if(z<=0.05f) return false;
    const float x=dot(d,right);
    const float y=dot(d,up);

    const float safeFov=std::clamp(fovDeg,30.0f,120.0f)*kPi/180.0f;
    const float focalY=(size.y*0.5f)/std::tan(safeFov*0.5f);
    const float focalX=focalY;
    out.x=size.x*0.5f+(x/z)*focalX;
    out.y=size.y*0.5f-(y/z)*focalY;
    return std::isfinite(out.x)&&std::isfinite(out.y);
}
}

void VisualEffects::SetMotionTexture(ImTextureID texture,bool ready){
    g_motionTexture=texture;
    g_motionReady=ready && texture!=nullptr;
}

bool VisualEffects::MotionCaptureRequested(){
    auto* m=ModuleRegistry::Get().Find("motion_blur");
    return m && m->enabled;
}

void VisualEffects::Render(){
    DrawMotionBlur();
    DrawLightingOverlay();
    DrawDamageTint();
    DrawBlockOutline();
    DrawWaypoints();
    DrawMomentum();
    DrawMenuBackdrop();
}

void VisualEffects::DrawMotionBlur(){
    auto& mods=ModuleRegistry::Get();
    auto* m=mods.Find("motion_blur");
    if(!m || !m->enabled || !g_motionReady || UI::MenuOpen()) return;

    const float strength=std::clamp(mods.Float("motion_blur","strength",0.25f),0.0f,0.90f);
    if(strength<=0.001f) return;

    auto& io=ImGui::GetIO();
    // One prior Minecraft frame is blended over the current frame. The setting
    // named "samples" is retained for the later multi-history pass; Alpha 4A
    // deliberately does not fake extra temporal samples.
    ImGui::GetBackgroundDrawList()->AddImage(
        g_motionTexture,ImVec2(0,0),io.DisplaySize,
        ImVec2(0,0),ImVec2(1,1),IM_COL32(255,255,255,(int)(strength*255.0f)));
}

void VisualEffects::DrawLightingOverlay(){
    auto& mods=ModuleRegistry::Get();
    auto* m=mods.Find("lighting");
    if(!m || !m->enabled || UI::MenuOpen()) return;

    float brightness=std::clamp(mods.Float("lighting","brightness",1.0f),0.5f,2.0f);
    const float gamma=std::clamp(mods.Float("lighting","gamma",1.0f),0.5f,3.0f);
    if(mods.Bool("lighting","full_bright",false)) brightness=std::max(brightness,1.35f);

    auto& io=ImGui::GetIO();
    if(brightness<0.999f){
        float a=std::clamp((1.0f-brightness)*0.78f*(1.0f/std::max(0.5f,gamma)),0.0f,0.75f);
        ImGui::GetBackgroundDrawList()->AddRectFilled({0,0},io.DisplaySize,IM_COL32(0,0,0,(int)(a*255.0f)));
    }else if(brightness>1.001f){
        // Alpha blending toward white is a safe post-lighting approximation.
        // It does not rewrite Minecraft block light values.
        float a=std::clamp((brightness-1.0f)*0.22f*gamma,0.0f,0.34f);
        ImGui::GetBackgroundDrawList()->AddRectFilled({0,0},io.DisplaySize,IM_COL32(255,255,255,(int)(a*255.0f)));
    }
}

void VisualEffects::DrawDamageTint(){
    auto& mods=ModuleRegistry::Get();
    auto* m=mods.Find("damage_tint");
    if(!m || !m->enabled || UI::MenuOpen()) return;

    const int duration=std::clamp(mods.Int("damage_tint","duration_ms",250),50,1500);
    const long long age=GameDataBridge::Get().LastDamageAgeMs();
    if(age<0 || age>duration) return;

    const float strength=std::clamp(mods.Float("damage_tint","strength",0.6f),0.0f,1.0f);
    if(strength<=0.001f) return;

    const float t=std::clamp(static_cast<float>(age)/static_cast<float>(duration),0.0f,1.0f);
    const float fade=(1.0f-t)*(1.0f-t); // fast flash, soft tail
    const Color4 color=optionColor(*m,"tint_color",{1.0f,0.0f,0.0f,0.6f});
    if(color.a<=0.001f || fade<=0.001f) return;

    auto& io=ImGui::GetIO();
    // Draw over the Minecraft frame but before WIRZA HUD/menu. The effect is
    // therefore visible to OBS Game Capture without tinting WIRZA's own HUD.
    ImGui::GetBackgroundDrawList()->AddRectFilled(
        {0,0},io.DisplaySize,toU32(color,strength*fade));
}

void VisualEffects::DrawBlockOutline(){
    auto& mods=ModuleRegistry::Get();
    auto* m=mods.Find("block_outline");
    if(!m || !m->enabled || UI::MenuOpen()) return;

    const auto& bridge=GameDataBridge::Get();
    const auto& t=bridge.Target();
    if(!bridge.PlayerReady() || !t.valid || t.type!=TargetType::Block || !t.blockOriginValid) return;

    auto& io=ImGui::GetIO();
    if(io.DisplaySize.x<32 || io.DisplaySize.y<32) return;

    const V3 camera{t.rayStart.x,t.rayStart.y,t.rayStart.z};
    const V3 origin{t.blockOrigin.x,t.blockOrigin.y,t.blockOrigin.z};
    const float yaw=bridge.Yaw();
    const float pitch=bridge.Pitch();
    const float fov=mods.Float("fov","normal_fov",90.0f)*std::clamp(GameBridge::ZoomModifier(),0.04f,1.0f);

    std::array<V3,8> corners{{
        {origin.x,origin.y,origin.z},{origin.x+1,origin.y,origin.z},
        {origin.x,origin.y+1,origin.z},{origin.x+1,origin.y+1,origin.z},
        {origin.x,origin.y,origin.z+1},{origin.x+1,origin.y,origin.z+1},
        {origin.x,origin.y+1,origin.z+1},{origin.x+1,origin.y+1,origin.z+1}
    }};
    std::array<ImVec2,8> p{};
    for(size_t i=0;i<corners.size();++i)
        if(!project(corners[i],camera,yaw,pitch,fov,io.DisplaySize,p[i])) return;

    const Color4 color=optionColor(*m,"outline_color",{0.65f,0.35f,1.0f,1.0f});
    const float line=std::clamp(mods.Float("block_outline","line_width",2.0f),1.0f,8.0f);
    const float fill=std::clamp(mods.Float("block_outline","fill_alpha",0.0f),0.0f,0.6f);
    auto* dl=ImGui::GetBackgroundDrawList();
    const ImU32 lineCol=toU32(color);

    static constexpr int edges[12][2]={{0,1},{0,2},{0,4},{1,3},{1,5},{2,3},{2,6},{3,7},{4,5},{4,6},{5,7},{6,7}};
    for(const auto& e:edges) dl->AddLine(p[e[0]],p[e[1]],lineCol,line);

    if(fill>0.001f){
        const ImU32 fillCol=toU32(color,fill);
        static constexpr int faces[6][4]={{0,1,3,2},{4,5,7,6},{0,1,5,4},{2,3,7,6},{0,2,6,4},{1,3,7,5}};
        for(const auto& f:faces) dl->AddQuadFilled(p[f[0]],p[f[1]],p[f[2]],p[f[3]],fillCol);
        // Re-draw edges so fill never hides the outline.
        for(const auto& e:edges) dl->AddLine(p[e[0]],p[e[1]],lineCol,line);
    }
}


void VisualEffects::DrawWaypoints(){
    auto& mods=ModuleRegistry::Get();
    auto* m=mods.Find("waypoints");
    if(!m || !m->enabled || UI::MenuOpen()) return;
    const auto& bridge=GameDataBridge::Get();
    if(!bridge.PlayerReady()) return;

    struct Waypoint { std::string name; V3 pos; };
    std::vector<Waypoint> points;
    std::stringstream list(mods.Text("waypoints","points",""));
    std::string record;
    while(std::getline(list,record,';')){
        std::stringstream row(record);
        std::string name,xs,ys,zs;
        if(!std::getline(row,name,',') || !std::getline(row,xs,',') || !std::getline(row,ys,',') || !std::getline(row,zs,',')) continue;
        try{
            points.push_back({name,{std::stof(xs),std::stof(ys),std::stof(zs)}});
        }catch(...){ }
    }
    if(points.empty()) return;

    auto& io=ImGui::GetIO();
    const auto& ps=bridge.Player();
    const V3 camera{ps.position.x,ps.position.y+1.62f,ps.position.z};
    const float fov=mods.Float("fov","normal_fov",90.0f)*std::clamp(GameBridge::ZoomModifier(),0.04f,1.0f);
    const float maxDistance=mods.Float("waypoints","max_distance",3000.0f);
    const bool beam=mods.Bool("waypoints","beam",true);
    const bool showDistance=mods.Bool("waypoints","show_distance",true);
    const Color4 color=optionColor(*m,"waypoint_color",{0.65f,0.35f,1.0f,1.0f});
    auto* dl=ImGui::GetForegroundDrawList();
    const ImU32 col=toU32(color);

    for(const auto& wp:points){
        const float dx=wp.pos.x-camera.x,dy=wp.pos.y-camera.y,dz=wp.pos.z-camera.z;
        const float dist=std::sqrt(dx*dx+dy*dy+dz*dz);
        if(dist>maxDistance || dist<0.05f) continue;
        ImVec2 p{};
        if(!project(wp.pos,camera,bridge.Yaw(),bridge.Pitch(),fov,io.DisplaySize,p)) continue;
        if(p.x<-100 || p.x>io.DisplaySize.x+100 || p.y<-100 || p.y>io.DisplaySize.y+100) continue;
        dl->AddCircleFilled(p,5.0f,col,16);
        std::string label=wp.name.empty()?"Waypoint":wp.name;
        if(showDistance) label += "  "+std::to_string(static_cast<int>(dist))+"m";
        dl->AddText({p.x+9.0f,p.y-8.0f},col,label.c_str());
        if(beam){
            ImVec2 top{};
            V3 topWorld=wp.pos; topWorld.y+=40.0f;
            if(project(topWorld,camera,bridge.Yaw(),bridge.Pitch(),fov,io.DisplaySize,top))
                dl->AddLine(p,top,toU32(color,0.55f),1.5f);
        }
    }
}


void VisualEffects::DrawMomentum(){
    auto& mods=ModuleRegistry::Get();
    auto* m=mods.Find("momentum");
    if(!m || !m->enabled || UI::MenuOpen()) return;
    const auto& bridge=GameDataBridge::Get();
    if(!bridge.PlayerReady()) return;
    const auto& v=bridge.Player().velocity;
    const float speed=std::sqrt(v.x*v.x+v.z*v.z);
    auto& io=ImGui::GetIO();
    auto* dl=ImGui::GetForegroundDrawList();
    const ImU32 col=IM_COL32(210,190,255,230);
    if(mods.Bool("momentum","show_speed",true)){
        char text[64]{}; std::snprintf(text,sizeof(text),"Speed %.3f",speed);
        dl->AddText({20.0f,io.DisplaySize.y-42.0f},col,text);
    }
    if(mods.Bool("momentum","show_graph",false)){
        struct Sample { double t; float v; };
        static std::vector<Sample> history;
        static const auto start=std::chrono::steady_clock::now();
        const double now=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
        history.push_back({now,speed});
        const double keep=std::clamp((double)mods.Float("momentum","history_seconds",3.0f),1.0,10.0);
        while(!history.empty() && now-history.front().t>keep) history.erase(history.begin());
        const ImVec2 base{20.0f,io.DisplaySize.y-52.0f}; const float w=180.0f,h=48.0f;
        dl->AddRectFilled({base.x,base.y-h},{base.x+w,base.y},IM_COL32(10,8,18,120));
        float maxv=0.01f; for(const auto& sm:history) maxv=std::max(maxv,sm.v);
        for(size_t i=1;i<history.size();++i){
            const float x1=base.x+(float)((history[i-1].t-(now-keep))/keep)*w;
            const float x2=base.x+(float)((history[i].t-(now-keep))/keep)*w;
            const float y1=base.y-(history[i-1].v/maxv)*h;
            const float y2=base.y-(history[i].v/maxv)*h;
            dl->AddLine({x1,y1},{x2,y2},col,1.5f);
        }
    }
}

void VisualEffects::DrawMenuBackdrop(){
    if(!UI::MenuOpen()) return;
    auto& mods=ModuleRegistry::Get();
    auto* m=mods.Find("menu_blur");
    if(!m || !m->enabled) return;

    const float dim=std::clamp(mods.Float("menu_blur","dim",0.35f),0.0f,0.8f);
    const float strength=std::clamp(mods.Float("menu_blur","strength",0.6f),0.0f,1.0f);
    auto& io=ImGui::GetIO();
    // Alpha 4A fallback: configurable dim + haze. A true separable blur pass
    // requires a sampled backbuffer shader and remains pending.
    const int blackA=(int)(std::clamp(dim,0.0f,0.8f)*255.0f);
    const int hazeA=(int)(std::clamp(strength*0.055f,0.0f,0.08f)*255.0f);
    auto* dl=ImGui::GetBackgroundDrawList();
    dl->AddRectFilled({0,0},io.DisplaySize,IM_COL32(0,0,0,blackA));
    if(hazeA>0) dl->AddRectFilled({0,0},io.DisplaySize,IM_COL32(120,105,145,hazeA));
}

}
