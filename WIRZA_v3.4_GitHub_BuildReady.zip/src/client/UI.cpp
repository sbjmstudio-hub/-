#include "UI.h"
#include "Settings.h"
#include "Metrics.h"
#include "Input.h"
#include "Timers.h"
#include "GameBridge.h"
#include "GameDataBridge.h"
#include "FirstPersonRenderBridge.h"
#include "ItemMaterialRenderBridge.h"
#include "ActorOverlayRenderBridge.h"
#include "EnvironmentRenderBridge.h"
#include "ExtendedFeatureBridge.h"
#include "RadioPlayer.h"
#include "ToggleInputController.h"
#include "AutoTextController.h"
#include "LogoTexture.h"
#include "ModuleRegistry.h"
#include "RuntimeStats.h"
#include "VisualEffects.h"
#include "ProfileManager.h"
#include <imgui.h>
#include <backends/imgui_impl_win32.h>
#include <algorithm>
#include <cstdio>
#include <string>
#include <functional>
#include <cctype>
#include <vector>

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

namespace wirza {
namespace {
bool g_menu=false; int g_category=0; char g_search[64]{}; bool g_lastMenu=false; char g_profileName[64]="Default"; int g_selectedModule=0;

bool sendEscapeToGame(HWND hwnd){
    if(!hwnd) return false;
    const UINT scan=MapVirtualKeyW(VK_ESCAPE,MAPVK_VK_TO_VSC);
    const LPARAM down=1 | (static_cast<LPARAM>(scan)<<16);
    const LPARAM up=down | (static_cast<LPARAM>(1)<<30) | (static_cast<LPARAM>(1)<<31);
    DWORD_PTR ignored=0;
    const auto flags=SMTO_ABORTIFHUNG|SMTO_BLOCK;
    const LRESULT a=SendMessageTimeoutW(hwnd,WM_KEYDOWN,VK_ESCAPE,down,flags,100,&ignored);
    const LRESULT b=SendMessageTimeoutW(hwnd,WM_KEYUP,VK_ESCAPE,up,flags,100,&ignored);
    return a!=0 && b!=0;
}

void theme(){
    ImGuiStyle& st=ImGui::GetStyle(); st.WindowRounding=10; st.ChildRounding=9; st.FrameRounding=8; st.PopupRounding=8; st.ScrollbarRounding=8; st.GrabRounding=8;
    st.WindowPadding={14,14}; st.FramePadding={10,7}; st.ItemSpacing={10,10};
    auto& c=st.Colors;
    c[ImGuiCol_WindowBg]={0.025f,0.035f,0.055f,0.97f}; c[ImGuiCol_ChildBg]={0.045f,0.060f,0.085f,0.96f};
    c[ImGuiCol_Border]={0.18f,0.22f,0.30f,1}; c[ImGuiCol_Text]={0.93f,0.95f,1,1}; c[ImGuiCol_TextDisabled]={0.55f,0.60f,0.70f,1};
    c[ImGuiCol_FrameBg]={0.07f,0.085f,0.12f,1}; c[ImGuiCol_FrameBgHovered]={0.13f,0.10f,0.24f,1}; c[ImGuiCol_FrameBgActive]={0.24f,0.12f,0.48f,1};
    c[ImGuiCol_CheckMark]={0.72f,0.45f,1,1}; c[ImGuiCol_SliderGrab]={0.55f,0.30f,1,1}; c[ImGuiCol_SliderGrabActive]={0.72f,0.45f,1,1};
    c[ImGuiCol_Button]={0.16f,0.11f,0.30f,1}; c[ImGuiCol_ButtonHovered]={0.28f,0.15f,0.55f,1}; c[ImGuiCol_ButtonActive]={0.40f,0.20f,0.75f,1};
    c[ImGuiCol_Header]={0.20f,0.12f,0.42f,1}; c[ImGuiCol_HeaderHovered]={0.30f,0.16f,0.60f,1}; c[ImGuiCol_HeaderActive]={0.40f,0.20f,0.75f,1};
}

bool matchSearch(const char* name){ if(g_search[0]=='\0')return true; std::string a(name),b(g_search); std::transform(a.begin(),a.end(),a.begin(),::tolower); std::transform(b.begin(),b.end(),b.begin(),::tolower); return a.find(b)!=std::string::npos; }

void moduleCard(const char* id,const char* name,const char* desc,bool& value){
    if(!matchSearch(name))return;
    ImGui::PushID(id); ImGui::BeginChild(id,ImVec2(0,78),true,ImGuiWindowFlags_NoScrollbar);
    ImGui::TextUnformatted(name); ImGui::SameLine(ImGui::GetWindowWidth()-56); ImGui::Checkbox("##toggle",&value);
    ImGui::TextDisabled("%s",desc); ImGui::EndChild(); ImGui::PopID();
}


bool drawModuleOption(ModuleOption& o){
    bool changed=false;
    ImGui::PushID(o.key.c_str());
    switch(o.type){
        case OptionType::Bool:
            changed=ImGui::Checkbox(o.label.c_str(),&o.boolValue);
            break;
        case OptionType::Float:
            changed=ImGui::SliderFloat(o.label.c_str(),&o.floatValue,o.floatMin,o.floatMax,"%.2f");
            break;
        case OptionType::Int:
            changed=ImGui::SliderInt(o.label.c_str(),&o.intValue,o.intMin,o.intMax);
            break;
        case OptionType::Color: {
            float c[4]{o.colorValue.r,o.colorValue.g,o.colorValue.b,o.colorValue.a};
            if(ImGui::ColorEdit4(o.label.c_str(),c)){
                o.colorValue={c[0],c[1],c[2],c[3]};
                changed=true;
            }
            break;
        }
        case OptionType::Choice: {
            const char* preview=(o.choiceIndex>=0 && o.choiceIndex<(int)o.choices.size())?o.choices[o.choiceIndex].c_str():"";
            if(ImGui::BeginCombo(o.label.c_str(),preview)){
                for(int i=0;i<(int)o.choices.size();++i){
                    const bool selected=i==o.choiceIndex;
                    if(ImGui::Selectable(o.choices[i].c_str(),selected)){o.choiceIndex=i;changed=true;}
                    if(selected)ImGui::SetItemDefaultFocus();
                }
                ImGui::EndCombo();
            }
            break;
        }
        case OptionType::Text: {
            char buf[512]{};
            strncpy_s(buf,o.textValue.c_str(),sizeof(buf)-1);
            if(ImGui::InputText(o.label.c_str(),buf,sizeof(buf))){
                o.textValue=buf; changed=true;
            }
            break;
        }
    }
    ImGui::PopID();
    return changed;
}

void drawHudStyleEditor(ModuleConfig& m){
    if(!m.hud)return;
    ImGui::SeparatorText("HUD appearance");
    ImGui::SliderFloat("HUD scale",&m.hudStyle.scale,0.5f,3.0f,"%.2fx");
    ImGui::SliderFloat("Text size",&m.hudStyle.textSize,0.5f,2.5f,"%.2fx");
    ImGui::SliderFloat("Opacity",&m.hudStyle.opacity,0.1f,1.0f,"%.2f");
    ImGui::SliderFloat("Corner radius",&m.hudStyle.cornerRadius,0.0f,18.0f,"%.1f");
    ImGui::Checkbox("Background",&m.hudStyle.background);

    float text[4]{m.hudStyle.textColor.r,m.hudStyle.textColor.g,m.hudStyle.textColor.b,m.hudStyle.textColor.a};
    if(ImGui::ColorEdit4("Text color",text))m.hudStyle.textColor={text[0],text[1],text[2],text[3]};

    float bg[4]{m.hudStyle.backgroundColor.r,m.hudStyle.backgroundColor.g,m.hudStyle.backgroundColor.b,m.hudStyle.backgroundColor.a};
    if(ImGui::ColorEdit4("Background color",bg))m.hudStyle.backgroundColor={bg[0],bg[1],bg[2],bg[3]};

    float accent[4]{m.hudStyle.accentColor.r,m.hudStyle.accentColor.g,m.hudStyle.accentColor.b,m.hudStyle.accentColor.a};
    if(ImGui::ColorEdit4("Accent color",accent))m.hudStyle.accentColor={accent[0],accent[1],accent[2],accent[3]};
}

void registryModuleCard(ModuleConfig& m){
    if(!matchSearch(m.name.c_str())) return;
    ImGui::PushID(m.id.c_str());
    ImGui::BeginChild(("##module_"+m.id).c_str(),ImVec2(0,116),true,ImGuiWindowFlags_NoScrollbar);
    ImGui::TextUnformatted(m.name.c_str());
    ImGui::SameLine(ImGui::GetWindowWidth()-72);
    if(ImGui::Checkbox("##enabled",&m.enabled)) ModuleRegistry::Get().Save();
    ImGui::TextDisabled("%s | %s",m.category.c_str(),ModuleRegistry::Get().StateText(m.state));
    if(!m.options.empty()){
        const auto& first=m.options.front();
        ImGui::TextDisabled("Settings: %zu | first: %s",m.options.size(),first.label.c_str());
    }else{
        ImGui::TextDisabled("No extra settings");
    }
    ImGui::TextDisabled("Select in Advanced Settings below to edit.");
    ImGui::EndChild();
    ImGui::PopID();
}

void placeWindow(const char* name,HudPosition& p, bool editor, float scale, const std::function<void()>& body){
    ImGui::SetNextWindowPos({p.x,p.y},ImGuiCond_Once);
    ImGuiWindowFlags f=ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_AlwaysAutoResize|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoFocusOnAppearing;
    if(!editor) f|=ImGuiWindowFlags_NoInputs|ImGuiWindowFlags_NoMove;
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{10*scale,7*scale}); ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,8*scale);
    ImGui::PushStyleColor(ImGuiCol_WindowBg,{0.04f,0.025f,0.07f,0.86f}); ImGui::PushStyleColor(ImGuiCol_Border,{0.58f,0.12f,0.72f,0.95f});
    ImGui::Begin(name,nullptr,f); ImGui::SetWindowFontScale(scale); body();
    if(editor){ auto pos=ImGui::GetWindowPos(); p.x=pos.x; p.y=pos.y; }
    ImGui::End(); ImGui::PopStyleColor(2); ImGui::PopStyleVar(2);
}

void placeModuleWindow(ModuleConfig& m,const char* id,bool edit,const std::function<void()>& fn){
    auto& p=m.hudStyle;
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,p.cornerRadius);
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha,p.opacity);

    ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(p.textColor.r,p.textColor.g,p.textColor.b,p.textColor.a));
    ImGui::PushStyleColor(ImGuiCol_WindowBg,ImVec4(
        p.backgroundColor.r,p.backgroundColor.g,p.backgroundColor.b,
        p.background ? p.backgroundColor.a : 0.0f));

    ImGui::SetNextWindowPos({p.x,p.y},ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(p.background ? p.backgroundColor.a : 0.0f);
    int flags=ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_AlwaysAutoResize|ImGuiWindowFlags_NoSavedSettings;
    if(!edit) flags|=ImGuiWindowFlags_NoInputs|ImGuiWindowFlags_NoMove;
    ImGui::Begin(id,nullptr,flags);
    ImGui::SetWindowFontScale(p.textSize*p.scale);
    fn();
    if(edit){
        const auto pos=ImGui::GetWindowPos();
        p.x=pos.x; p.y=pos.y;
    }
    ImGui::End();

    ImGui::PopStyleColor(2);
    ImGui::PopStyleVar(2);
}


void keyBox(const char* label,bool down){
    ImGui::PushStyleColor(ImGuiCol_Button,down?ImVec4(0.42f,0.16f,0.62f,1):ImVec4(0.10f,0.06f,0.14f,0.95f));
    ImGui::Button(label,{42,36}); ImGui::PopStyleColor();
}


void drawCrosshair(){
    auto* m=ModuleRegistry::Get().Find("crosshair");
    if(!m || !m->enabled || UI::MenuOpen()) return;

    auto& mods=ModuleRegistry::Get();
    auto& io=ImGui::GetIO();
    const ImVec2 c{io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f};

    float length=mods.Float("crosshair","length",8.0f);
    float gap=mods.Float("crosshair","gap",3.0f);
    float thickness=mods.Float("crosshair","thickness",2.0f);
    Color4 color{1,1,1,1};
    if(auto* o=mods.Option(*m,"color");o && o->type==OptionType::Color)color=o->colorValue;

    const ImU32 col=ImGui::ColorConvertFloat4ToU32({color.r,color.g,color.b,color.a});
    auto* dl=ImGui::GetForegroundDrawList();

    dl->AddLine({c.x-gap-length,c.y},{c.x-gap,c.y},col,thickness);
    dl->AddLine({c.x+gap,c.y},{c.x+gap+length,c.y},col,thickness);
    dl->AddLine({c.x,c.y-gap-length},{c.x,c.y-gap},col,thickness);
    dl->AddLine({c.x,c.y+gap},{c.x,c.y+gap+length},col,thickness);
}

std::string fmtTimer(double sec,bool hundredths){
    if(sec<0)sec=0; int total=static_cast<int>(sec); int h=total/3600,m=(total%3600)/60,s=total%60; char b[64]{};
    if(hundredths){ int cs=static_cast<int>((sec-total)*100.0); snprintf(b,sizeof(b),"%02d:%02d:%02d.%02d",h,m,s,cs); }
    else if(h>0) snprintf(b,sizeof(b),"%02d:%02d:%02d",h,m,s); else snprintf(b,sizeof(b),"%02d:%02d",m,s);
    return b;
}
}

void UI::Initialize(HWND){ theme(); ModuleRegistry::Get().Initialize(); Timer().SetDuration(Settings::Get().timerSeconds); }
void UI::Shutdown(){ RadioPlayer::Get().Shutdown(); Settings::Get().Save(); ModuleRegistry::Get().Save(); }
bool UI::MenuOpen(){return g_menu;} bool UI::WantsInput(){return g_menu||Settings::Get().hudEdit;}
void UI::NewFrame(HWND hwnd){
    Input::Get().Update(hwnd); Metrics::Get().OnFrame();
    RadioPlayer::Get().Update();
    AutoTextController::Get().Update(hwnd,Input::Get().State().foreground && !g_menu && !Settings::Get().hudEdit);
    ToggleInputController::Get().Update(hwnd,Input::Get().State().foreground && !g_menu && !Settings::Get().hudEdit);
    if(Input::Get().ConsumeRightShiftPressed()){
        if(!g_menu){
            // Release any latched movement key before WIRZA begins consuming input.
            ToggleInputController::Get().ReleaseAll(hwnd);
            // Open Minecraft's own pause screen first, while WIRZA is not yet
            // consuming keyboard input. The WIRZA panel is then drawn above it.
            sendEscapeToGame(hwnd);
            g_menu=true;
        }else{
            // Stop consuming input before forwarding ESC so Minecraft can close
            // its native pause screen and return to gameplay.
            g_menu=false;
            Settings::Get().hudEdit=false;
            Settings::Get().Save();
            sendEscapeToGame(hwnd);
        }
    }
    ImGui::GetIO().MouseDrawCursor=g_menu||Settings::Get().hudEdit;
    if(g_menu||Settings::Get().hudEdit){ ClipCursor(nullptr); ReleaseCapture(); }
    if(g_lastMenu&&!g_menu) Settings::Get().Save(); g_lastMenu=g_menu;
}
LRESULT UI::WndProc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp,bool& handled){
    if(!g_menu && !Settings::Get().hudEdit && ToggleInputController::Get().ProcessWndProc(hwnd,msg,wp,lp)){ handled=true; return 0; }
    // Zoom FOV adjustment works while C is held during gameplay.
    if(msg==WM_MOUSEWHEEL && !g_menu && !Settings::Get().hudEdit){
        auto& mods=ModuleRegistry::Get();
        auto* zoom=mods.Find("zoom");
        const auto& input=Input::Get().State();
        if(zoom && zoom->enabled && input.foreground && input.c){
            auto* target=mods.Option(*zoom,"target_fov");
            auto* step=mods.Option(*zoom,"wheel_step");
            if(target && step && target->type==OptionType::Float && step->type==OptionType::Float){
                const int delta=GET_WHEEL_DELTA_WPARAM(wp);
                target->floatValue += (delta>0 ? -step->floatValue : step->floatValue);
                target->floatValue=std::clamp(target->floatValue,target->floatMin,target->floatMax);
                mods.Save();
                handled=true;
                return 0;
            }
        }
    }

    if(WantsInput()){
        ImGui_ImplWin32_WndProcHandler(hwnd,msg,wp,lp);
        switch(msg){
            case WM_INPUT: case WM_MOUSEMOVE:
            case WM_LBUTTONDOWN: case WM_LBUTTONUP:
            case WM_RBUTTONDOWN: case WM_RBUTTONUP:
            case WM_MOUSEWHEEL:
            case WM_KEYDOWN: case WM_KEYUP: case WM_CHAR:
                handled=true; return 0;
            default: break;
        }
    }
    handled=false;
    return 0;
}

void UI::Render(){ VisualEffects::Render(); if(!g_menu || Settings::Get().hudEdit) DrawHud(); drawCrosshair(); if(g_menu)DrawMenu(); }

void UI::DrawHud(){
    auto& s=Settings::Get();
    if(s.hideAllHud)return;
    const auto& in=Input::Get().State();
    const float z=s.hudScale;
    auto& mods=ModuleRegistry::Get();

    auto enabled=[&](const char* id,bool fallback=false){
        auto* m=mods.Find(id);
        return m?m->enabled:fallback;
    };

    if(enabled("fps",s.fps)) placeWindow("##WIRZA_FPS",s.fpsPos,s.hudEdit,z,[&]{ ImGui::Text("FPS"); ImGui::TextColored({0.65f,0.35f,1,1},"%d",Metrics::Get().Fps()); });
    if(enabled("cps",s.cps)) placeWindow("##WIRZA_CPS",s.cpsPos,s.hudEdit,z,[&]{ ImGui::Text("CPS"); ImGui::TextColored({0.65f,0.35f,1,1},"%d",Metrics::Get().TotalCps()); });
    if(enabled("keystrokes",s.wasd)) placeWindow("##WIRZA_KEYS",s.wasdPos,s.hudEdit,z,[&]{
        ImGui::Indent(45); keyBox("W",in.w); ImGui::Unindent(45);
        keyBox("A",in.a); ImGui::SameLine(); keyBox("S",in.s); ImGui::SameLine(); keyBox("D",in.d);
        ImGui::Button(in.space?"SPACE *":"SPACE",{130,28});
        ImGui::Text("%s  %s",in.shift?"SHIFT":"shift",in.ctrl?"CTRL":"ctrl");
        ImGui::Text("LMB %d   RMB %d",Metrics::Get().LeftCps(),Metrics::Get().RightCps());
    });
    if(s.timer) placeWindow("##WIRZA_TIMER",s.timerPos,s.hudEdit,z,[&]{ ImGui::Text("Timer"); auto t=fmtTimer(Timer().Remaining(),false); ImGui::TextColored({0.65f,0.35f,1,1},"%s",t.c_str()); });
    if(enabled("stopwatch",s.stopwatch)) placeWindow("##WIRZA_STOPWATCH",s.stopwatchPos,s.hudEdit,z,[&]{ ImGui::Text("Stopwatch"); auto t=fmtTimer(Stopwatch().Elapsed(),true); ImGui::TextColored({0.65f,0.35f,1,1},"%s",t.c_str()); });

    if(auto* m=mods.Find("clock"); m && m->enabled){
        HudPosition p{m->hudStyle.x,m->hudStyle.y};
        placeWindow("##WIRZA_CLOCK",p,s.hudEdit,m->hudStyle.scale,[&]{ auto t=RuntimeStats::Get().ClockText(); ImGui::Text("Clock"); ImGui::Text("%s",t.c_str()); });
        if(s.hudEdit){m->hudStyle.x=p.x;m->hudStyle.y=p.y;}
    }
    if(auto* m=mods.Find("playtime"); m && m->enabled){
        HudPosition p{m->hudStyle.x,m->hudStyle.y};
        placeWindow("##WIRZA_PLAYTIME",p,s.hudEdit,m->hudStyle.scale,[&]{ auto t=fmtTimer(RuntimeStats::Get().PlaytimeSeconds(),false); ImGui::Text("Playtime"); ImGui::Text("%s",t.c_str()); });
        if(s.hudEdit){m->hudStyle.x=p.x;m->hudStyle.y=p.y;}
    }
    if(auto* m=mods.Find("memory_usage"); m && m->enabled){
        HudPosition p{m->hudStyle.x,m->hudStyle.y};
        placeWindow("##WIRZA_MEMORY",p,s.hudEdit,m->hudStyle.scale,[&]{
            const double mib=RuntimeStats::Get().WorkingSetBytes()/(1024.0*1024.0);
            ImGui::Text("Memory"); ImGui::Text("%.0f MiB",mib);
        });
        if(s.hudEdit){m->hudStyle.x=p.x;m->hudStyle.y=p.y;}
    }



    auto& bridge=GameDataBridge::Get();

    if(auto* m=mods.Find("direction_hud"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_DIRECTION",s.hudEdit,[&]{
            const int mode=([&]{
                auto* o=mods.Option(*m,"mode");
                return (o && o->type==OptionType::Choice)?o->choiceIndex:0;
            })();
            if(!bridge.PlayerReady()){
                ImGui::Text("Direction: --");
                ImGui::TextDisabled("%s",bridge.StateText());
            }else{
                float yaw=bridge.Yaw();
                while(yaw<0)yaw+=360.0f;
                while(yaw>=360.0f)yaw-=360.0f;
                if(mode==0) ImGui::Text("%s",bridge.CardinalDirection());
                else if(mode==1) ImGui::Text("%.0f deg",yaw);
                else ImGui::Text("%s  %.0f deg",bridge.CardinalDirection(),yaw);
            }
        });
    }

    if(auto* m=mods.Find("item_counter"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_ITEM_COUNTER",s.hudEdit,[&]{
            const std::string token=mods.Text("item_counter","item_name","totem");
            if(!bridge.InventoryReady()){
                ImGui::Text("Item: --");
                ImGui::TextDisabled("%s",bridge.StateText());
            }else{
                ImGui::Text("%s: %d",token.c_str(),bridge.CountItemContains(token));
            }
        });
    }

    if(auto* m=mods.Find("totem_counter"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_TOTEM_COUNTER",s.hudEdit,[&]{
            if(!bridge.InventoryReady()){
                ImGui::Text("Totems: --");
            }else{
                const int count=bridge.CountItemContains("totem");
                ImGui::Text("Totems: %d",count);
            }
        });
    }

    if(auto* m=mods.Find("potion_counter"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_POTION_COUNTER",s.hudEdit,[&]{
            if(!bridge.InventoryReady()){
                ImGui::Text("Potions: --");
            }else{
                ImGui::Text("Potions: %d",bridge.CountItemContains("potion"));
            }
        });
    }


    if(auto* m=mods.Find("armor_status"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_ARMOR_STATUS",s.hudEdit,[&]{
            if(!bridge.ArmorReady()){
                ImGui::Text("Armor: --");
                ImGui::TextDisabled("Waiting for armor data");
            }else{
                const bool showDur=mods.Bool("armor_status","show_durability",true);
                const int low=mods.Int("armor_status","low_durability",20);
                const bool vertical=([&]{
                    auto* o=mods.Option(*m,"layout");
                    return o && o->type==OptionType::Choice && o->choiceIndex==1;
                })();

                int shown=0;
                for(int i=0;i<4;++i){
                    const auto& a=bridge.Player().armor[i];
                    if(!a.valid) continue;
                    const std::string label=!a.itemId.empty()?a.itemId:a.translateName;
                    if(!vertical && shown>0) ImGui::SameLine();
                    if(showDur && a.maxDamage>0){
                        const bool warn=a.durabilityPercent<=low;
                        if(warn) ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(1.0f,0.25f,0.2f,1.0f));
                        ImGui::Text("%s %.0f%%",label.c_str(),a.durabilityPercent);
                        if(warn) ImGui::PopStyleColor();
                    }else{
                        ImGui::Text("%s",label.c_str());
                    }
                    ++shown;
                }
                if(mods.Bool("armor_status","show_held_item",true) && bridge.Player().heldItem.valid){
                    if(!vertical && shown>0) ImGui::SameLine();
                    ImGui::Text("Hand: %s",bridge.Player().heldItem.itemId.c_str());
                }
                if(shown==0) ImGui::Text("Armor: none");
            }
        });
    }

    if(auto* m=mods.Find("ping"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_PING",s.hudEdit,[&]{
            if(!bridge.NetworkReady()){
                ImGui::Text("Ping: --");
            }else{
                ImGui::Text("Ping: %d%s",bridge.Network().pingMs,
                    mods.Bool("ping","show_ms",true) ? " ms" : "");
            }
        });
    }

    if(auto* m=mods.Find("server_address"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_SERVER",s.hudEdit,[&]{
            if(!bridge.NetworkReady()){
                ImGui::Text("Server: Local / --");
            }else{
                const auto& n=bridge.Network();
                std::string text;
                if(mods.Bool("server_address","prefer_hostname",true) && !n.unresolvedUrl.empty())
                    text=n.unresolvedUrl;
                else if(!n.hostIp.empty()) text=n.hostIp;
                else text=n.unresolvedUrl;

                if(!mods.Bool("server_address","hide_port",false) && n.port>0)
                    text += ":"+std::to_string(n.port);

                ImGui::Text("Server: %s",text.c_str());
                if(!n.region.empty()) ImGui::TextDisabled("%s",n.region.c_str());
            }
        });
    }

    if(auto* m=mods.Find("reach_display"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_REACH",s.hudEdit,[&]{
            const int timeout=mods.Int("reach_display","timeout_ms",2500);
            const int decimals=mods.Int("reach_display","decimals",2);
            if(!bridge.HasRecentReach(timeout)){
                ImGui::Text("Reach: --");
            }else{
                ImGui::Text(("Reach: %."+std::to_string(decimals)+"f%s").c_str(),
                    bridge.LastReach(),
                    mods.Bool("reach_display","show_blocks_suffix",true) ? " blocks" : "");
            }
        });
    }

    if(auto* m=mods.Find("waila"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_WAILA",s.hudEdit,[&]{
            if(!bridge.TargetReady()){
                ImGui::Text("WAILA: --");
            }else{
                const auto& t=bridge.Target();
                if(t.type==TargetType::Block && mods.Bool("waila","show_block",true)){
                    ImGui::Text("%s",t.name.c_str());
                    if(!t.identifier.empty()) ImGui::TextDisabled("%s",t.identifier.c_str());
                }else if(t.type==TargetType::Entity && mods.Bool("waila","show_entity",true)){
                    ImGui::Text("%s",t.name.c_str());
                    if(!t.identifier.empty()) ImGui::TextDisabled("%s",t.identifier.c_str());
                }else{
                    ImGui::Text("WAILA: hidden by settings");
                }
                if(mods.Bool("waila","show_distance",false))
                    ImGui::Text("%.2f blocks",t.distance);
            }
        });
    }

    if(auto* m=mods.Find("horse_stats"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_HORSE",s.hudEdit,[&]{
            if(!bridge.Horse().valid){
                ImGui::Text("Horse: --");
                ImGui::TextDisabled("Look at a horse");
            }else{
                const auto& h=bridge.Horse();
                ImGui::Text("%s",h.identifier.c_str());
                if(mods.Bool("horse_stats","show_health",true)){
                    if(h.health>=0.0f) ImGui::Text("Health: %.1f / %.1f",h.health,h.maxHealth);
                    else ImGui::TextDisabled("Health: adapter pending");
                }
                if(mods.Bool("horse_stats","show_speed",true))
                    ImGui::TextDisabled("Speed stat: adapter pending");
                if(mods.Bool("horse_stats","show_jump",true))
                    ImGui::TextDisabled("Jump stat: adapter pending");
            }
        });
    }

    if(auto* m=mods.Find("potion_effects"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_EFFECTS",s.hudEdit,[&]{
            if(!bridge.PotionEffectsReady()){
                ImGui::Text("Potion Effects");
                ImGui::TextDisabled("Unsupported by current verified adapter");
            }else if(bridge.PotionEffects().empty()){
                ImGui::Text("Potion Effects: none");
            }else{
                for(const auto& e:bridge.PotionEffects()){
                    ImGui::Text("%s %d",e.name.c_str(),e.amplifier+1);
                }
            }
        });
    }

    auto& ext=ExtendedFeatureBridge::Get();
    if(auto* m=mods.Find("scoreboard"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_SCOREBOARD",s.hudEdit,[&]{
            const auto& snap=ext.Scoreboard();
            if(!snap.ready){ ImGui::Text("Scoreboard"); ImGui::TextDisabled("Adapter pending"); return; }
            ImGui::TextUnformatted(snap.title.c_str()); ImGui::Separator();
            const bool hide=mods.Bool("scoreboard","hide_numbers",false);
            for(const auto& row:snap.rows){ if(hide) ImGui::Text("%s",row.first.c_str()); else ImGui::Text("%s  %d",row.first.c_str(),row.second); }
        });
    }
    if(auto* m=mods.Find("boss_bar"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_BOSSBAR",s.hudEdit,[&]{
            const auto& snap=ext.BossBar();
            if(!snap.ready){ ImGui::Text("Boss Bar"); ImGui::TextDisabled("Adapter pending"); return; }
            ImGui::TextUnformatted(snap.title.c_str());
            const auto c=optionColor(*m,"bar_color",{0.65f,0.35f,1.0f,1.0f});
            ImGui::PushStyleColor(ImGuiCol_PlotHistogram,{c.r,c.g,c.b,c.a});
            ImGui::ProgressBar(std::clamp(snap.progress,0.0f,1.0f),{260.0f*mods.Float("boss_bar","scale",1.0f),0});
            ImGui::PopStyleColor();
        });
    }
    if(auto* m=mods.Find("chat_mod"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_CHAT",s.hudEdit,[&]{
            const auto& snap=ext.Chat();
            if(!snap.ready){ ImGui::Text("Chat Mod"); ImGui::TextDisabled("Adapter pending"); return; }
            const bool timestamps=mods.Bool("chat_mod","timestamps",false);
            const int start=std::max(0,(int)snap.lines.size()-8);
            for(int i=start;i<(int)snap.lines.size();++i){
                if(timestamps){
                    std::time_t tt=std::chrono::system_clock::to_time_t(snap.lines[i].received); std::tm tm{}; localtime_s(&tm,&tt);
                    char tb[16]{}; std::strftime(tb,sizeof(tb),"%H:%M",&tm); ImGui::TextDisabled("[%s]",tb); ImGui::SameLine();
                }
                ImGui::TextWrapped("%s",snap.lines[i].text.c_str());
            }
        });
    }
    if(auto* m=mods.Find("titles"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_TITLES",s.hudEdit,[&]{
            const auto& snap=ext.Title();
            if(!snap.ready){ ImGui::Text("Titles"); ImGui::TextDisabled("Adapter pending"); return; }
            const auto c=optionColor(*m,"title_color",{1,1,1,1});
            ImGui::PushStyleColor(ImGuiCol_Text,{c.r,c.g,c.b,c.a*mods.Float("titles","opacity",1.0f)});
            ImGui::SetWindowFontScale(m->hudStyle.textSize*m->hudStyle.scale*mods.Float("titles","scale",1.0f));
            ImGui::TextUnformatted(snap.title.c_str()); if(!snap.subtitle.empty()) ImGui::TextDisabled("%s",snap.subtitle.c_str());
            ImGui::PopStyleColor();
        });
    }
    if(auto* m=mods.Find("pack_display"); m && m->enabled){
        placeModuleWindow(*m,"##WIRZA_PACK",s.hudEdit,[&]{
            const auto& snap=ext.Pack();
            if(!snap.ready){ ImGui::Text("Pack"); ImGui::TextDisabled("Adapter pending"); return; }
            if(mods.Bool("pack_display","show_name",true)){
                auto name=snap.name; const int mx=mods.Int("pack_display","max_name",32); if((int)name.size()>mx) name=name.substr(0,mx)+"...";
                ImGui::Text("Pack: %s",name.c_str());
            }
        });
    }

}

void UI::DrawMenu(){
    auto& s=Settings::Get(); auto& io=ImGui::GetIO();

    // Keep Minecraft's native pause screen visible behind WIRZA instead of
    // replacing the whole frame with an opaque client menu. Menu Blur owns the
    // configurable backdrop when enabled; otherwise keep the legacy dim.
    auto* menuBlur=ModuleRegistry::Get().Find("menu_blur");
    if(!menuBlur || !menuBlur->enabled)
        ImGui::GetBackgroundDrawList()->AddRectFilled({0,0},io.DisplaySize,IM_COL32(0,0,0,92));

    ImVec2 panel{1050.f,650.f};
    panel.x=std::min(panel.x,std::max(640.f,io.DisplaySize.x-40.f));
    panel.y=std::min(panel.y,std::max(480.f,io.DisplaySize.y-40.f));
    ImGui::SetNextWindowPos({io.DisplaySize.x*0.5f,io.DisplaySize.y*0.5f},ImGuiCond_Always,{0.5f,0.5f});
    ImGui::SetNextWindowSize(panel,ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(0.955f);
    ImGui::Begin("##WIRZA_CLIENT_MENU",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoSavedSettings);

    const float sidebar=205.f;
    ImGui::BeginChild("sidebar",{sidebar,0},true);
    if(LogoTexture::Ready()){
        const float logo=118.f;
        ImGui::SetCursorPosX((ImGui::GetContentRegionAvail().x-logo)*0.5f+ImGui::GetCursorPosX());
        ImGui::Image(LogoTexture::Id(),{logo,logo});
        ImGui::Spacing();
    }
    ImGui::TextDisabled("MODULES");
    if(ImGui::Selectable("All Modules",g_category==0))g_category=0;
    if(ImGui::Selectable("HUD",g_category==1))g_category=1;
    if(ImGui::Selectable("Visual",g_category==2))g_category=2;
    if(ImGui::Selectable("Other",g_category==3))g_category=3;
    ImGui::Spacing(); ImGui::Separator(); ImGui::TextDisabled("EDITOR");
    if(ImGui::Checkbox("HUD Editor",&s.hudEdit))s.Save();
    ImGui::Spacing(); ImGui::TextDisabled("ZOOM STATUS"); ImGui::TextWrapped("%s",GameBridge::ZoomStatus());
    ImGui::Spacing(); ImGui::TextDisabled("GAME DATA"); ImGui::TextWrapped("%s",GameDataBridge::Get().StateText());
    ImGui::Spacing(); ImGui::TextDisabled("FIRST-PERSON VISUALS"); ImGui::TextWrapped("%s",FirstPersonRenderBridge::Get().StatusText());
    ImGui::Spacing(); ImGui::TextDisabled("ITEM / MATERIAL VISUALS"); ImGui::TextWrapped("%s",ItemMaterialRenderBridge::Get().StatusText());
    ImGui::Spacing(); ImGui::TextDisabled("ACTOR OVERLAY VISUALS"); ImGui::TextWrapped("%s",ActorOverlayRenderBridge::Get().StatusText());
    ImGui::Spacing(); ImGui::TextDisabled("ENVIRONMENT VISUALS"); ImGui::TextWrapped("%s",EnvironmentRenderBridge::Get().StatusText());
    ImGui::Spacing(); ImGui::TextDisabled("EXTENDED UI / PARTICLES"); ImGui::TextWrapped("%s",ExtendedFeatureBridge::Get().StatusText());
    ImGui::Spacing(); ImGui::TextDisabled("RADIO"); ImGui::TextWrapped("%s",RadioPlayer::Get().StatusText());
    ImGui::Spacing(); ImGui::TextDisabled("AUTO TEXT"); ImGui::TextWrapped("%s",AutoTextController::Get().StatusText());
    ImGui::TextDisabled("Armor: %s",GameDataBridge::Get().ArmorReady()?"ready":"waiting");
    ImGui::TextDisabled("Network: %s",GameDataBridge::Get().NetworkReady()?"ready":"waiting");
    ImGui::TextDisabled("Effects: %s",GameDataBridge::Get().PotionEffectsReady()?"ready":"unsupported");
    ImGui::Spacing(); ImGui::Separator();
    int implemented=0, partial=0, planned=0;
    for(const auto& m:ModuleRegistry::Get().All()){
        if(m.state==ModuleState::Implemented) ++implemented;
        else if(m.state==ModuleState::Partial) ++partial;
        else ++planned;
    }
    ImGui::TextDisabled("IMPLEMENTATION");
    ImGui::Text("Done: %d",implemented);
    ImGui::Text("Partial: %d",partial);
    ImGui::Text("Remaining: %d",planned);
    ImGui::Spacing(); ImGui::Separator();
    ImGui::TextDisabled("Right Shift: close");
    ImGui::TextDisabled("Minecraft pause menu stays behind");
    ImGui::TextDisabled("HUD: D3D12 backbuffer / OBS target");
    ImGui::EndChild(); ImGui::SameLine();

    ImGui::BeginChild("main",{0,0},false);
    ImGui::Text("Modules"); ImGui::SameLine(ImGui::GetWindowWidth()-340); ImGui::SetNextItemWidth(220); ImGui::InputTextWithHint("##search","Search modules...",g_search,sizeof(g_search)); ImGui::SameLine(); if(ImGui::Button("Save",{90,0}))s.Save();

    ImGui::SeparatorText("55 Independent Modules");
    ImGui::BeginChild("##WIRZA_55_MODULES",ImVec2(0,360),false);
    for(auto& module : ModuleRegistry::Get().All()){
        registryModuleCard(module);
    }
    ImGui::EndChild();

    ImGui::SeparatorText("Advanced Settings");
    auto& allModules=ModuleRegistry::Get().All();
    if(!allModules.empty()){
        g_selectedModule=std::clamp(g_selectedModule,0,(int)allModules.size()-1);
        if(ImGui::BeginCombo("Module",allModules[g_selectedModule].name.c_str())){
            for(int i=0;i<(int)allModules.size();++i){
                bool selected=i==g_selectedModule;
                if(ImGui::Selectable(allModules[i].name.c_str(),selected))g_selectedModule=i;
                if(selected)ImGui::SetItemDefaultFocus();
            }
            ImGui::EndCombo();
        }

        auto& selected=allModules[g_selectedModule];
        ImGui::Checkbox("Enabled",&selected.enabled);
        ImGui::TextDisabled("Status: %s",ModuleRegistry::Get().StateText(selected.state));
        if(selected.id=="glint_colorizer" || selected.id=="shiny_pots")
            ImGui::TextWrapped("Material adapter: %s",ItemMaterialRenderBridge::Get().StatusText());
        if(selected.id=="hit_color")
            ImGui::TextWrapped("Actor overlay adapter: %s",ActorOverlayRenderBridge::Get().StatusText());
        if(selected.id=="fog" || selected.id=="overlay_mod")
            ImGui::TextWrapped("Environment adapter: %s",EnvironmentRenderBridge::Get().StatusText());
        if(selected.id=="particle_changer" || selected.id=="scoreboard" || selected.id=="boss_bar" || selected.id=="chat_mod" || selected.id=="titles" || selected.id=="pack_display" || selected.id=="scrollable_tooltips" || selected.id=="2d_items" || selected.id=="gui_scale" || selected.id=="item_physics" || selected.id=="kill_sounds" || selected.id=="nick_hider" || selected.id=="pack_organizer")
            ImGui::TextWrapped("Extended adapter: %s",ExtendedFeatureBridge::Get().StatusText());
        if(selected.id=="radio"){
            ImGui::TextWrapped("Radio: %s",RadioPlayer::Get().StatusText());
            if(ImGui::Button("Play station")) RadioPlayer::Get().PlayConfigured(); ImGui::SameLine();
            if(ImGui::Button("Stop radio")) RadioPlayer::Get().Stop();
        }
        if(selected.id=="toggle_sneak_sprint")
            ImGui::TextWrapped("Latched: sprint=%s, sneak=%s",ToggleInputController::Get().SprintLatched()?"ON":"OFF",ToggleInputController::Get().SneakLatched()?"ON":"OFF");
        if(selected.id=="auto_text_actions" || selected.id=="auto_text_hotkey")
            ImGui::TextWrapped("Auto text: %s",AutoTextController::Get().StatusText());
        if(selected.id=="damage_tint")
            ImGui::TextWrapped("Damage source: local minecraft:health attribute (read-only, 100 ms refresh)");
        drawHudStyleEditor(selected);

        if(!selected.options.empty())ImGui::SeparatorText("Module options");
        bool moduleChanged=false;
        for(auto& option:selected.options) moduleChanged|=drawModuleOption(option);
        if(moduleChanged || ImGui::Button("Save module settings")){
            ModuleRegistry::Get().Save();
        }
    }

    ImGui::SeparatorText("Quick Settings");
ImGui::SeparatorText("Profiles");
    ImGui::InputText("Profile name",g_profileName,sizeof(g_profileName));
    if(ImGui::Button("Save profile")){
        Settings::Get().Save();
        ModuleRegistry::Get().Save();
        ProfileManager::Get().SaveProfile(g_profileName);
    }
    ImGui::SameLine();
    if(ImGui::Button("Load profile")){
        ProfileManager::Get().LoadProfile(g_profileName);
    }
    ImGui::SameLine();
    if(ImGui::Button("Delete profile")){
        ProfileManager::Get().DeleteProfile(g_profileName);
    }
    auto profiles=ProfileManager::Get().ListProfiles();
    if(!profiles.empty()){
        ImGui::TextDisabled("Saved:");
        for(const auto& p:profiles){ ImGui::SameLine(); ImGui::TextUnformatted(p.c_str()); }
    }

    ImGui::Separator();
    auto cards2=[&](auto left,auto right){ ImGui::Columns(2,nullptr,false); left(); ImGui::NextColumn(); right(); ImGui::Columns(1); };
    if(g_category==0||g_category==1){
        ImGui::TextColored({0.68f,0.42f,1,1},"HUD");
        cards2([&]{moduleCard("fps","FPS","Minecraft render FPS",s.fps); moduleCard("wasd","WASD","Keyboard movement state",s.wasd); moduleCard("timer","Timer","Countdown timer",s.timer);},
               [&]{moduleCard("cps","CPS","Clicks in the last second",s.cps); moduleCard("mouse","LMB / RMB","Mouse button CPS",s.mouse); moduleCard("stopwatch","Stopwatch","Count-up stopwatch",s.stopwatch);});
    }
    if(g_category==0||g_category==2){
        ImGui::Spacing(); ImGui::TextColored({0.68f,0.42f,1,1},"VISUAL");
        cards2([&]{moduleCard("zoom","Native Zoom (FOV)","Hold C: target FOV is configurable in Advanced Settings",s.zoom);},
               [&]{ ImGui::BeginChild("hudscale",{0,104},true); ImGui::Text("HUD Scale"); ImGui::TextDisabled("Size of all HUD modules"); ImGui::SliderFloat("##scale",&s.hudScale,0.60f,2.00f,"%.2fx"); ImGui::EndChild(); });
    }
    if(g_category==0||g_category==3){
        ImGui::Spacing(); ImGui::TextColored({0.68f,0.42f,1,1},"OTHER");
        cards2([&]{moduleCard("hide","Hide All HUD","Temporarily hide every HUD module",s.hideAllHud);},
               [&]{ ImGui::BeginChild("reset",{0,78},true); ImGui::Text("HUD Positions"); if(ImGui::Button("Reset positions")){s.fpsPos={20,20};s.cpsPos={20,72};s.wasdPos={20,124};s.mousePos={20,250};s.timerPos={20,330};s.stopwatchPos={20,385};} ImGui::EndChild(); });
    }
    ImGui::Spacing(); ImGui::Separator();
    ImGui::TextColored({0.68f,0.42f,1,1},"TIMER CONTROLS");
    int mins=s.timerSeconds/60, secs=s.timerSeconds%60; ImGui::SetNextItemWidth(80); ImGui::InputInt("Minutes",&mins); ImGui::SameLine(); ImGui::SetNextItemWidth(80); ImGui::InputInt("Seconds",&secs);
    mins=std::clamp(mins,0,999); secs=std::clamp(secs,0,59); int newDur=std::max(1,mins*60+secs); if(newDur!=s.timerSeconds){s.timerSeconds=newDur;Timer().SetDuration(newDur);}
    if(ImGui::Button(Timer().Running()?"Pause Timer":"Start Timer"))Timer().StartPause(); ImGui::SameLine(); if(ImGui::Button("Reset Timer"))Timer().Reset(); ImGui::SameLine();
    if(ImGui::Button(Stopwatch().Running()?"Pause Stopwatch":"Start Stopwatch"))Stopwatch().StartPause(); ImGui::SameLine(); if(ImGui::Button("Reset Stopwatch"))Stopwatch().Reset();
    ImGui::EndChild(); ImGui::End();
}

}