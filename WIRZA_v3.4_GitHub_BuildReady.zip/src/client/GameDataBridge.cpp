#include "GameDataBridge.h"
#include "PatternScan.h"
#include "BedrockEcs.h"

#include <MinHook.h>
#include <windows.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cctype>
#include <cstring>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace wirza {
namespace {

constexpr const char* kPlatformGameCorePattern="4C 89 3D ? ? ? ? 4D 85 FF";

constexpr const char* kActorAttackPattern=
    "55 41 57 41 56 41 55 41 54 56 57 53 48 81 EC ? ? ? ? "
    "48 8D AC 24 ? ? ? ? 0F 29 B5 ? ? ? ? 48 C7 85 ? ? ? ? ? ? ? ? "
    "4D 89 CF 4D 89 C6 48 89 D6 48 89 CF 41 8B 80";

constexpr const char* kAveragePingPattern=
    "48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 31 E0 48 89 84 24 ? ? ? ? "
    "4C 8B 02 4C 3B 05 ? ? ? ? 0F 85 ? ? ? ? 0F B7 42 ?";

constexpr const char* kItemDamagePattern=
    "56 57 48 83 EC ? 48 8B 05 ? ? ? ? 48 31 E0 48 89 44 24 ? "
    "48 8B 41 ? 48 85 C0 74 ? 48 83 38";

constexpr ptrdiff_t kWinMainPlatformOffset=0x8;
constexpr ptrdiff_t kPlatformMinecraftGameOffset=0x18;
constexpr ptrdiff_t kMinecraftGamePrimaryClientsOffset=0x938;

constexpr ptrdiff_t kClientInstanceMinecraftOffset=0x1A8;
constexpr ptrdiff_t kClientInstancePacketSenderOffset=0x1C8;
constexpr size_t kClientInstanceGetRegionVtableIndex=0x1E;
constexpr size_t kClientInstanceGetLocalPlayerVtableIndex=0x1F;

constexpr ptrdiff_t kActorEntityContextOffset=0x8;
constexpr ptrdiff_t kActorStateVectorOffset=0x218;
constexpr ptrdiff_t kActorAabbShapeOffset=0x220;
constexpr ptrdiff_t kActorRotationOffset=0x228;
constexpr ptrdiff_t kPlayerSuppliesOffset=0x5B8;

constexpr ptrdiff_t kPlayerInventorySelectedSlotOffset=0x10;
constexpr ptrdiff_t kPlayerInventoryInventoryOffset=0xB8;
constexpr size_t kInventoryGetItemVtableIndex=7;

constexpr ptrdiff_t kItemStackWeakItemOffset=0x8;
constexpr ptrdiff_t kItemStackCountOffset=0x22;
constexpr ptrdiff_t kItemStackValidOffset=0x23;

constexpr ptrdiff_t kItemTranslateNameOffset=0xB0;
constexpr ptrdiff_t kItemIdStringOffset=0xD8;
constexpr size_t kItemGetMaxDamageVtableIndex=0x24;

constexpr ptrdiff_t kPacketSenderNetworkSystemOffset=0x20;
constexpr ptrdiff_t kNetworkSystemRemoteConnectorOffset=0xF8;
constexpr ptrdiff_t kRemoteConnectorNetherNetOffset=0x68;
constexpr ptrdiff_t kRemoteConnectorRakNetOffset=0x70;
constexpr size_t kRemoteGetConnectedGameInfoVtableIndex=0x3;

constexpr ptrdiff_t kConnectionHostIpOffset=0x8;
constexpr ptrdiff_t kConnectionUnresolvedUrlOffset=0x28;
constexpr ptrdiff_t kConnectionRegionOffset=0x48;
constexpr ptrdiff_t kConnectionPortOffset=0x8C;

constexpr ptrdiff_t kMinecraftGameSessionOffset=0xC0;
constexpr ptrdiff_t kGameSessionReadyOffset=0x28;
constexpr ptrdiff_t kGameSessionControlOffset=0x30;
constexpr ptrdiff_t kGameSessionLevelOffset=0x40;
constexpr size_t kLevelGetHitResultVtableIndex=0x14F;
constexpr uint32_t kHealthAttributeId=7; // minecraft:health

constexpr size_t kBlockSourceGetBlockByPosVtableIndex=0x2;
constexpr ptrdiff_t kBlockLegacyOffset=0x68;
constexpr ptrdiff_t kBlockLegacyTranslateNameOffset=0x8;
constexpr ptrdiff_t kBlockLegacyNameStringOffset=0x98;
constexpr ptrdiff_t kBlockLegacyNamespaceOffset=0xC0;
constexpr ptrdiff_t kBlockLegacyNamespacedIdStringOffset=0xE8;

using ActorAttackFn=void*(__fastcall*)(void*,void*,void*,void*,void*);
using AveragePingFn=int(__fastcall*)(void*,char*);
ActorAttackFn g_actorAttackOriginal=nullptr;
AveragePingFn g_averagePingOriginal=nullptr;

struct RawVec2 { float x,y; };
struct RawVec3 { float x,y,z; };
struct RawAabb { RawVec3 min; RawVec3 max; };
struct RawBlockPos { int x,y,z; };

struct RawHitResult {
    RawVec3 start;
    RawVec3 end;
    int hitType;
    int8_t face;
    unsigned char pad0[3];
    RawBlockPos hitBlock;
    RawVec3 hitPos;
};

bool executableAddress(const void* p){
    if(!p) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if(!VirtualQuery(p,&mbi,sizeof(mbi))) return false;
    if(mbi.State!=MEM_COMMIT || (mbi.Protect&(PAGE_NOACCESS|PAGE_GUARD))) return false;
    const DWORD prot=mbi.Protect&0xFF;
    return prot==PAGE_EXECUTE || prot==PAGE_EXECUTE_READ ||
           prot==PAGE_EXECUTE_READWRITE || prot==PAGE_EXECUTE_WRITECOPY;
}

void* readPointer(const void* address){
    if(!ReadableAddress(address,sizeof(void*))) return nullptr;
    auto value=*reinterpret_cast<void* const*>(address);
    return ReadableAddress(value,sizeof(void*)) ? value : nullptr;
}

template<typename Ret, typename... Args>
bool callVirtualSafe(void* object,size_t index,Ret& result,Args... args){
    if(!ReadableAddress(object,sizeof(void*))) return false;
    auto vtable=*reinterpret_cast<void***>(object);
    if(!ReadableAddress(vtable,(index+1)*sizeof(void*))) return false;
    auto fn=vtable[index];
    if(!executableAddress(fn)) return false;
    using Fn=Ret(__fastcall*)(void*,Args...);
    result=reinterpret_cast<Fn>(fn)(object,args...);
    return true;
}

template<typename... Args>
bool callVirtualVoidSafe(void* object,size_t index,Args... args){
    if(!ReadableAddress(object,sizeof(void*))) return false;
    auto vtable=*reinterpret_cast<void***>(object);
    if(!ReadableAddress(vtable,(index+1)*sizeof(void*))) return false;
    auto fn=vtable[index];
    if(!executableAddress(fn)) return false;
    using Fn=void(__fastcall*)(void*,Args...);
    reinterpret_cast<Fn>(fn)(object,args...);
    return true;
}

std::string readMsvcString(const void* stringObject){
    if(!ReadableAddress(stringObject,32)) return {};
    const auto* raw=reinterpret_cast<const unsigned char*>(stringObject);

    size_t size=0, capacity=0;
    std::memcpy(&size,raw+0x10,sizeof(size));
    std::memcpy(&capacity,raw+0x18,sizeof(capacity));

    if(size>512 || capacity>8192 || size>capacity) return {};

    const char* data=nullptr;
    if(capacity<16){
        data=reinterpret_cast<const char*>(raw);
    }else{
        std::memcpy(&data,raw,sizeof(data));
        if(!data || !ReadableAddress(data,size+1)) return {};
    }

    if(size==0) return {};
    if(!ReadableAddress(data,size)) return {};

    std::string out(data,size);
    for(unsigned char c:out){
        if(c==0 || (c<0x20 && c!='\t')) return {};
    }
    return out;
}

std::string lower(std::string s){
    std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
    return s;
}

std::string titleCaseIdentifier(std::string id){
    if(auto colon=id.find(':');colon!=std::string::npos) id=id.substr(colon+1);
    if(id.rfind("tile.",0)==0) id=id.substr(5);
    if(id.rfind("item.",0)==0) id=id.substr(5);
    if(id.size()>5 && id.ends_with(".name")) id.resize(id.size()-5);

    std::string out;
    bool cap=true;
    for(char c:id){
        if(c=='_'||c=='-'||c=='.'){
            out.push_back(' ');
            cap=true;
        }else{
            out.push_back(cap ? static_cast<char>(std::toupper(static_cast<unsigned char>(c)))
                              : static_cast<char>(std::tolower(static_cast<unsigned char>(c))));
            cap=false;
        }
    }
    return out.empty() ? "Unknown" : out;
}

bool finiteVec(const RawVec3& v){
    return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z) &&
           std::fabs(v.x)<30000000.0f && std::fabs(v.y)<1000000.0f && std::fabs(v.z)<30000000.0f;
}
bool finiteRot(const RawVec2& v){
    return std::isfinite(v.x)&&std::isfinite(v.y) &&
           std::fabs(v.x)<10000.0f && std::fabs(v.y)<10000.0f;
}
float distance(const RawVec3& a,const RawVec3& b){
    const float dx=a.x-b.x,dy=a.y-b.y,dz=a.z-b.z;
    return std::sqrt(dx*dx+dy*dy+dz*dz);
}

void* levelFromClient(void* clientInstance){
    void* minecraft=readPointer(reinterpret_cast<unsigned char*>(clientInstance)+kClientInstanceMinecraftOffset);
    if(!minecraft) return nullptr;

    void* session=readPointer(reinterpret_cast<unsigned char*>(minecraft)+kMinecraftGameSessionOffset);
    if(!session) return nullptr;

    auto* ready=reinterpret_cast<uint8_t*>(reinterpret_cast<unsigned char*>(session)+kGameSessionReadyOffset);
    if(!ReadableAddress(ready,1) || *ready!=1) return nullptr;

    void* control=readPointer(reinterpret_cast<unsigned char*>(session)+kGameSessionControlOffset);
    if(!control || !ReadableAddress(control,1) || *reinterpret_cast<uint8_t*>(control)!=1) return nullptr;

    return readPointer(reinterpret_cast<unsigned char*>(session)+kGameSessionLevelOffset);
}

bool readItemStackSnapshot(void* stack,InventorySlotSnapshot& out,int slot,uintptr_t damageFn){
    if(!stack || !ReadableAddress(stack,0x30)) return false;

    const bool valid=*reinterpret_cast<bool*>(reinterpret_cast<unsigned char*>(stack)+kItemStackValidOffset);
    const int count=static_cast<int>(*reinterpret_cast<uint8_t*>(
        reinterpret_cast<unsigned char*>(stack)+kItemStackCountOffset));
    if(!valid || count<=0 || count>127) return false;

    void* weakItem=readPointer(reinterpret_cast<unsigned char*>(stack)+kItemStackWeakItemOffset);
    if(!weakItem) return false;
    void* item=readPointer(weakItem);
    if(!item) return false;

    out.valid=true;
    out.slot=slot;
    out.count=count;
    out.translateName=readMsvcString(reinterpret_cast<unsigned char*>(item)+kItemTranslateNameOffset);
    out.itemId=readMsvcString(reinterpret_cast<unsigned char*>(item)+kItemIdStringOffset);

    int maxDamage=0;
    callVirtualSafe<int>(item,kItemGetMaxDamageVtableIndex,maxDamage);
    out.maxDamage=std::max(0,maxDamage);

    if(damageFn && executableAddress(reinterpret_cast<void*>(damageFn))){
        using DamageFn=short(__fastcall*)(void*);
        const short damage=reinterpret_cast<DamageFn>(damageFn)(stack);
        if(damage>=0 && damage<32767) out.damage=damage;
    }

    return !out.translateName.empty() || !out.itemId.empty();
}

template<typename T>
T* tryGetEcsComponent(void* actor){
    if(!actor || !ReadableAddress(reinterpret_cast<unsigned char*>(actor)+kActorEntityContextOffset,24))
        return nullptr;

    auto** refs=reinterpret_cast<void**>(reinterpret_cast<unsigned char*>(actor)+kActorEntityContextOffset);
    auto* registry=reinterpret_cast<entt::basic_registry<bedrock::EntityId>*>(refs[1]);
    if(!registry || !ReadableAddress(registry,sizeof(void*))) return nullptr;

    bedrock::EntityId entity{};
    std::memcpy(&entity,reinterpret_cast<unsigned char*>(actor)+kActorEntityContextOffset+16,sizeof(entity));

    try{
        return registry->template try_get<T>(entity);
    }catch(...){
        return nullptr;
    }
}

bool readAttribute(void* actor,uint32_t id,float& value,float& maxValue){
    auto* comp=tryGetEcsComponent<bedrock::AttributesComponent>(actor);
    if(!comp) return false;

    try{
        const auto& ids=comp->baseAttributes.ids;
        const auto& instances=comp->baseAttributes.instances;
        if(ids.size()!=instances.size() || ids.size()>128) return false;
        for(size_t i=0;i<ids.size();++i){
            if(ids[i]!=id) continue;
            value=instances[i].value;
            maxValue=instances[i].maxValue;
            return std::isfinite(value)&&std::isfinite(maxValue);
        }
    }catch(...){}
    return false;
}

std::string readIdentifierComponent(void* actor){
    auto* comp=tryGetEcsComponent<bedrock::ActorDefinitionIdentifierComponent>(actor);
    if(!comp) return {};
    try{
        const std::string& ns=comp->identifier.nameSpace;
        const std::string& id=comp->identifier.identifier;
        if(id.empty() || id.size()>256 || ns.size()>128) return {};
        return ns.empty() ? id : ns+":"+id;
    }catch(...){
        return {};
    }
}

uint32_t readActorEntityRawId(void* actor){
    if(!actor || !ReadableAddress(reinterpret_cast<unsigned char*>(actor)+kActorEntityContextOffset+16,sizeof(bedrock::EntityId)))
        return 0;
    bedrock::EntityId entity{};
    std::memcpy(&entity,reinterpret_cast<unsigned char*>(actor)+kActorEntityContextOffset+16,sizeof(entity));
    return entity.rawId;
}

bool getActorPos(void* actor,RawVec3& pos){
    void* state=readPointer(reinterpret_cast<unsigned char*>(actor)+kActorStateVectorOffset);
    if(!state || !ReadableAddress(state,sizeof(RawVec3))) return false;
    std::memcpy(&pos,state,sizeof(pos));
    return finiteVec(pos);
}

bool getActorAabb(void* actor,RawAabb& aabb){
    void* shape=readPointer(reinterpret_cast<unsigned char*>(actor)+kActorAabbShapeOffset);
    if(!shape || !ReadableAddress(shape,sizeof(RawAabb))) return false;
    std::memcpy(&aabb,shape,sizeof(aabb));
    return finiteVec(aabb.min)&&finiteVec(aabb.max);
}

bool rayAabb(const RawVec3& origin,const RawVec3& dir,const RawAabb& box,float maxDist,float& tOut){
    float tmin=0.0f,tmax=maxDist;
    const float o[3]{origin.x,origin.y,origin.z};
    const float d[3]{dir.x,dir.y,dir.z};
    const float mn[3]{box.min.x,box.min.y,box.min.z};
    const float mx[3]{box.max.x,box.max.y,box.max.z};

    for(int i=0;i<3;++i){
        if(std::fabs(d[i])<1e-6f){
            if(o[i]<mn[i]||o[i]>mx[i]) return false;
        }else{
            const float inv=1.0f/d[i];
            float t1=(mn[i]-o[i])*inv;
            float t2=(mx[i]-o[i])*inv;
            if(t1>t2) std::swap(t1,t2);
            tmin=std::max(tmin,t1);
            tmax=std::min(tmax,t2);
            if(tmin>tmax) return false;
        }
    }
    tOut=tmin;
    return tmin>=0.0f && tmin<=maxDist;
}

RawVec3 normalized(const RawVec3& v){
    const float m=std::sqrt(v.x*v.x+v.y*v.y+v.z*v.z);
    if(m<1e-6f) return {};
    return {v.x/m,v.y/m,v.z/m};
}

}

GameDataBridge& GameDataBridge::Get(){
    static GameDataBridge b;
    return b;
}

void GameDataBridge::clearVolatileSnapshots(){
    player_=PlayerSnapshot{};
    network_=NetworkSnapshot{};
    target_=TargetSnapshot{};
    horse_=HorseSnapshot{};
    effects_.clear();
    armorReady_=false;
    effectsReady_=false;
}

bool GameDataBridge::Install(){
    clearVolatileSnapshots();

    HMODULE mc=GetModuleHandleW(nullptr);
    const uintptr_t sig=FindPattern(mc,kPlatformGameCorePattern);
    if(!sig){
        state_=BridgeState::SignatureMissing;
        return false;
    }

    platformGlobalSlot_=ResolveRel32(sig,3,7);
    if(!ReadableAddress(reinterpret_cast<void*>(platformGlobalSlot_),sizeof(void*))){
        state_=BridgeState::SignatureMissing;
        platformGlobalSlot_=0;
        return false;
    }

    // Passive observability hooks. They never alter attack reach or network packets.
    attackTarget_=FindPattern(mc,kActorAttackPattern);
    if(attackTarget_ && MH_CreateHook(reinterpret_cast<void*>(attackTarget_),
                                     &GameDataBridge::HookActorAttack,
                                     reinterpret_cast<void**>(&g_actorAttackOriginal))==MH_OK){
        MH_EnableHook(reinterpret_cast<void*>(attackTarget_));
    }else{
        attackTarget_=0;
    }

    pingTarget_=FindPattern(mc,kAveragePingPattern);
    if(pingTarget_ && MH_CreateHook(reinterpret_cast<void*>(pingTarget_),
                                   &GameDataBridge::HookAveragePing,
                                   reinterpret_cast<void**>(&g_averagePingOriginal))==MH_OK){
        MH_EnableHook(reinterpret_cast<void*>(pingTarget_));
    }else{
        pingTarget_=0;
    }

    state_=BridgeState::PlatformUnavailable;
    Refresh();
    return PlayerReady();
}

void GameDataBridge::Uninstall(){
    if(attackTarget_) MH_DisableHook(reinterpret_cast<void*>(attackTarget_));
    if(pingTarget_) MH_DisableHook(reinterpret_cast<void*>(pingTarget_));
    attackTarget_=pingTarget_=0;
}

void GameDataBridge::Refresh(){
    clearVolatileSnapshots();

    if(!platformGlobalSlot_){
        state_=BridgeState::SignatureMissing;
        return;
    }

    void* winMain=readPointer(reinterpret_cast<void*>(platformGlobalSlot_));
    if(!winMain){
        state_=BridgeState::PlatformUnavailable;
        return;
    }

    void* platform=readPointer(reinterpret_cast<unsigned char*>(winMain)+kWinMainPlatformOffset);
    if(!platform){
        state_=BridgeState::PlatformUnavailable;
        return;
    }

    void* minecraftGame=readPointer(reinterpret_cast<unsigned char*>(platform)+kPlatformMinecraftGameOffset);
    if(!minecraftGame){
        state_=BridgeState::ClientInstanceUnavailable;
        return;
    }

    using ClientMap=std::map<uint8_t,std::shared_ptr<void>>;
    auto* mapPtr=reinterpret_cast<ClientMap*>(reinterpret_cast<unsigned char*>(minecraftGame)+kMinecraftGamePrimaryClientsOffset);
    if(!ReadableAddress(mapPtr,sizeof(ClientMap))){
        state_=BridgeState::ClientInstanceUnavailable;
        return;
    }

    void* clientInstance=nullptr;
    try{
        auto it=mapPtr->find(0);
        if(it!=mapPtr->end()) clientInstance=it->second.get();
    }catch(...){}

    if(!clientInstance || !ReadableAddress(clientInstance,sizeof(void*))){
        state_=BridgeState::ClientInstanceUnavailable;
        return;
    }

    void* localPlayer=nullptr;
    if(!callVirtualSafe<void*>(clientInstance,kClientInstanceGetLocalPlayerVtableIndex,localPlayer) ||
       !localPlayer || !ReadableAddress(localPlayer,0x230)){
        state_=BridgeState::LocalPlayerUnavailable;
        return;
    }
    lastLocalPlayer_=localPlayer;

    void* stateVector=readPointer(reinterpret_cast<unsigned char*>(localPlayer)+kActorStateVectorOffset);
    void* actorRotation=readPointer(reinterpret_cast<unsigned char*>(localPlayer)+kActorRotationOffset);

    if(!stateVector || !actorRotation ||
       !ReadableAddress(stateVector,sizeof(RawVec3)*3) ||
       !ReadableAddress(actorRotation,sizeof(RawVec2))){
        state_=BridgeState::LocalPlayerUnavailable;
        return;
    }

    RawVec3 pos{},old{},vel{};
    RawVec2 rot{};
    std::memcpy(&pos,stateVector,sizeof(pos));
    std::memcpy(&old,reinterpret_cast<unsigned char*>(stateVector)+sizeof(RawVec3),sizeof(old));
    std::memcpy(&vel,reinterpret_cast<unsigned char*>(stateVector)+sizeof(RawVec3)*2,sizeof(vel));
    std::memcpy(&rot,actorRotation,sizeof(rot));

    if(!finiteVec(pos)||!finiteVec(vel)||!finiteRot(rot)){
        state_=BridgeState::LocalPlayerUnavailable;
        return;
    }

    player_.valid=true;
    player_.position={pos.x,pos.y,pos.z};
    player_.velocity={vel.x,vel.y,vel.z};
    player_.rotation={rot.x,rot.y};
    state_=BridgeState::BasicPlayerReady;

    float health=0.0f,maxHealth=0.0f;
    if(readAttribute(localPlayer,kHealthAttributeId,health,maxHealth) &&
       health>=0.0f && maxHealth>0.0f && health<=maxHealth+64.0f && maxHealth<4096.0f){
        player_.healthValid=true;
        player_.health=health;
        player_.maxHealth=maxHealth;
        observeLocalHealth(localPlayer,health,maxHealth);
    }

    const uintptr_t damageFn=FindPattern(GetModuleHandleW(nullptr),kItemDamagePattern);

    void* supplies=readPointer(reinterpret_cast<unsigned char*>(localPlayer)+kPlayerSuppliesOffset);
    if(supplies){
        if(ReadableAddress(reinterpret_cast<unsigned char*>(supplies)+kPlayerInventorySelectedSlotOffset,sizeof(int))){
            player_.selectedSlot=*reinterpret_cast<int*>(
                reinterpret_cast<unsigned char*>(supplies)+kPlayerInventorySelectedSlotOffset);
            if(player_.selectedSlot<0 || player_.selectedSlot>8) player_.selectedSlot=0;
        }

        void* inventory=readPointer(reinterpret_cast<unsigned char*>(supplies)+kPlayerInventoryInventoryOffset);
        if(inventory){
            int validSlots=0;
            for(int slot=0;slot<36;++slot){
                void* stack=nullptr;
                if(!callVirtualSafe<void*>(inventory,kInventoryGetItemVtableIndex,stack,slot)) continue;
                InventorySlotSnapshot snap{};
                if(readItemStackSnapshot(stack,snap,slot,damageFn)){
                    player_.inventory[slot]=snap;
                    ++validSlots;
                }
            }
            if(player_.selectedSlot>=0 && player_.selectedSlot<36)
                player_.heldItem=player_.inventory[player_.selectedSlot];
            {
                std::scoped_lock lock(heldItemMutex_);
                heldItemIdCache_=player_.heldItem.itemId;
            }

            if(validSlots>0 || inventory) state_=BridgeState::InventoryReady;
        }
    }

    refreshArmor(localPlayer);
    refreshNetwork(clientInstance);
    refreshTarget(clientInstance,localPlayer);
    refreshHorse(localPlayer);

    // Potion Effects remains capability-gated. We intentionally do not guess a
    // MobEffectInstance layout for this Minecraft build.
    effectsReady_=false;

    if(armorReady_ || network_.valid || target_.valid)
        state_=BridgeState::ExtendedReady;
}

void GameDataBridge::refreshArmor(void* localPlayer){
    const uintptr_t damageFn=FindPattern(GetModuleHandleW(nullptr),kItemDamagePattern);
    auto* equipment=tryGetEcsComponent<bedrock::ActorEquipmentComponent>(localPlayer);
    if(!equipment || !equipment->armorContainer) return;

    armorReady_=true;
    for(int slot=0;slot<4;++slot){
        void* stack=nullptr;
        if(!callVirtualSafe<void*>(equipment->armorContainer,kInventoryGetItemVtableIndex,stack,slot))
            continue;

        InventorySlotSnapshot temp{};
        if(!readItemStackSnapshot(stack,temp,slot,damageFn)) continue;

        auto& out=player_.armor[slot];
        out.valid=true;
        out.slot=slot;
        out.count=temp.count;
        out.damage=temp.damage;
        out.maxDamage=temp.maxDamage;
        out.itemId=temp.itemId;
        out.translateName=temp.translateName;
        if(out.maxDamage>0){
            const float remain=static_cast<float>(std::max(0,out.maxDamage-out.damage));
            out.durabilityPercent=std::clamp(remain/static_cast<float>(out.maxDamage)*100.0f,0.0f,100.0f);
        }
    }
}

void GameDataBridge::refreshNetwork(void* clientInstance){
    void* packetSender=readPointer(reinterpret_cast<unsigned char*>(clientInstance)+kClientInstancePacketSenderOffset);
    if(!packetSender) return;
    void* networkSystem=readPointer(reinterpret_cast<unsigned char*>(packetSender)+kPacketSenderNetworkSystemOffset);
    if(!networkSystem) return;
    void* composite=readPointer(reinterpret_cast<unsigned char*>(networkSystem)+kNetworkSystemRemoteConnectorOffset);
    if(!composite) return;

    void* connectors[2]{
        readPointer(reinterpret_cast<unsigned char*>(composite)+kRemoteConnectorRakNetOffset),
        readPointer(reinterpret_cast<unsigned char*>(composite)+kRemoteConnectorNetherNetOffset)
    };

    for(void* connector:connectors){
        if(!connector) continue;
        void* info=nullptr;
        if(!callVirtualSafe<void*>(connector,kRemoteGetConnectedGameInfoVtableIndex,info) || !info)
            continue;
        if(!ReadableAddress(info,0x90)) continue;

        const std::string host=readMsvcString(reinterpret_cast<unsigned char*>(info)+kConnectionHostIpOffset);
        const std::string url=readMsvcString(reinterpret_cast<unsigned char*>(info)+kConnectionUnresolvedUrlOffset);
        const std::string region=readMsvcString(reinterpret_cast<unsigned char*>(info)+kConnectionRegionOffset);
        const int port=*reinterpret_cast<int*>(reinterpret_cast<unsigned char*>(info)+kConnectionPortOffset);

        if(host.empty() && url.empty()) continue;
        network_.valid=true;
        network_.connected=true;
        network_.hostIp=host;
        network_.unresolvedUrl=url;
        network_.region=region;
        network_.port=(port>=0 && port<=65535)?port:0;
        network_.pingMs=lastPingMs_;
        return;
    }
}

void GameDataBridge::refreshTarget(void* clientInstance,void* localPlayer){
    void* level=levelFromClient(clientInstance);
    if(!level) return;

    void* hitPtr=nullptr;
    if(!callVirtualSafe<void*>(level,kLevelGetHitResultVtableIndex,hitPtr) ||
       !hitPtr || !ReadableAddress(hitPtr,sizeof(RawHitResult))) return;

    RawHitResult hit{};
    std::memcpy(&hit,hitPtr,sizeof(hit));
    if(!finiteVec(hit.start)||!finiteVec(hit.hitPos)) return;

    target_.distance=distance(hit.start,hit.hitPos);
    target_.position={hit.hitPos.x,hit.hitPos.y,hit.hitPos.z};
    target_.rayStart={hit.start.x,hit.start.y,hit.start.z};

    if(hit.hitType==0){
        void* region=nullptr;
        if(!callVirtualSafe<void*>(clientInstance,kClientInstanceGetRegionVtableIndex,region) || !region) return;

        RawBlockPos bp=hit.hitBlock;
        void* block=nullptr;
        if(!callVirtualSafe<void*,const RawBlockPos&>(region,kBlockSourceGetBlockByPosVtableIndex,block,bp) || !block)
            return;

        void* legacy=readPointer(reinterpret_cast<unsigned char*>(block)+kBlockLegacyOffset);
        if(!legacy) return;

        const std::string translated=readMsvcString(reinterpret_cast<unsigned char*>(legacy)+kBlockLegacyTranslateNameOffset);
        std::string name=readMsvcString(reinterpret_cast<unsigned char*>(legacy)+kBlockLegacyNamespacedIdStringOffset);
        if(name.empty()) name=readMsvcString(reinterpret_cast<unsigned char*>(legacy)+kBlockLegacyNameStringOffset);
        const std::string ns=readMsvcString(reinterpret_cast<unsigned char*>(legacy)+kBlockLegacyNamespaceOffset);
        if(!ns.empty() && name.find(':')==std::string::npos && !name.empty()) name=ns+":"+name;

        target_.valid=true;
        target_.type=TargetType::Block;
        target_.blockOriginValid=true;
        target_.blockOrigin={static_cast<float>(bp.x),static_cast<float>(bp.y),static_cast<float>(bp.z)};
        target_.identifier=name;
        target_.name=titleCaseIdentifier(!name.empty()?name:translated);
        return;
    }

    if(hit.hitType==1){
        // Find the nearest actor whose AABB intersects the current hit ray.
        // This does not reveal actors through walls; it uses the game's current hit ray.
        std::vector<void*> actors;
        if(!callVirtualVoidSafe<std::vector<void*>&>(level,0x145,actors) || actors.size()>4096) return;

        RawVec3 rayDir=normalized({hit.hitPos.x-hit.start.x,hit.hitPos.y-hit.start.y,hit.hitPos.z-hit.start.z});
        float best=std::max(0.1f,target_.distance+0.75f);
        void* bestActor=nullptr;

        for(void* actor:actors){
            if(!actor || actor==localPlayer) continue;
            RawAabb box{};
            if(!getActorAabb(actor,box)) continue;
            float t=0.0f;
            if(rayAabb(hit.start,rayDir,box,best,t) && t<best){
                best=t;
                bestActor=actor;
            }
        }

        if(bestActor){
            RawVec3 p{};
            getActorPos(bestActor,p);
            const std::string id=readIdentifierComponent(bestActor);
            target_.valid=true;
            target_.type=TargetType::Entity;
            target_.identifier=id;
            target_.name=titleCaseIdentifier(id);
            target_.distance=best;
            target_.position={p.x,p.y,p.z};
        }
    }
}

void GameDataBridge::refreshHorse(void*){
    if(!target_.valid || target_.type!=TargetType::Entity) return;
    std::string id=lower(target_.identifier);
    if(id.find("horse")==std::string::npos) return;

    // The target actor itself isn't retained in TargetSnapshot; re-acquiring the
    // same target for attributes would need a stable runtime-id field. Until that
    // is profiled for this build, Horse Stats exposes what is genuinely known:
    // target identity and client-side approach speed remain available, while
    // hidden jump-strength is explicitly unsupported.
    horse_.valid=true;
    horse_.identifier=target_.identifier;
    horse_.health=-1.0f;
    horse_.maxHealth=-1.0f;
    horse_.currentSpeed=0.0f;
    horse_.jumpStrengthAvailable=false;
}


void GameDataBridge::observeLocalHealth(void* localPlayer,float health,float maxHealth){
    std::scoped_lock lock(combatVisualMutex_);
    const auto now=std::chrono::steady_clock::now();

    const bool observationGap=lastHealthObservationTime_.time_since_epoch().count()!=0 &&
        std::chrono::duration_cast<std::chrono::milliseconds>(now-lastHealthObservationTime_).count()>500;
    lastHealthObservationTime_=now;

    if(!healthBaselineValid_ || healthOwner_!=localPlayer || observationGap ||
       std::fabs(lastObservedMaxHealth_-maxHealth)>0.01f){
        healthBaselineValid_=true;
        healthOwner_=localPlayer;
        lastObservedHealth_=health;
        lastObservedMaxHealth_=maxHealth;
        return;
    }

    // Read-only damage observation. Healing, absorption/max-health changes and
    // respawns do not generate a false damage event.
    if(health+0.01f<lastObservedHealth_){
        lastDamageTime_=now;
    }
    lastObservedHealth_=health;
    lastObservedMaxHealth_=maxHealth;
}

void GameDataBridge::recordHitTarget(void* actor){
    if(!actor) return;
    std::scoped_lock lock(combatVisualMutex_);
    lastHitActor_=actor;
    lastHitEntityRawId_=readActorEntityRawId(actor);
    lastHitTime_=std::chrono::steady_clock::now();
}

bool GameDataBridge::HasRecentDamage(int timeoutMs) const{
    const long long age=LastDamageAgeMs();
    return age>=0 && age<=timeoutMs;
}

long long GameDataBridge::LastDamageAgeMs() const{
    std::scoped_lock lock(combatVisualMutex_);
    if(lastDamageTime_.time_since_epoch().count()==0) return -1;
    const auto elapsed=std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now()-lastDamageTime_).count();
    return elapsed>=0 ? elapsed : -1;
}

bool GameDataBridge::IsRecentHitActor(void* actor,int timeoutMs) const{
    if(!actor) return false;
    std::scoped_lock lock(combatVisualMutex_);
    if(lastHitTime_.time_since_epoch().count()==0) return false;
    const auto elapsed=std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now()-lastHitTime_).count();
    if(elapsed<0 || elapsed>timeoutMs) return false;

    const uint32_t entityId=readActorEntityRawId(actor);
    if(lastHitEntityRawId_!=0 && entityId!=0) return entityId==lastHitEntityRawId_;
    return actor==lastHitActor_;
}

int GameDataBridge::CountItemContains(const std::string& token) const{
    if(!InventoryReady() || token.empty()) return 0;
    const std::string wanted=lower(token);
    int total=0;
    for(const auto& s:player_.inventory){
        if(!s.valid) continue;
        const std::string id=lower(s.itemId);
        const std::string tr=lower(s.translateName);
        if(id.find(wanted)!=std::string::npos || tr.find(wanted)!=std::string::npos)
            total+=s.count;
    }
    return total;
}


std::string GameDataBridge::HeldItemIdCopy() const{
    std::scoped_lock lock(heldItemMutex_);
    return heldItemIdCache_;
}

int GameDataBridge::CountExactItem(const std::string& itemId) const{
    if(!InventoryReady() || itemId.empty()) return 0;
    const std::string wanted=lower(itemId);
    int total=0;
    for(const auto& s:player_.inventory){
        if(!s.valid) continue;
        const std::string id=lower(s.itemId);
        if(id==wanted || ("minecraft:"+id)==wanted || id==("minecraft:"+wanted))
            total+=s.count;
    }
    return total;
}

bool GameDataBridge::PlayerReady() const{
    return state_==BridgeState::BasicPlayerReady || state_==BridgeState::InventoryReady || state_==BridgeState::ExtendedReady;
}
bool GameDataBridge::InventoryReady() const{
    return state_==BridgeState::InventoryReady || state_==BridgeState::ExtendedReady;
}

const char* GameDataBridge::StateText() const{
    switch(state_){
        case BridgeState::NotInitialized: return "Not initialized";
        case BridgeState::SignatureMissing: return "Unsupported build: platform signature not found";
        case BridgeState::PlatformUnavailable: return "Waiting for Minecraft platform";
        case BridgeState::ClientInstanceUnavailable: return "Waiting for primary client";
        case BridgeState::LocalPlayerUnavailable: return "Waiting for local player / world";
        case BridgeState::BasicPlayerReady: return "Player data ready";
        case BridgeState::InventoryReady: return "Player + inventory data ready";
        case BridgeState::ExtendedReady: return "Extended game data ready";
        default: return "Unknown";
    }
}

const char* GameDataBridge::CardinalDirection() const{
    if(!PlayerReady()) return "--";
    float yaw=std::fmod(player_.rotation.y,360.0f);
    if(yaw<0) yaw+=360.0f;
    if(yaw>=315.0f || yaw<45.0f) return "S";
    if(yaw<135.0f) return "W";
    if(yaw<225.0f) return "N";
    return "E";
}

bool GameDataBridge::HasRecentReach(int timeoutMs) const{
    if(lastReachTime_.time_since_epoch().count()==0) return false;
    const auto elapsed=std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now()-lastReachTime_).count();
    return elapsed>=0 && elapsed<=timeoutMs;
}

void* __fastcall GameDataBridge::HookActorAttack(void* obj,void* ret,void* target,void* cause,void* a4){
    auto& b=GameDataBridge::Get();

    if(obj && obj==b.lastLocalPlayer_){
        b.recordHitTarget(target);
        // Measure only from Minecraft's current successful attack callback.
        // Nothing here changes attack range or hit validity.
        // Re-use the currently resolved HitResult from Refresh().
        // target pointer itself is intentionally not modified.
        HMODULE mc=GetModuleHandleW(nullptr);
        (void)mc;

        // The periodic target snapshot is close enough to the attack time and
        // comes from Level::getHitResult() -> start/hitPos.
        if(b.target_.valid && b.target_.distance>=0.0f && b.target_.distance<20.0f){
            b.lastReach_=b.target_.distance;
            b.lastReachTime_=std::chrono::steady_clock::now();
        }
    }

    return g_actorAttackOriginal
        ? g_actorAttackOriginal(obj,ret,target,cause,a4)
        : nullptr;
}

int __fastcall GameDataBridge::HookAveragePing(void* obj,char* guidOrAddress){
    const int ping=g_averagePingOriginal ? g_averagePingOriginal(obj,guidOrAddress) : 0;
    if(ping>=0 && ping<60000){
        auto& b=GameDataBridge::Get();
        b.lastPingMs_=ping;
        b.network_.pingMs=ping;
    }
    return ping;
}

}
