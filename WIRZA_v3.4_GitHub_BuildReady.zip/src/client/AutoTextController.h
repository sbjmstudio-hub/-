#pragma once
#include <chrono>
#include <string>
#include <windows.h>

namespace wirza {

class AutoTextController {
public:
    static AutoTextController& Get();
    void Update(HWND hwnd,bool gameplayActive);
    // Future verified game-event adapters may call this for Auto Text Actions.
    void TriggerAction(const std::string& text,int delayMs);
    const char* StatusText() const { return status_.c_str(); }

private:
    void queue(const std::string& text,int delayMs);
    void typeUnicode(const std::string& text);
    void tapKey(WORD vk);

    bool prevHotkeyDown_=false;
    int phase_=0;
    std::string pending_;
    std::chrono::steady_clock::time_point due_{};
    std::string status_="Idle";
};

}
