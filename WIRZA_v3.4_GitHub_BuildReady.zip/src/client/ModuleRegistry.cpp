#include "ModuleRegistry.h"
#include <windows.h>
#include <filesystem>
#include <cstdlib>
#include <cwchar>
#include <algorithm>

namespace wirza {
namespace {

std::wstring appDataDir() {
    wchar_t* env = nullptr;
    size_t len = 0;
    if (_wdupenv_s(&env, &len, L"APPDATA") != 0 || !env) return L".";
    std::wstring path(env);
    free(env);
    path += L"\\WIRZA Client";
    std::error_code ec;
    std::filesystem::create_directories(path, ec);
    return path;
}

std::wstring widen(const std::string& s) {
    if (s.empty()) return {};
    const int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, nullptr, 0);
    if(n<=0) return {};
    std::wstring out(static_cast<size_t>(n), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, out.data(), n);
    if (!out.empty() && out.back() == L'\0') out.pop_back();
    return out;
}

std::string narrow(const std::wstring& s) {
    if(s.empty()) return {};
    int n=WideCharToMultiByte(CP_UTF8,0,s.c_str(),-1,nullptr,0,nullptr,nullptr);
    if(n<=0) return {};
    std::string out(static_cast<size_t>(n),'\0');
    WideCharToMultiByte(CP_UTF8,0,s.c_str(),-1,out.data(),n,nullptr,nullptr);
    if(!out.empty() && out.back()=='\0') out.pop_back();
    return out;
}

int readInt(const std::wstring& f, const std::wstring& section, const std::wstring& key, int def) {
    return static_cast<int>(GetPrivateProfileIntW(section.c_str(), key.c_str(), def, f.c_str()));
}
float readFloat(const std::wstring& f, const std::wstring& section, const std::wstring& key, float def) {
    wchar_t buf[64]{}, d[64]{};
    swprintf_s(d, L"%.6f", def);
    GetPrivateProfileStringW(section.c_str(), key.c_str(), d, buf, 64, f.c_str());
    return static_cast<float>(_wtof(buf));
}
std::string readText(const std::wstring& f,const std::wstring& section,const std::wstring& key,const std::string& def){
    wchar_t buf[1024]{};
    const auto wd=widen(def);
    GetPrivateProfileStringW(section.c_str(),key.c_str(),wd.c_str(),buf,1024,f.c_str());
    return narrow(buf);
}
void writeInt(const std::wstring& f, const std::wstring& section, const std::wstring& key, int v) {
    wchar_t b[32]{}; swprintf_s(b, L"%d", v);
    WritePrivateProfileStringW(section.c_str(), key.c_str(), b, f.c_str());
}
void writeFloat(const std::wstring& f, const std::wstring& section, const std::wstring& key, float v) {
    wchar_t b[64]{}; swprintf_s(b, L"%.6f", v);
    WritePrivateProfileStringW(section.c_str(), key.c_str(), b, f.c_str());
}
void writeText(const std::wstring& f,const std::wstring& section,const std::wstring& key,const std::string& v){
    const auto w=widen(v);
    WritePrivateProfileStringW(section.c_str(),key.c_str(),w.c_str(),f.c_str());
}

ModuleOption optBool(const char* key,const char* label,bool v){
    ModuleOption o; o.key=key;o.label=label;o.type=OptionType::Bool;o.boolValue=v;return o;
}
ModuleOption optFloat(const char* key,const char* label,float v,float mn,float mx){
    ModuleOption o; o.key=key;o.label=label;o.type=OptionType::Float;o.floatValue=v;o.floatMin=mn;o.floatMax=mx;return o;
}
ModuleOption optInt(const char* key,const char* label,int v,int mn,int mx){
    ModuleOption o; o.key=key;o.label=label;o.type=OptionType::Int;o.intValue=v;o.intMin=mn;o.intMax=mx;return o;
}
ModuleOption optColor(const char* key,const char* label,float r,float g,float b,float a){
    ModuleOption o; o.key=key;o.label=label;o.type=OptionType::Color;o.colorValue={r,g,b,a};return o;
}
ModuleOption optChoice(const char* key,const char* label,int index,std::vector<std::string> values){
    ModuleOption o; o.key=key;o.label=label;o.type=OptionType::Choice;o.choiceIndex=index;o.choices=std::move(values);return o;
}
ModuleOption optText(const char* key,const char* label,const char* value){
    ModuleOption o; o.key=key;o.label=label;o.type=OptionType::Text;o.textValue=value;return o;
}

}

ModuleRegistry& ModuleRegistry::Get() { static ModuleRegistry r; return r; }

void ModuleRegistry::Initialize() {
    if (!modules_.empty()) return;
    modules_ = {
        {"2d_items", "2D Items", "Visual", false, ModuleState::Partial, false, {}, {optFloat("scale","Item scale",1.0f,0.4f,2.0f),optFloat("offset_x","Horizontal offset",0.0f,-100.0f,100.0f),optFloat("offset_y","Vertical offset",0.0f,-100.0f,100.0f),optFloat("rotation","Rotation",0.0f,-180.0f,180.0f)}},
        {"armor_status", "Armor Status", "HUD", false, ModuleState::Implemented, true, {}, {optBool("show_durability","Show durability",true),optBool("show_held_item","Show held item",true),optChoice("layout","Layout",0,{"Horizontal","Vertical"}),optInt("low_durability","Low durability %",20,1,100),optColor("warning_color","Low durability color",1.0f,0.25f,0.2f,1.0f)}},
        {"auto_text_actions", "Auto Text Actions", "Utility", false, ModuleState::Partial, false, {}, {optText("text","Text / command","gg"),optInt("delay_ms","Delay (ms)",150,0,5000),optBool("chat_only","Chat only",true)}},
        {"auto_text_hotkey", "Auto Text Hotkey", "Utility", false, ModuleState::Partial, false, {}, {optText("text","Text / command","gg"),optInt("hotkey","Virtual key",117,1,255),optBool("require_chat_safe","Require chat-safe mode",true)}},
        {"block_outline", "Block Outline", "Visual", false, ModuleState::Partial, false, {}, {optFloat("line_width","Line width",2.0f,1.0f,8.0f),optColor("outline_color","Outline color",0.65f,0.35f,1.0f,1.0f),optFloat("fill_alpha","Fill opacity",0.0f,0.0f,0.6f)}},
        {"boss_bar", "Boss Bar", "HUD", false, ModuleState::Partial, true, {}, {optFloat("scale","Bar scale",1.0f,0.5f,2.0f),optBool("hide_background","Hide background",false),optColor("bar_color","Bar color",0.65f,0.35f,1.0f,1.0f)}},
        {"chat_mod", "Chat Mod", "HUD", false, ModuleState::Partial, true, {}, {optFloat("opacity","Chat opacity",0.85f,0.0f,1.0f),optFloat("font_scale","Font scale",1.0f,0.6f,1.8f),optBool("timestamps","Show timestamps",false),optBool("compact","Compact spacing",false)}},
        {"clock", "Clock", "HUD", false, ModuleState::Implemented, true, {}, {optBool("format_24h","24-hour format",true),optBool("show_seconds","Show seconds",true)}},
        {"color_saturation", "Color Saturation", "Visual", false, ModuleState::Partial, false, {}, {optFloat("saturation","Saturation",1.0f,0.0f,2.0f),optFloat("contrast","Contrast",1.0f,0.5f,1.8f),optFloat("brightness","Brightness",1.0f,0.5f,1.8f)}},
        {"cps", "CPS", "HUD", true, ModuleState::Implemented, true, {}, {optBool("show_left","Show LMB",true),optBool("show_right","Show RMB",true),optInt("window_ms","CPS window (ms)",1000,250,3000)}},
        {"crosshair", "Crosshair", "Visual", false, ModuleState::Implemented, false, {}, {optFloat("length","Length",8.0f,2.0f,30.0f),optFloat("gap","Gap",3.0f,0.0f,15.0f),optFloat("thickness","Thickness",2.0f,1.0f,6.0f),optColor("color","Color",1.0f,1.0f,1.0f,1.0f)}},
        {"damage_tint", "Damage Tint", "Visual", false, ModuleState::Partial, false, {}, {optFloat("strength","Tint strength",0.6f,0.0f,1.0f),optColor("tint_color","Tint color",1.0f,0.0f,0.0f,0.6f),optInt("duration_ms","Duration (ms)",250,50,1500)}},
        {"direction_hud", "Direction HUD", "HUD", false, ModuleState::Implemented, true, {}, {optChoice("mode","Display mode",0,{"N/E/S/W","Degrees","Both"}),optInt("precision","Degree precision",0,0,2)}},
        {"fog", "Fog / Fog Customizer", "Visual", false, ModuleState::Partial, false, {}, {optFloat("density","Fog density",1.0f,0.0f,2.0f),optFloat("start_scale","Fog start",1.0f,0.1f,2.0f),optColor("fog_color","Fog color",0.75f,0.82f,0.9f,1.0f)}},
        {"fov", "FOV", "Camera", false, ModuleState::Partial, false, {}, {optFloat("normal_fov","Normal FOV (degrees)",90.0f,30.0f,120.0f),optBool("dynamic_fov","Dynamic FOV",true)}},
        {"fps", "FPS", "HUD", true, ModuleState::Implemented, true, {}, {optBool("show_label","Show FPS label",true),optInt("update_ms","Update interval (ms)",500,100,2000)}},
        {"glint_colorizer", "Glint Colorizer", "Visual", false, ModuleState::Partial, false, {}, {optColor("glint_color","Glint color",0.65f,0.35f,1.0f,1.0f),optFloat("strength","Glint strength",1.0f,0.0f,2.0f),optFloat("speed","Animation speed",1.0f,0.1f,3.0f)}},
        {"gui_scale", "GUI Scale", "Visual", false, ModuleState::Partial, false, {}, {optFloat("scale","GUI scale",1.0f,0.5f,2.0f),optBool("hud_only","HUD only",false)}},
        {"hit_color", "Hit Color", "Visual", false, ModuleState::Partial, false, {}, {optColor("hit_color","Hit color",1.0f,0.0f,0.0f,1.0f),optFloat("strength","Strength",1.0f,0.0f,1.0f),optInt("duration_ms","Duration (ms)",350,50,1500)}},
        {"horse_stats", "Horse Stats", "HUD", false, ModuleState::Partial, true, {}, {optBool("show_speed","Show speed",true),optBool("show_jump","Show jump",true),optBool("show_health","Show health",true)}},
        {"item_counter", "Item Counter", "HUD", false, ModuleState::Implemented, true, {}, {optText("item_name","Tracked item","totem_of_undying"),optBool("show_icon","Show icon",true),optInt("warn_below","Warn below count",1,0,64)}},
        {"item_customizer", "Item Customizer", "Visual", false, ModuleState::Partial, false, {}, {optFloat("scale","Scale",1.0f,0.3f,2.0f),optFloat("x","X offset",0.0f,-2.0f,2.0f),optFloat("y","Y offset",0.0f,-2.0f,2.0f),optFloat("rotation","Rotation",0.0f,-180.0f,180.0f)}},
        {"item_physics", "Item Physics", "Visual", false, ModuleState::Partial, false, {}, {optFloat("rotation_speed","Rotation speed",1.0f,0.0f,3.0f),optFloat("ground_tilt","Ground tilt",90.0f,0.0f,90.0f),optFloat("bob_strength","Bob strength",0.2f,0.0f,1.0f)}},
        {"keystrokes", "Keystrokes", "HUD", true, ModuleState::Implemented, true, {}, {optBool("show_space","Show Space",true),optBool("show_shift","Show Shift",true),optBool("show_ctrl","Show Ctrl",true),optBool("show_mouse","Show LMB/RMB",true),optColor("pressed_color","Pressed color",0.65f,0.35f,1.0f,1.0f)}},
        {"kill_sounds", "Kill Sounds", "Audio", false, ModuleState::Partial, false, {}, {optFloat("volume","Volume",0.8f,0.0f,1.0f),optChoice("sound","Sound preset",0,{"Default","Bell","Pop","Chime"})}},
        {"lighting", "Lighting", "Visual", false, ModuleState::Partial, false, {}, {optFloat("brightness","Brightness",1.0f,0.5f,2.0f),optFloat("gamma","Gamma",1.0f,0.5f,3.0f),optBool("full_bright","Full Bright",false)}},
        {"memory_usage", "Memory Usage", "HUD", false, ModuleState::Implemented, true, {}, {optChoice("unit","Unit",0,{"MiB","GiB"}),optBool("show_process","Show process label",false)}},
        {"menu_blur", "Menu Blur", "Visual", false, ModuleState::Partial, false, {}, {optFloat("strength","Blur strength",0.6f,0.0f,1.0f),optFloat("dim","Background dim",0.35f,0.0f,0.8f)}},
        {"momentum", "Momentum", "Visual", false, ModuleState::Partial, false, {}, {optBool("show_speed","Show movement speed",true),optBool("show_graph","Show speed graph",false),optFloat("history_seconds","Graph history",3.0f,1.0f,10.0f)}},
        {"motion_blur", "Motion Blur", "Visual", false, ModuleState::Partial, false, {}, {optFloat("strength","Blur strength",0.25f,0.0f,0.9f),optInt("samples","Samples",4,1,16)}},
        {"nick_hider", "Nick Hider", "Privacy", false, ModuleState::Partial, false, {}, {optBool("hide_self","Hide own name",true),optBool("hide_others","Hide other names",false),optText("replacement","Replacement text","Player")}},
        {"one_seven_visuals", "1.7 Visuals", "Visual", false, ModuleState::Partial, false, {}, {optBool("old_swing","1.7 swing",true),optBool("old_block","1.7 block look",true),optFloat("scale","Visual scale",1.0f,0.5f,1.5f)}},
        {"overlay_mod", "Overlay Mod", "Visual", false, ModuleState::Partial, false, {}, {optFloat("fire_opacity","Fire opacity",0.5f,0.0f,1.0f),optFloat("water_opacity","Water opacity",0.7f,0.0f,1.0f),optFloat("block_opacity","In-block opacity",0.7f,0.0f,1.0f)}},
        {"pack_display", "Pack Display", "HUD", false, ModuleState::Partial, true, {}, {optBool("show_icon","Show icon",true),optBool("show_name","Show pack name",true),optInt("max_name","Max name length",32,8,80)}},
        {"pack_organizer", "Pack Organizer", "Utility", false, ModuleState::Partial, false, {}, {optBool("favorites_first","Favorites first",true),optBool("compact","Compact list",false),optText("search","Search packs","")}},
        {"particle_changer", "Particle Changer", "Visual", false, ModuleState::Partial, false, {}, {optFloat("amount","Particle amount",1.0f,0.0f,3.0f),optFloat("size","Particle size",1.0f,0.25f,3.0f),optColor("particle_color","Particle color",1.0f,1.0f,1.0f,1.0f),optBool("override_color","Override color",false)}},
        {"ping", "Ping", "HUD", false, ModuleState::Implemented, true, {}, {optBool("show_ms","Show ms suffix",true),optInt("update_ms","Update interval",1000,250,5000),optInt("good_threshold","Good ping threshold",80,10,300),optInt("bad_threshold","Bad ping threshold",160,20,1000),optColor("good_color","Good ping color",0.3f,1.0f,0.5f,1.0f),optColor("bad_color","Bad ping color",1.0f,0.25f,0.2f,1.0f)}},
        {"playtime", "Playtime", "HUD", false, ModuleState::Implemented, true, {}, {optBool("session_only","Session only",true),optBool("show_seconds","Show seconds",false)}},
        {"potion_effects", "Potion Effects", "HUD", false, ModuleState::Partial, true, {}, {optBool("show_duration","Show duration",true),optBool("show_amplifier","Show level",true),optBool("compact","Compact layout",false)}},
        {"radio", "Radio / Lunar FM", "Audio", false, ModuleState::Partial, false, {}, {optFloat("volume","Volume",0.5f,0.0f,1.0f),optText("station","Station / URL",""),optBool("autoplay","Autoplay",false)}},
        {"reach_display", "Reach Display", "HUD", false, ModuleState::Implemented, true, {}, {optInt("decimals","Decimals",2,0,3),optInt("timeout_ms","Display timeout",2500,250,10000),optColor("accent","Accent color",0.65f,0.35f,1.0f,1.0f),optBool("show_blocks_suffix","Show blocks suffix",true)}},
        {"scoreboard", "Scoreboard", "HUD", false, ModuleState::Partial, true, {}, {optFloat("scale","Scale",1.0f,0.5f,2.0f),optFloat("opacity","Background opacity",0.6f,0.0f,1.0f),optBool("hide_numbers","Hide score numbers",false)}},
        {"screenshot", "Screenshot / Screenshot Uploader", "Utility", false, ModuleState::Planned, false, {}, {optBool("include_hud","Include WIRZA HUD",true),optChoice("format","Image format",0,{"PNG","JPG"}),optInt("jpeg_quality","JPG quality",92,50,100)}},
        {"scrollable_tooltips", "Scrollable Tooltips", "UI", false, ModuleState::Partial, false, {}, {optFloat("scroll_speed","Scroll speed",1.0f,0.2f,4.0f),optBool("horizontal","Allow horizontal scroll",false)}},
        {"server_address", "Server Address", "HUD", false, ModuleState::Implemented, true, {}, {optBool("hide_port","Hide port",false),optBool("hide_when_local","Hide in local world",true),optBool("prefer_hostname","Prefer hostname",true)}},
        {"shields", "Shields", "Visual", false, ModuleState::Partial, false, {}, {optFloat("scale","Shield scale",1.0f,0.3f,1.5f),optFloat("x","X offset",0.0f,-2.0f,2.0f),optFloat("y","Y offset",0.0f,-2.0f,2.0f)}},
        {"shiny_pots", "Shiny Pots", "Visual", false, ModuleState::Partial, false, {}, {optColor("shine_color","Shine color",1.0f,1.0f,1.0f,1.0f),optFloat("strength","Shine strength",1.0f,0.0f,2.0f)}},
        {"stopwatch", "Stopwatch", "HUD", true, ModuleState::Implemented, true, {}, {optBool("show_ms","Show hundredths",true),optBool("auto_reset","Auto reset on world join",false)}},
        {"titles", "Titles", "HUD", false, ModuleState::Partial, true, {}, {optFloat("scale","Title scale",1.0f,0.5f,2.0f),optFloat("opacity","Opacity",1.0f,0.0f,1.0f),optColor("title_color","Title color",1.0f,1.0f,1.0f,1.0f)}},
        {"toggle_sneak_sprint", "Toggle Sneak / Toggle Sprint", "Input", false, ModuleState::Partial, false, {}, {optBool("toggle_sprint","Toggle sprint",true),optBool("toggle_sneak","Toggle sneak",true),optInt("sprint_key","Sprint key",17,1,255),optInt("sneak_key","Sneak key",16,1,255)}},
        {"totem_counter", "Totem Counter", "HUD", false, ModuleState::Implemented, true, {}, {optInt("warn_below","Warn below",1,0,10),optColor("warning_color","Warning color",1.0f,0.25f,0.2f,1.0f)}},
        {"waila", "WAILA", "HUD", false, ModuleState::Partial, true, {}, {optBool("show_block","Show block name",true),optBool("show_entity","Show entity name",true),optBool("show_distance","Show distance",false)}},
        {"waypoints", "Waypoints", "World", false, ModuleState::Partial, false, {}, {optFloat("max_distance","Max render distance",3000.0f,50.0f,10000.0f),optBool("beam","Show vertical beam",true),optBool("show_distance","Show distance",true),optText("points","Waypoints: Name,x,y,z;...","Home,0,64,0"),optColor("waypoint_color","Default color",0.65f,0.35f,1.0f,1.0f)}},
        {"zoom", "Zoom", "Camera", true, ModuleState::Implemented, false, {}, {optFloat("target_fov","Zoom FOV (degrees)",30.0f,5.0f,90.0f),optFloat("wheel_step","Mouse wheel FOV step",5.0f,1.0f,15.0f),optBool("smooth","Smooth zoom",true),optFloat("smooth_speed","Smooth speed",12.0f,1.0f,30.0f)}},
        {"potion_counter", "Potion Counter", "HUD", false, ModuleState::Implemented, true, {}, {optChoice("type","Potion filter",0,{"All","Healing","Speed","Strength","Regeneration"}),optInt("warn_below","Warn below",1,0,20)}},
    };
}

std::wstring ModuleRegistry::FilePath() const { return appDataDir() + L"\\modules.ini"; }

void ModuleRegistry::Load() {
    Initialize();
    const auto f = FilePath();
    for (auto& m : modules_) {
        const auto s = widen("Module." + m.id);
        m.enabled = readInt(f, s, L"Enabled", m.enabled ? 1 : 0) != 0;

        if (m.hud) {
            m.hudStyle.x = readFloat(f, s, L"X", m.hudStyle.x);
            m.hudStyle.y = readFloat(f, s, L"Y", m.hudStyle.y);
            m.hudStyle.scale = readFloat(f, s, L"Scale", m.hudStyle.scale);
            m.hudStyle.opacity = readFloat(f, s, L"Opacity", m.hudStyle.opacity);
            m.hudStyle.textSize = readFloat(f, s, L"TextSize", m.hudStyle.textSize);
            m.hudStyle.cornerRadius = readFloat(f,s,L"CornerRadius",m.hudStyle.cornerRadius);
            m.hudStyle.background = readInt(f, s, L"Background", m.hudStyle.background ? 1 : 0) != 0;

            m.hudStyle.backgroundColor.r=readFloat(f,s,L"BgR",m.hudStyle.backgroundColor.r);
            m.hudStyle.backgroundColor.g=readFloat(f,s,L"BgG",m.hudStyle.backgroundColor.g);
            m.hudStyle.backgroundColor.b=readFloat(f,s,L"BgB",m.hudStyle.backgroundColor.b);
            m.hudStyle.backgroundColor.a=readFloat(f,s,L"BgA",m.hudStyle.backgroundColor.a);

            m.hudStyle.textColor.r=readFloat(f,s,L"TextR",m.hudStyle.textColor.r);
            m.hudStyle.textColor.g=readFloat(f,s,L"TextG",m.hudStyle.textColor.g);
            m.hudStyle.textColor.b=readFloat(f,s,L"TextB",m.hudStyle.textColor.b);
            m.hudStyle.textColor.a=readFloat(f,s,L"TextA",m.hudStyle.textColor.a);

            m.hudStyle.accentColor.r=readFloat(f,s,L"AccentR",m.hudStyle.accentColor.r);
            m.hudStyle.accentColor.g=readFloat(f,s,L"AccentG",m.hudStyle.accentColor.g);
            m.hudStyle.accentColor.b=readFloat(f,s,L"AccentB",m.hudStyle.accentColor.b);
            m.hudStyle.accentColor.a=readFloat(f,s,L"AccentA",m.hudStyle.accentColor.a);
        }

        for(auto& o:m.options){
            const auto k=widen("Option."+o.key);
            switch(o.type){
                case OptionType::Bool:
                    o.boolValue=readInt(f,s,k,o.boolValue?1:0)!=0; break;
                case OptionType::Float:
                    o.floatValue=std::clamp(readFloat(f,s,k,o.floatValue),o.floatMin,o.floatMax); break;
                case OptionType::Int:
                    o.intValue=std::clamp(readInt(f,s,k,o.intValue),o.intMin,o.intMax); break;
                case OptionType::Color:
                    o.colorValue.r=readFloat(f,s,k+L".R",o.colorValue.r);
                    o.colorValue.g=readFloat(f,s,k+L".G",o.colorValue.g);
                    o.colorValue.b=readFloat(f,s,k+L".B",o.colorValue.b);
                    o.colorValue.a=readFloat(f,s,k+L".A",o.colorValue.a);
                    break;
                case OptionType::Choice:
                    if(!o.choices.empty()) o.choiceIndex=std::clamp(readInt(f,s,k,o.choiceIndex),0,(int)o.choices.size()-1);
                    break;
                case OptionType::Text:
                    o.textValue=readText(f,s,k,o.textValue); break;
            }
        }
    }
}

void ModuleRegistry::Save() const {
    const auto f = FilePath();
    for (const auto& m : modules_) {
        const auto s = widen("Module." + m.id);
        writeInt(f, s, L"Enabled", m.enabled ? 1 : 0);

        if (m.hud) {
            writeFloat(f, s, L"X", m.hudStyle.x);
            writeFloat(f, s, L"Y", m.hudStyle.y);
            writeFloat(f, s, L"Scale", m.hudStyle.scale);
            writeFloat(f, s, L"Opacity", m.hudStyle.opacity);
            writeFloat(f, s, L"TextSize", m.hudStyle.textSize);
            writeFloat(f,s,L"CornerRadius",m.hudStyle.cornerRadius);
            writeInt(f, s, L"Background", m.hudStyle.background ? 1 : 0);

            writeFloat(f,s,L"BgR",m.hudStyle.backgroundColor.r);
            writeFloat(f,s,L"BgG",m.hudStyle.backgroundColor.g);
            writeFloat(f,s,L"BgB",m.hudStyle.backgroundColor.b);
            writeFloat(f,s,L"BgA",m.hudStyle.backgroundColor.a);

            writeFloat(f,s,L"TextR",m.hudStyle.textColor.r);
            writeFloat(f,s,L"TextG",m.hudStyle.textColor.g);
            writeFloat(f,s,L"TextB",m.hudStyle.textColor.b);
            writeFloat(f,s,L"TextA",m.hudStyle.textColor.a);

            writeFloat(f,s,L"AccentR",m.hudStyle.accentColor.r);
            writeFloat(f,s,L"AccentG",m.hudStyle.accentColor.g);
            writeFloat(f,s,L"AccentB",m.hudStyle.accentColor.b);
            writeFloat(f,s,L"AccentA",m.hudStyle.accentColor.a);
        }

        for(const auto& o:m.options){
            const auto k=widen("Option."+o.key);
            switch(o.type){
                case OptionType::Bool: writeInt(f,s,k,o.boolValue?1:0); break;
                case OptionType::Float: writeFloat(f,s,k,o.floatValue); break;
                case OptionType::Int: writeInt(f,s,k,o.intValue); break;
                case OptionType::Color:
                    writeFloat(f,s,k+L".R",o.colorValue.r);
                    writeFloat(f,s,k+L".G",o.colorValue.g);
                    writeFloat(f,s,k+L".B",o.colorValue.b);
                    writeFloat(f,s,k+L".A",o.colorValue.a);
                    break;
                case OptionType::Choice: writeInt(f,s,k,o.choiceIndex); break;
                case OptionType::Text: writeText(f,s,k,o.textValue); break;
            }
        }
    }
}

ModuleConfig* ModuleRegistry::Find(const std::string& id) {
    for (auto& m : modules_) if (m.id == id) return &m;
    return nullptr;
}
const ModuleConfig* ModuleRegistry::Find(const std::string& id) const {
    for (const auto& m : modules_) if (m.id == id) return &m;
    return nullptr;
}
ModuleOption* ModuleRegistry::Option(ModuleConfig& module,const std::string& key){
    for(auto& o:module.options) if(o.key==key) return &o;
    return nullptr;
}
const ModuleOption* ModuleRegistry::Option(const ModuleConfig& module,const std::string& key) const{
    for(const auto& o:module.options) if(o.key==key) return &o;
    return nullptr;
}
float ModuleRegistry::Float(const std::string& moduleId,const std::string& key,float fallback) const{
    auto* m=Find(moduleId); if(!m)return fallback; auto* o=Option(*m,key); return o&&o->type==OptionType::Float?o->floatValue:fallback;
}
int ModuleRegistry::Int(const std::string& moduleId,const std::string& key,int fallback) const{
    auto* m=Find(moduleId); if(!m)return fallback; auto* o=Option(*m,key); return o&&o->type==OptionType::Int?o->intValue:fallback;
}
bool ModuleRegistry::Bool(const std::string& moduleId,const std::string& key,bool fallback) const{
    auto* m=Find(moduleId); if(!m)return fallback; auto* o=Option(*m,key); return o&&o->type==OptionType::Bool?o->boolValue:fallback;
}
std::string ModuleRegistry::Text(const std::string& moduleId,const std::string& key,const std::string& fallback) const{
    auto* m=Find(moduleId); if(!m)return fallback; auto* o=Option(*m,key); return o&&o->type==OptionType::Text?o->textValue:fallback;
}
const char* ModuleRegistry::StateText(ModuleState s) const {
    switch (s) {
        case ModuleState::Implemented: return "Implemented";
        case ModuleState::Partial: return "Partial";
        case ModuleState::BedrockAlternative: return "Bedrock alternative required";
        case ModuleState::NotApplicable: return "Not applicable";
        default: return "Planned";
    }
}
}
