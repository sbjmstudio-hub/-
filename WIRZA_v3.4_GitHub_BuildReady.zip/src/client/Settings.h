#pragma once
#include <windows.h>
#include <string>

namespace wirza {
struct HudPosition { float x = 20.0f; float y = 20.0f; };

struct Settings {
    bool fps = true;
    bool cps = true;
    bool wasd = true;
    bool mouse = true;
    bool timer = true;
    bool stopwatch = true;
    bool zoom = true;
    bool hideAllHud = false;
    bool hudEdit = false;
    float hudScale = 1.0f;
    float zoomFactor = 4.0f;
    int timerSeconds = 600;

    // Module-specific settings for currently implemented v3 modules.
    float crosshairLength = 8.0f;
    float crosshairGap = 3.0f;
    float crosshairThickness = 2.0f;
    float crosshairR = 1.0f;
    float crosshairG = 1.0f;
    float crosshairB = 1.0f;
    float crosshairA = 1.0f;

    HudPosition fpsPos{20, 20};
    HudPosition cpsPos{20, 72};
    HudPosition wasdPos{20, 124};
    HudPosition mousePos{20, 250};
    HudPosition timerPos{20, 330};
    HudPosition stopwatchPos{20, 385};

    static Settings& Get();
    void Load();
    void Save() const;
    std::wstring FilePath() const;
};
}
