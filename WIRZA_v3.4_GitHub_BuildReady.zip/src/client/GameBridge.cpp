#include "GameBridge.h"
#include "PatternScan.h"
#include "Settings.h"
#include "Input.h"
#include "ModuleRegistry.h"
#include <MinHook.h>
#include <windows.h>
#include <cmath>
#include <atomic>
#include <algorithm>

// WIRZA Phase 1 version adapter.
// The render-level signature and field layout are deliberately isolated here so
// Minecraft updates cannot silently write arbitrary addresses. If the expected
// function pattern is absent, Zoom is disabled rather than guessing.
namespace wirza {
namespace {
using RenderLevelFn = void(__fastcall*)(void*, void*, void*);
RenderLevelFn g_original=nullptr; void* g_target=nullptr; std::atomic<bool> g_supported=false; float g_zoomModifier=1.0f;
constexpr ptrdiff_t kLevelRendererPlayerOffset=0x468;
constexpr ptrdiff_t kFovXOffset=0xF58;
constexpr ptrdiff_t kFovYOffset=0xF6C;

void __fastcall hookRenderLevel(void* levelRenderer, void* screenContext, void* unk){
    g_original(levelRenderer,screenContext,unk);
    GameBridge::ApplyZoom(levelRenderer);
}
}

bool GameBridge::Install(){
    HMODULE mc=GetModuleHandleW(nullptr);
    // Current 26.4X profile. Pattern resolves a CALL to LevelRenderer::renderLevel.
    const uintptr_t call=FindPattern(mc,"E8 ? ? ? ? 45 31 E4 48 83 BE");
    if(!call){ g_supported=false; return false; }
    const uintptr_t target=ResolveRel32(call,1,5);
    if(!ReadableAddress(reinterpret_cast<void*>(target),16)){ g_supported=false; return false; }
    g_target=reinterpret_cast<void*>(target);
    if(MH_CreateHook(g_target,reinterpret_cast<void*>(&hookRenderLevel),reinterpret_cast<void**>(&g_original))!=MH_OK){ g_supported=false; return false; }
    if(MH_EnableHook(g_target)!=MH_OK){ g_supported=false; return false; }
    g_supported=true; return true;
}
void GameBridge::Uninstall(){ if(g_target) MH_DisableHook(g_target); g_supported=false; g_zoomModifier=1.0f; }
bool GameBridge::ZoomSupported(){ return g_supported.load(); }
const char* GameBridge::ZoomStatus(){ return g_supported.load()?"Ready (native camera FOV)":"Unsupported game build - safely disabled"; }
float GameBridge::ZoomModifier(){ return g_supported.load()?g_zoomModifier:1.0f; }
void GameBridge::ApplyZoom(void* levelRenderer){
    if(!g_supported.load())return;

    const auto& in=Input::Get().State();
    auto& mods=ModuleRegistry::Get();
    auto* zoom=mods.Find("zoom");

    const bool enabled=zoom && zoom->enabled && in.foreground;
    const float normalFov=std::clamp(mods.Float("fov","normal_fov",90.0f),30.0f,120.0f);
    const float targetFov=std::clamp(mods.Float("zoom","target_fov",30.0f),5.0f,normalFov);
    const float targetModifier=(enabled && in.c)
        ? std::clamp(targetFov/normalFov,0.04f,1.0f)
        : 1.0f;

    const bool smooth=mods.Bool("zoom","smooth",true);
    if(smooth){
        const float speed=std::clamp(mods.Float("zoom","smooth_speed",12.0f),1.0f,30.0f);
        const float alpha=std::clamp(speed/60.0f,0.02f,0.65f);
        g_zoomModifier += (targetModifier-g_zoomModifier)*alpha;
        if(std::fabs(g_zoomModifier-targetModifier)<0.0005f) g_zoomModifier=targetModifier;
    }else{
        g_zoomModifier=targetModifier;
    }

    if(g_zoomModifier>0.9995f)return;

    auto base=reinterpret_cast<uint8_t*>(levelRenderer);
    if(!ReadableAddress(base+kLevelRendererPlayerOffset,sizeof(void*)))return;
    void* player=*reinterpret_cast<void**>(base+kLevelRendererPlayerOffset);
    if(!ReadableAddress(player,static_cast<size_t>(kFovYOffset+sizeof(float))))return;

    float* fx=reinterpret_cast<float*>(reinterpret_cast<uint8_t*>(player)+kFovXOffset);
    float* fy=reinterpret_cast<float*>(reinterpret_cast<uint8_t*>(player)+kFovYOffset);
    if(!std::isfinite(*fx)||!std::isfinite(*fy)||std::fabs(*fx)>10000.f||std::fabs(*fy)>10000.f)return;

    *fx*=g_zoomModifier;
    *fy*=g_zoomModifier;
}
}
