#include "AutoTextController.h"
#include "ModuleRegistry.h"
#include <algorithm>

namespace wirza {

AutoTextController& AutoTextController::Get(){ static AutoTextController c; return c; }

void AutoTextController::tapKey(WORD vk){
    INPUT in[2]{};
    in[0].type=INPUT_KEYBOARD; in[0].ki.wVk=vk;
    in[1]=in[0]; in[1].ki.dwFlags=KEYEVENTF_KEYUP;
    SendInput(2,in,sizeof(INPUT));
}

void AutoTextController::typeUnicode(const std::string& text){
    if(text.empty()) return;
    int n=MultiByteToWideChar(CP_UTF8,0,text.c_str(),-1,nullptr,0);
    if(n<=1) return;
    std::wstring w(static_cast<size_t>(n),L'\0');
    MultiByteToWideChar(CP_UTF8,0,text.c_str(),-1,w.data(),n);
    w.resize(static_cast<size_t>(n-1));
    for(wchar_t ch:w){
        INPUT in[2]{};
        in[0].type=INPUT_KEYBOARD; in[0].ki.wScan=ch; in[0].ki.dwFlags=KEYEVENTF_UNICODE;
        in[1]=in[0]; in[1].ki.dwFlags=KEYEVENTF_UNICODE|KEYEVENTF_KEYUP;
        SendInput(2,in,sizeof(INPUT));
    }
}

void AutoTextController::queue(const std::string& text,int delayMs){
    if(text.empty()) return;
    pending_=text;
    due_=std::chrono::steady_clock::now()+std::chrono::milliseconds(std::clamp(delayMs,0,5000));
    phase_=1;
    status_="Queued";
}

void AutoTextController::TriggerAction(const std::string& text,int delayMs){ queue(text,delayMs); }

void AutoTextController::Update(HWND, bool gameplayActive){
    auto& mods=ModuleRegistry::Get();
    auto* hot=mods.Find("auto_text_hotkey");
    if(!gameplayActive){ prevHotkeyDown_=false; return; }

    if(hot && hot->enabled){
        const int vk=mods.Int("auto_text_hotkey","hotkey",117);
        const bool down=(GetAsyncKeyState(vk)&0x8000)!=0;
        if(down && !prevHotkeyDown_) queue(mods.Text("auto_text_hotkey","text","gg"),0);
        prevHotkeyDown_=down;
    }else prevHotkeyDown_=false;

    const auto now=std::chrono::steady_clock::now();
    if(phase_==1 && now>=due_){
        // Open vanilla chat, then type on a later frame so the focus change has time to settle.
        tapKey('T');
        due_=now+std::chrono::milliseconds(60);
        phase_=2;
        status_="Opening chat";
    }else if(phase_==2 && now>=due_){
        typeUnicode(pending_);
        tapKey(VK_RETURN);
        pending_.clear(); phase_=0; status_="Sent";
    }
}

}
