#pragma once
namespace wirza { class D3D12Hooks { public: static bool Install(); static void Shutdown(); }; }
